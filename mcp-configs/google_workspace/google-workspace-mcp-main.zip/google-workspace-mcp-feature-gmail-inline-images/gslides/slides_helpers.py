"""
Google Slides Helper Functions

Utility functions for working with the Google Slides API.
"""

from typing import Dict, Any, Optional, Tuple
import uuid


# Standard Google Slides dimensions (in EMU - English Metric Units)
# 1 inch = 914400 EMU, 1 point = 12700 EMU
SLIDE_WIDTH_EMU = 9144000  # 10 inches (standard 16:9 slide)
SLIDE_HEIGHT_EMU = 5143500  # ~5.625 inches


def inches_to_emu(inches: float) -> int:
    """Convert inches to EMU (English Metric Units)."""
    return int(inches * 914400)


def emu_to_inches(emu: int) -> float:
    """Convert EMU to inches."""
    return emu / 914400


def points_to_emu(points: float) -> int:
    """Convert points to EMU."""
    return int(points * 12700)


def emu_to_points(emu: int) -> float:
    """Convert EMU to points."""
    return emu / 12700


def generate_object_id(prefix: str = "obj") -> str:
    """Generate a unique object ID for slides elements."""
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def calculate_position(
    position: str,
    width_emu: int,
    height_emu: int,
    slide_width: int = SLIDE_WIDTH_EMU,
    slide_height: int = SLIDE_HEIGHT_EMU,
    margin_emu: int = 457200,  # 0.5 inch margin
) -> Tuple[int, int]:
    """
    Calculate x, y position based on named position.

    Args:
        position: One of 'center', 'top-left', 'top-center', 'top-right',
                 'middle-left', 'middle-right', 'bottom-left', 'bottom-center',
                 'bottom-right'
        width_emu: Width of the element in EMU
        height_emu: Height of the element in EMU
        slide_width: Slide width in EMU
        slide_height: Slide height in EMU
        margin_emu: Margin from edges in EMU

    Returns:
        Tuple of (x, y) position in EMU
    """
    position = position.lower().replace("_", "-")

    # Calculate center positions
    center_x = (slide_width - width_emu) // 2
    center_y = (slide_height - height_emu) // 2

    # Calculate edge positions
    left_x = margin_emu
    right_x = slide_width - width_emu - margin_emu
    top_y = margin_emu
    bottom_y = slide_height - height_emu - margin_emu

    positions = {
        "center": (center_x, center_y),
        "top-left": (left_x, top_y),
        "top-center": (center_x, top_y),
        "top-right": (right_x, top_y),
        "middle-left": (left_x, center_y),
        "middle-right": (right_x, center_y),
        "bottom-left": (left_x, bottom_y),
        "bottom-center": (center_x, bottom_y),
        "bottom-right": (right_x, bottom_y),
    }

    return positions.get(position, (center_x, center_y))


def create_size_dict(width_emu: int, height_emu: int) -> Dict[str, Any]:
    """Create a size dictionary for the Slides API."""
    return {
        "width": {"magnitude": width_emu, "unit": "EMU"},
        "height": {"magnitude": height_emu, "unit": "EMU"},
    }


def create_transform_dict(
    x_emu: int, y_emu: int, scale_x: float = 1.0, scale_y: float = 1.0
) -> Dict[str, Any]:
    """Create a transform dictionary for the Slides API."""
    return {
        "scaleX": scale_x,
        "scaleY": scale_y,
        "translateX": x_emu,
        "translateY": y_emu,
        "unit": "EMU",
    }


def create_element_properties(
    page_id: str,
    width_emu: int,
    height_emu: int,
    x_emu: int,
    y_emu: int,
) -> Dict[str, Any]:
    """Create elementProperties for the Slides API."""
    return {
        "pageObjectId": page_id,
        "size": create_size_dict(width_emu, height_emu),
        "transform": create_transform_dict(x_emu, y_emu),
    }


def extract_text_from_shape(shape: Dict[str, Any]) -> str:
    """Extract text content from a shape element."""
    text_content = shape.get("text", {})
    if not text_content:
        return ""

    text_parts = []
    for text_element in text_content.get("textElements", []):
        text_run = text_element.get("textRun", {})
        content = text_run.get("content", "")
        if content:
            text_parts.append((text_element.get("startIndex", 0), content))

    # Sort by start index and join
    text_parts.sort(key=lambda x: x[0])
    return "".join([part[1] for part in text_parts]).strip()


def get_element_type(element: Dict[str, Any]) -> str:
    """Determine the type of a page element."""
    if "shape" in element:
        shape_type = element["shape"].get("shapeType", "SHAPE")
        if shape_type == "TEXT_BOX":
            return "text_box"
        return f"shape:{shape_type.lower()}"
    elif "image" in element:
        return "image"
    elif "video" in element:
        return "video"
    elif "table" in element:
        return "table"
    elif "line" in element:
        return "line"
    elif "sheetsChart" in element:
        return "chart"
    elif "wordArt" in element:
        return "word_art"
    elif "elementGroup" in element:
        return "group"
    return "unknown"


def get_element_bounds(element: Dict[str, Any]) -> Optional[Dict[str, float]]:
    """Get the bounds (position and size) of an element in inches."""
    size = element.get("size", {})
    transform = element.get("transform", {})

    if not size or not transform:
        return None

    width = size.get("width", {}).get("magnitude", 0)
    height = size.get("height", {}).get("magnitude", 0)
    x = transform.get("translateX", 0)
    y = transform.get("translateY", 0)
    scale_x = transform.get("scaleX", 1)
    scale_y = transform.get("scaleY", 1)

    return {
        "x_inches": emu_to_inches(x),
        "y_inches": emu_to_inches(y),
        "width_inches": emu_to_inches(width * scale_x),
        "height_inches": emu_to_inches(height * scale_y),
    }


def rgb_to_slides_color(
    red: float, green: float, blue: float
) -> Dict[str, Dict[str, float]]:
    """
    Convert RGB values (0-1 or 0-255) to Slides API color format.

    Args:
        red, green, blue: Color values. If > 1, assumed to be 0-255 range.

    Returns:
        Dict in Slides API color format
    """
    # Normalize to 0-1 range if needed
    if red > 1 or green > 1 or blue > 1:
        red = red / 255
        green = green / 255
        blue = blue / 255

    return {"rgbColor": {"red": red, "green": green, "blue": blue}}


def hex_to_slides_color(hex_color: str) -> Dict[str, Dict[str, float]]:
    """
    Convert hex color to Slides API color format.

    Args:
        hex_color: Color in hex format (e.g., "#FF0000" or "FF0000")

    Returns:
        Dict in Slides API color format
    """
    hex_color = hex_color.lstrip("#")
    r = int(hex_color[0:2], 16) / 255
    g = int(hex_color[2:4], 16) / 255
    b = int(hex_color[4:6], 16) / 255
    return rgb_to_slides_color(r, g, b)


def color_to_hex(color_dict: Dict[str, Any]) -> Optional[str]:
    """
    Convert Slides API color format to hex string.

    Args:
        color_dict: Color in Slides API format (opaqueColor.rgbColor or similar)

    Returns:
        Hex color string like "#FF0000" or None if not convertible
    """
    if not color_dict:
        return None

    opaque = color_dict.get("opaqueColor", {})
    rgb = opaque.get("rgbColor", {})

    if not rgb:
        # Might be a theme color reference
        theme_color = opaque.get("themeColor")
        if theme_color:
            return f"THEME:{theme_color}"
        return None

    r = int(rgb.get("red", 0) * 255)
    g = int(rgb.get("green", 0) * 255)
    b = int(rgb.get("blue", 0) * 255)
    return f"#{r:02X}{g:02X}{b:02X}"


def resolve_effective_text_style(
    presentation: Dict[str, Any],
    element: Dict[str, Any],
    text_run_style: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Resolve the complete effective text style for an element, including inheritance.

    This walks the inheritance chain:
    1. Explicit style on the text run itself
    2. Placeholder parent in the layout
    3. Master slide defaults
    4. Theme defaults

    Args:
        presentation: The full presentation object from the API
        element: The page element containing text
        text_run_style: Optional explicit style from a specific textRun

    Returns:
        Dict with resolved style properties:
        - font_family: str
        - font_weight: int (100-900)
        - font_size_pt: float
        - font_color: str (hex or "THEME:name")
        - bold: bool
        - italic: bool
        - underline: bool
        - line_spacing: int (percentage, e.g., 100 = single space)
    """
    result = {
        "font_family": None,
        "font_weight": None,
        "font_size_pt": None,
        "font_color": None,
        "bold": None,
        "italic": None,
        "underline": None,
        "line_spacing": None,
    }

    # Helper to extract style properties
    def extract_from_style(style: Dict[str, Any]) -> None:
        if not style:
            return

        # Font family and weight
        wff = style.get("weightedFontFamily", {})
        if wff:
            if result["font_family"] is None and wff.get("fontFamily"):
                result["font_family"] = wff.get("fontFamily")
            if result["font_weight"] is None and wff.get("weight"):
                result["font_weight"] = wff.get("weight")

        # Legacy font family
        if result["font_family"] is None and style.get("fontFamily"):
            result["font_family"] = style.get("fontFamily")

        # Font size
        if result["font_size_pt"] is None:
            fs = style.get("fontSize", {})
            if fs and fs.get("unit") == "PT":
                result["font_size_pt"] = fs.get("magnitude")

        # Font color
        if result["font_color"] is None:
            fg = style.get("foregroundColor")
            if fg:
                result["font_color"] = color_to_hex(fg)

        # Text decorations
        if result["bold"] is None and "bold" in style:
            result["bold"] = style.get("bold")
        if result["italic"] is None and "italic" in style:
            result["italic"] = style.get("italic")
        if result["underline"] is None and "underline" in style:
            result["underline"] = style.get("underline")

    def extract_from_paragraph_style(style: Dict[str, Any]) -> None:
        if not style:
            return
        if result["line_spacing"] is None and "lineSpacing" in style:
            result["line_spacing"] = style.get("lineSpacing")

    # 1. Start with explicit text run style
    if text_run_style:
        extract_from_style(text_run_style)

    # 2. Check the element's first text run if we don't have text_run_style
    if not text_run_style and "shape" in element:
        text = element["shape"].get("text", {})
        for te in text.get("textElements", []):
            if "textRun" in te:
                extract_from_style(te["textRun"].get("style", {}))
                break
            if "paragraphMarker" in te:
                extract_from_paragraph_style(te["paragraphMarker"].get("style", {}))

    # 3. Check placeholder parent in layout
    placeholder = element.get("shape", {}).get("placeholder", {})
    parent_id = placeholder.get("parentObjectId")

    if parent_id:
        # Find the parent placeholder in layouts
        for layout in presentation.get("layouts", []):
            for layout_elem in layout.get("pageElements", []):
                if layout_elem.get("objectId") == parent_id:
                    # Found the parent placeholder - extract its first text style
                    if "shape" in layout_elem:
                        text = layout_elem["shape"].get("text", {})
                        for te in text.get("textElements", []):
                            if "textRun" in te:
                                extract_from_style(te["textRun"].get("style", {}))
                            if "paragraphMarker" in te:
                                extract_from_paragraph_style(
                                    te["paragraphMarker"].get("style", {})
                                )
                    break

    # 4. Check master slide defaults (simplified - use first text style found)
    if any(v is None for v in result.values()):
        for master in presentation.get("masters", []):
            for master_elem in master.get("pageElements", []):
                if "shape" in master_elem and "text" in master_elem["shape"]:
                    text = master_elem["shape"]["text"]
                    for te in text.get("textElements", []):
                        if "textRun" in te:
                            extract_from_style(te["textRun"].get("style", {}))
                            # Only take the first one as a fallback
                            break
                    break
            break

    # 5. Apply reasonable defaults for anything still missing
    if result["font_family"] is None:
        result["font_family"] = "Arial"  # Google Slides default
    if result["font_weight"] is None:
        result["font_weight"] = 400
    if result["font_size_pt"] is None:
        result["font_size_pt"] = 18.0
    if result["font_color"] is None:
        result["font_color"] = "#000000"
    if result["bold"] is None:
        result["bold"] = False
    if result["italic"] is None:
        result["italic"] = False
    if result["underline"] is None:
        result["underline"] = False
    if result["line_spacing"] is None:
        result["line_spacing"] = 100

    return result


def create_text_style_requests(
    element_id: str,
    font_family: Optional[str] = None,
    font_size_pt: Optional[float] = None,
    font_weight: Optional[int] = None,
    font_color: Optional[str] = None,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
    underline: Optional[bool] = None,
    line_spacing: Optional[int] = None,
) -> list:
    """
    Create batch update requests to apply text styling.

    Args:
        element_id: The object ID of the text element
        font_family: Font family name (e.g., "Noto Sans")
        font_size_pt: Font size in points
        font_weight: Font weight (100-900, 400=normal, 700=bold)
        font_color: Hex color string (e.g., "#FFFFFF")
        bold: Whether text should be bold
        italic: Whether text should be italic
        underline: Whether text should be underlined
        line_spacing: Line spacing as percentage (100 = single)

    Returns:
        List of request dicts for batchUpdate
    """
    requests = []

    # Build text style
    text_style: Dict[str, Any] = {}
    text_fields = []

    if font_family is not None or font_weight is not None:
        wff: Dict[str, Any] = {}
        if font_family:
            wff["fontFamily"] = font_family
        if font_weight:
            wff["weight"] = font_weight
        text_style["weightedFontFamily"] = wff
        text_fields.append("weightedFontFamily")

    if font_size_pt is not None:
        text_style["fontSize"] = {"magnitude": font_size_pt, "unit": "PT"}
        text_fields.append("fontSize")

    if font_color is not None and not font_color.startswith("THEME:"):
        text_style["foregroundColor"] = {"opaqueColor": hex_to_slides_color(font_color)}
        text_fields.append("foregroundColor")

    if bold is not None:
        text_style["bold"] = bold
        text_fields.append("bold")

    if italic is not None:
        text_style["italic"] = italic
        text_fields.append("italic")

    if underline is not None:
        text_style["underline"] = underline
        text_fields.append("underline")

    if text_fields:
        requests.append(
            {
                "updateTextStyle": {
                    "objectId": element_id,
                    "textRange": {"type": "ALL"},
                    "style": text_style,
                    "fields": ",".join(text_fields),
                }
            }
        )

    # Build paragraph style
    if line_spacing is not None:
        requests.append(
            {
                "updateParagraphStyle": {
                    "objectId": element_id,
                    "textRange": {"type": "ALL"},
                    "style": {"lineSpacing": line_spacing},
                    "fields": "lineSpacing",
                }
            }
        )

    return requests
