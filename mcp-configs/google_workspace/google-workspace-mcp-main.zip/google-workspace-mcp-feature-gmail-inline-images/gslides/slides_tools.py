"""
Google Slides MCP Tools

This module provides MCP tools for interacting with Google Slides API.
"""

import logging
import asyncio
from typing import List, Dict, Any, Optional

from auth.service_decorator import require_google_service
from core.server import server
from core.utils import handle_http_errors
from core.comments import create_comment_tools
from gslides.slides_helpers import (
    generate_object_id,
    calculate_position,
    create_element_properties,
    inches_to_emu,
    get_element_type,
    get_element_bounds,
    extract_text_from_shape,
    resolve_effective_text_style,
    create_text_style_requests,
)

logger = logging.getLogger(__name__)


@server.tool()
@handle_http_errors("create_presentation", service_type="slides")
@require_google_service("slides", "slides")
async def create_presentation(
    service, user_google_email: str, title: str = "Untitled Presentation"
) -> str:
    """
    Create a new Google Slides presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        title (str): The title for the new presentation. Defaults to "Untitled Presentation".

    Returns:
        str: Details about the created presentation including ID and URL.

    ⚠️ VISUAL DESIGN REMINDER: New presentations have plain white backgrounds.
    If recreating an existing presentation, use view_slide() on the SOURCE first
    to see colors, backgrounds, and fonts - then apply those to your new slides.
    Visual design is as important as content in presentations!
    """
    logger.info(
        f"[create_presentation] Invoked. Email: '{user_google_email}', Title: '{title}'"
    )

    body = {"title": title}

    result = await asyncio.to_thread(service.presentations().create(body=body).execute)

    presentation_id = result.get("presentationId")
    presentation_url = f"https://docs.google.com/presentation/d/{presentation_id}/edit"

    confirmation_message = f"""Presentation Created Successfully for {user_google_email}:
- Title: {title}
- Presentation ID: {presentation_id}
- URL: {presentation_url}
- Slides: {len(result.get("slides", []))} slide(s) created"""

    logger.info(f"Presentation created successfully for {user_google_email}")
    return confirmation_message


@server.tool()
@handle_http_errors("get_presentation", is_read_only=True, service_type="slides")
@require_google_service("slides", "slides_read")
async def get_presentation(
    service, user_google_email: str, presentation_id: str
) -> str:
    """
    Get details about a Google Slides presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation to retrieve.

    Returns:
        str: Details about the presentation including title, slides count, and metadata.

    ⚠️ VISUAL DESIGN TIP: This tool returns text content and structure, but NOT visual
    styling (colors, backgrounds, fonts). To see how slides actually LOOK, use:
        view_slide(presentation_id, slide_index=N)
    then read_file() the resulting image. Visual design is as important as content!
    """
    logger.info(
        f"[get_presentation] Invoked. Email: '{user_google_email}', ID: '{presentation_id}'"
    )

    result = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )

    title = result.get("title", "Untitled")
    slides = result.get("slides", [])
    page_size = result.get("pageSize", {})

    slides_info = []
    for i, slide in enumerate(slides, 1):
        slide_id = slide.get("objectId", "Unknown")
        page_elements = slide.get("pageElements", [])

        # Collect text from the slide whose JSON structure is very complicated
        # https://googleapis.github.io/google-api-python-client/docs/dyn/slides_v1.presentations.html#get
        slide_text = ""
        try:
            texts_from_elements = []
            for page_element in slide.get("pageElements", []):
                shape = page_element.get("shape", None)
                if shape and shape.get("text", None):
                    text = shape.get("text", None)
                    if text:
                        text_elements_in_shape = []
                        for text_element in text.get("textElements", []):
                            text_run = text_element.get("textRun", None)
                            if text_run:
                                content = text_run.get("content", None)
                                if content:
                                    start_index = text_element.get("startIndex", 0)
                                    text_elements_in_shape.append(
                                        (start_index, content)
                                    )

                        if text_elements_in_shape:
                            # Sort text elements within a single shape
                            text_elements_in_shape.sort(key=lambda item: item[0])
                            full_text_from_shape = "".join(
                                [item[1] for item in text_elements_in_shape]
                            )
                            texts_from_elements.append(full_text_from_shape)

            # cleanup text we collected
            slide_text = "\n".join(texts_from_elements)
            slide_text_rows = slide_text.split("\n")
            slide_text_rows = [row for row in slide_text_rows if len(row.strip()) > 0]
            if slide_text_rows:
                slide_text_rows = ["    > " + row for row in slide_text_rows]
                slide_text = "\n" + "\n".join(slide_text_rows)
            else:
                slide_text = ""
        except Exception as e:
            logger.warning(f"Failed to extract text from the slide {slide_id}: {e}")
            slide_text = f"<failed to extract text: {type(e)}, {e}>"

        slides_info.append(
            f"  Slide {i}: ID {slide_id}, {len(page_elements)} element(s), "
            f"text: {slide_text if slide_text else 'empty'}"
        )

    confirmation_message = f"""Presentation Details for {user_google_email}:
- Title: {title}
- Presentation ID: {presentation_id}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit
- Total Slides: {len(slides)}
- Page Size: {page_size.get("width", {}).get("magnitude", "Unknown")} x {page_size.get("height", {}).get("magnitude", "Unknown")} {page_size.get("width", {}).get("unit", "")}

Slides Breakdown:
{chr(10).join(slides_info) if slides_info else "  No slides found"}"""

    logger.info(f"Presentation retrieved successfully for {user_google_email}")
    return confirmation_message


@server.tool()
@handle_http_errors("batch_update_presentation", service_type="slides")
@require_google_service("slides", "slides")
async def batch_update_presentation(
    service,
    user_google_email: str,
    presentation_id: str,
    requests: List[Dict[str, Any]],
) -> str:
    """
    Apply batch updates to a Google Slides presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation to update.
        requests (List[Dict[str, Any]]): List of update requests to apply.

    Returns:
        str: Details about the batch update operation results.
    """
    logger.info(
        f"[batch_update_presentation] Invoked. Email: '{user_google_email}', ID: '{presentation_id}', Requests: {len(requests)}"
    )

    body = {"requests": requests}

    result = await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    replies = result.get("replies", [])

    confirmation_message = f"""Batch Update Completed for {user_google_email}:
- Presentation ID: {presentation_id}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit
- Requests Applied: {len(requests)}
- Replies Received: {len(replies)}"""

    if replies:
        confirmation_message += "\n\nUpdate Results:"
        for i, reply in enumerate(replies, 1):
            if "createSlide" in reply:
                slide_id = reply["createSlide"].get("objectId", "Unknown")
                confirmation_message += (
                    f"\n  Request {i}: Created slide with ID {slide_id}"
                )
            elif "createShape" in reply:
                shape_id = reply["createShape"].get("objectId", "Unknown")
                confirmation_message += (
                    f"\n  Request {i}: Created shape with ID {shape_id}"
                )
            else:
                confirmation_message += f"\n  Request {i}: Operation completed"

    logger.info(f"Batch update completed successfully for {user_google_email}")
    return confirmation_message


@server.tool()
@handle_http_errors("get_page", is_read_only=True, service_type="slides")
@require_google_service("slides", "slides_read")
async def get_page(
    service, user_google_email: str, presentation_id: str, page_object_id: str
) -> str:
    """
    Get details about a specific page (slide) in a presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        page_object_id (str): The object ID of the page/slide to retrieve.

    Returns:
        str: Details about the specific page including elements and layout.
    """
    logger.info(
        f"[get_page] Invoked. Email: '{user_google_email}', Presentation: '{presentation_id}', Page: '{page_object_id}'"
    )

    result = await asyncio.to_thread(
        service.presentations()
        .pages()
        .get(presentationId=presentation_id, pageObjectId=page_object_id)
        .execute
    )

    page_type = result.get("pageType", "Unknown")
    page_elements = result.get("pageElements", [])

    elements_info = []
    for element in page_elements:
        element_id = element.get("objectId", "Unknown")
        if "shape" in element:
            shape_type = element["shape"].get("shapeType", "Unknown")
            elements_info.append(f"  Shape: ID {element_id}, Type: {shape_type}")
        elif "table" in element:
            table = element["table"]
            rows = table.get("rows", 0)
            cols = table.get("columns", 0)
            elements_info.append(f"  Table: ID {element_id}, Size: {rows}x{cols}")
        elif "line" in element:
            line_type = element["line"].get("lineType", "Unknown")
            elements_info.append(f"  Line: ID {element_id}, Type: {line_type}")
        else:
            elements_info.append(f"  Element: ID {element_id}, Type: Unknown")

    confirmation_message = f"""Page Details for {user_google_email}:
- Presentation ID: {presentation_id}
- Page ID: {page_object_id}
- Page Type: {page_type}
- Total Elements: {len(page_elements)}

Page Elements:
{chr(10).join(elements_info) if elements_info else "  No elements found"}"""

    logger.info(f"Page retrieved successfully for {user_google_email}")
    return confirmation_message


@server.tool()
@handle_http_errors("get_page_thumbnail", is_read_only=True, service_type="slides")
@require_google_service("slides", "slides_read")
async def get_page_thumbnail(
    service,
    user_google_email: str,
    presentation_id: str,
    page_object_id: str,
    thumbnail_size: str = "MEDIUM",
) -> str:
    """
    Generate a thumbnail URL for a specific page (slide) in a presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        page_object_id (str): The object ID of the page/slide.
        thumbnail_size (str): Size of thumbnail ("LARGE", "MEDIUM", "SMALL"). Defaults to "MEDIUM".

    Returns:
        str: URL to the generated thumbnail image.
    """
    logger.info(
        f"[get_page_thumbnail] Invoked. Email: '{user_google_email}', Presentation: '{presentation_id}', Page: '{page_object_id}', Size: '{thumbnail_size}'"
    )

    result = await asyncio.to_thread(
        service.presentations()
        .pages()
        .getThumbnail(
            presentationId=presentation_id,
            pageObjectId=page_object_id,
            thumbnailProperties_thumbnailSize=thumbnail_size,
            thumbnailProperties_mimeType="PNG",
        )
        .execute
    )

    thumbnail_url = result.get("contentUrl", "")

    confirmation_message = f"""Thumbnail Generated for {user_google_email}:
- Presentation ID: {presentation_id}
- Page ID: {page_object_id}
- Thumbnail Size: {thumbnail_size}
- Thumbnail URL: {thumbnail_url}

You can view or download the thumbnail using the provided URL."""

    logger.info(f"Thumbnail generated successfully for {user_google_email}")
    return confirmation_message


@server.tool()
@handle_http_errors("view_slide", is_read_only=True, service_type="slides")
@require_google_service("slides", "slides_read")
async def view_slide(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: Optional[str] = None,
    slide_index: Optional[int] = None,
) -> str:
    """
    Get a visual preview of a slide by downloading its thumbnail image.

    ⚠️ CRITICAL FOR SLIDE WORK: Visual design is as important as content!
    Always use this tool to SEE how a slide actually looks before and after modifications.
    This helps you verify backgrounds, colors, fonts, and overall visual appearance.

    After calling this tool, use read_file on the returned file path to view the image.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str, optional): The object ID of the slide to view.
        slide_index (int, optional): 0-based index of the slide to view.
            Either slide_id or slide_index must be provided.

    Returns:
        str: Path to the downloaded thumbnail image. Use read_file to view it.

    Example workflow:
        1. view_slide(presentation_id="abc", slide_index=0)
        2. read_file("/tmp/slide_abc_0.png")  # View the actual slide appearance
        3. Note: background color, text colors, fonts, logos, etc.
        4. Recreate with matching visual design
    """
    import urllib.request
    import ssl

    logger.info(
        f"[view_slide] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}', Slide ID: {slide_id}, Index: {slide_index}"
    )

    if slide_id is None and slide_index is None:
        return "Error: Either slide_id or slide_index must be provided."

    target_id = slide_id
    actual_index = slide_index

    # Look up slide ID if using index
    if slide_index is not None:
        presentation = await asyncio.to_thread(
            service.presentations().get(presentationId=presentation_id).execute
        )
        slides = presentation.get("slides", [])

        if slide_index < 0 or slide_index >= len(slides):
            return f"Error: slide_index {slide_index} is out of range. Presentation has {len(slides)} slides (0-{len(slides) - 1})."

        target_id = slides[slide_index].get("objectId")
    else:
        # Find index for the slide ID
        presentation = await asyncio.to_thread(
            service.presentations().get(presentationId=presentation_id).execute
        )
        slides = presentation.get("slides", [])
        for i, slide in enumerate(slides):
            if slide.get("objectId") == slide_id:
                actual_index = i
                break

    # Get thumbnail URL
    result = await asyncio.to_thread(
        service.presentations()
        .pages()
        .getThumbnail(
            presentationId=presentation_id,
            pageObjectId=target_id,
            thumbnailProperties_thumbnailSize="LARGE",
            thumbnailProperties_mimeType="PNG",
        )
        .execute
    )

    thumbnail_url = result.get("contentUrl", "")

    if not thumbnail_url:
        return "Error: Could not generate thumbnail URL for this slide."

    # Download the thumbnail using urllib (built-in, no extra deps)
    try:
        # Create SSL context for HTTPS
        ssl_context = ssl.create_default_context()

        # Download synchronously (wrapped in to_thread for async compatibility)
        def download_image():
            req = urllib.request.Request(
                thumbnail_url, headers={"User-Agent": "Mozilla/5.0"}
            )
            with urllib.request.urlopen(
                req, context=ssl_context, timeout=30
            ) as response:
                return response.read()

        image_data = await asyncio.to_thread(download_image)

        # Save to temp file with descriptive name
        safe_pres_id = presentation_id[:12]  # Truncate for filename
        index_str = str(actual_index) if actual_index is not None else target_id[:8]
        filename = f"/tmp/slide_{safe_pres_id}_{index_str}.png"

        with open(filename, "wb") as f:
            f.write(image_data)

        logger.info(f"Slide thumbnail saved to {filename}")

        return f"""Slide Preview Downloaded Successfully:
- Presentation ID: {presentation_id}
- Slide ID: {target_id}
- Slide Index: {actual_index}
- Image saved to: {filename}

**NEXT STEP**: Use read_file("{filename}") to view the slide's visual appearance.

Check for:
- Background color/image
- Text colors and fonts
- Logos and brand elements
- Overall visual design

This is CRITICAL - visual design is as important as content for presentations!"""

    except Exception as e:
        logger.error(f"Failed to download thumbnail: {e}")
        return f"Error downloading thumbnail: {e}. Thumbnail URL: {thumbnail_url}"


# =============================================================================
# High-Level Convenience Tools
# =============================================================================


@server.tool()
@handle_http_errors("add_slide", service_type="slides")
@require_google_service("slides", "slides")
async def add_slide(
    service,
    user_google_email: str,
    presentation_id: str,
    position: Optional[int] = None,
    layout: Optional[str] = None,
) -> str:
    """
    Add a new slide to a presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        position (int, optional): 0-based index where to insert the slide.
            If not specified, adds at the end.
        layout (str, optional): Layout to use. Can be a layout ID (e.g., "p4")
            or a layout name like "TITLE", "TITLE_AND_BODY", "BLANK", etc.
            Use list_layouts to see available options.

    Returns:
        str: Details about the created slide including its ID.

    ⚠️ VISUAL DESIGN REMINDER: After adding a slide, set its background color/image
    with set_slide_background() if needed. New slides default to white backgrounds.
    Use view_slide() to verify the visual appearance after making changes.

    Examples:
        # Add blank slide at end
        add_slide(presentation_id="abc123")

        # Add slide at position 0 (beginning) with title layout
        add_slide(presentation_id="abc123", position=0, layout="TITLE")

        # Add slide using layout ID
        add_slide(presentation_id="abc123", layout="p4")
    """
    logger.info(
        f"[add_slide] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}', Position: {position}, Layout: {layout}"
    )

    # Generate a unique ID for the new slide
    slide_id = generate_object_id("slide")

    # Build the createSlide request
    create_request: Dict[str, Any] = {"objectId": slide_id}

    if position is not None:
        create_request["insertionIndex"] = position

    # Handle layout - could be ID or predefined name
    if layout:
        # First, get the presentation to find layout IDs
        presentation = await asyncio.to_thread(
            service.presentations().get(presentationId=presentation_id).execute
        )

        layout_id = None
        layout_upper = layout.upper()

        # Search through layouts
        for layout_obj in presentation.get("layouts", []):
            props = layout_obj.get("layoutProperties", {})
            obj_id = layout_obj.get("objectId", "")

            # Match by ID directly
            if obj_id == layout:
                layout_id = obj_id
                break

            # Match by layout name
            if props.get("name", "").upper() == layout_upper:
                layout_id = obj_id
                break

            # Match by display name
            if props.get("displayName", "").upper() == layout_upper:
                layout_id = obj_id
                break

        if layout_id:
            create_request["slideLayoutReference"] = {"layoutId": layout_id}
        else:
            # Try using it as a predefined layout type
            create_request["slideLayoutReference"] = {"predefinedLayout": layout_upper}

    # Execute the request
    body = {"requests": [{"createSlide": create_request}]}

    result = await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    # Get the created slide ID from response
    replies = result.get("replies", [])
    created_id = slide_id
    if replies and "createSlide" in replies[0]:
        created_id = replies[0]["createSlide"].get("objectId", slide_id)

    position_msg = f"at position {position}" if position is not None else "at the end"

    return f"""Slide Created Successfully:
- Presentation ID: {presentation_id}
- New Slide ID: {created_id}
- Position: {position_msg}
- Layout: {layout or "default"}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("delete_slide", service_type="slides")
@require_google_service("slides", "slides")
async def delete_slide(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: Optional[str] = None,
    slide_index: Optional[int] = None,
) -> str:
    """
    Delete a slide from a presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str, optional): The ID of the slide to delete.
        slide_index (int, optional): 0-based index of the slide to delete.
            Either slide_id or slide_index must be provided.

    Returns:
        str: Confirmation of the deletion.

    Examples:
        # Delete by slide ID
        delete_slide(presentation_id="abc123", slide_id="p")

        # Delete by index (first slide)
        delete_slide(presentation_id="abc123", slide_index=0)
    """
    logger.info(
        f"[delete_slide] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}', Slide ID: {slide_id}, Index: {slide_index}"
    )

    if slide_id is None and slide_index is None:
        return "Error: Either slide_id or slide_index must be provided."

    target_id = slide_id

    # If using index, look up the slide ID
    if slide_index is not None:
        presentation = await asyncio.to_thread(
            service.presentations().get(presentationId=presentation_id).execute
        )
        slides = presentation.get("slides", [])

        if slide_index < 0 or slide_index >= len(slides):
            return f"Error: slide_index {slide_index} is out of range. Presentation has {len(slides)} slides (0-{len(slides) - 1})."

        target_id = slides[slide_index].get("objectId")

    # Execute delete
    body = {"requests": [{"deleteObject": {"objectId": target_id}}]}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    return f"""Slide Deleted Successfully:
- Presentation ID: {presentation_id}
- Deleted Slide ID: {target_id}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("set_slide_layout", service_type="slides")
@require_google_service("slides", "slides")
async def set_slide_layout(
    service,
    user_google_email: str,
    presentation_id: str,
    layout: str,
    slide_id: Optional[str] = None,
    slide_index: Optional[int] = None,
) -> str:
    """
    Change a slide's layout by deleting and recreating it.

    ⚠️ API LIMITATION: Google Slides API does NOT support changing a slide's layout
    after creation. This tool works around this by:
    1. Deleting the existing slide
    2. Creating a new slide with the desired layout at the same position

    **WARNING**: This will remove any custom content from the slide! Only use this
    on slides where you plan to re-add the content, or on empty slides.

    Layouts are CRITICAL for visual design - they contain:
    - Background images (e.g., wave patterns, gradients)
    - Logos (e.g., company logo in corner)
    - Styled placeholders with correct fonts and colors
    - Proper text positioning

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        layout (str): Layout to use. Can be:
            - A layout ID (e.g., "g3adf3da1fe0_0_58")
            - A layout name like "TITLE", "TITLE_AND_BODY", "BLANK", "CUSTOM"
            - A display name like "Title slide", "Section header"
            Use list_layouts to see available options.
        slide_id (str, optional): The ID of the slide to update.
        slide_index (int, optional): 0-based index of the slide.
            Either slide_id or slide_index must be provided.

    Returns:
        str: Details about the new slide including its ID.

    ⚠️ VISUAL DESIGN TIP: Use list_layouts() to see all available layouts in a
    presentation. Look for "CUSTOM" layouts which often contain branded backgrounds
    and logos. Use view_slide() to verify the visual result!

    Examples:
        # Change to custom title layout
        set_slide_layout(presentation_id="abc", slide_index=0, layout="CUSTOM")

        # Change to specific layout by ID
        set_slide_layout(presentation_id="abc", slide_id="p", layout="g3adf3da1fe0_0_58")
    """
    logger.info(
        f"[set_slide_layout] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}', Layout: {layout}"
    )

    if slide_id is None and slide_index is None:
        return "Error: Either slide_id or slide_index must be provided."

    # Get the presentation to find the layout ID and slide ID
    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )

    # Resolve slide ID and index
    target_id = slide_id
    target_index = slide_index
    slides = presentation.get("slides", [])

    if slide_index is not None:
        if slide_index < 0 or slide_index >= len(slides):
            return f"Error: slide_index {slide_index} is out of range. Presentation has {len(slides)} slides."
        target_id = slides[slide_index].get("objectId")
    else:
        # Find the index from the slide ID
        for i, s in enumerate(slides):
            if s.get("objectId") == slide_id:
                target_index = i
                break
        if target_index is None:
            return f"Error: slide_id '{slide_id}' not found in presentation."

    # Find the layout ID
    layout_id = None
    layout_upper = layout.upper()
    layout_display_name = None

    for layout_obj in presentation.get("layouts", []):
        props = layout_obj.get("layoutProperties", {})
        obj_id = layout_obj.get("objectId", "")

        # Match by ID directly
        if obj_id == layout:
            layout_id = obj_id
            layout_display_name = props.get("displayName", layout)
            break

        # Match by layout name
        if props.get("name", "").upper() == layout_upper:
            layout_id = obj_id
            layout_display_name = props.get("displayName", layout)
            break

        # Match by display name (case-insensitive)
        if props.get("displayName", "").upper() == layout_upper:
            layout_id = obj_id
            layout_display_name = props.get("displayName", layout)
            break

    if not layout_id:
        # List available layouts for help
        available = []
        for layout_obj in presentation.get("layouts", []):
            props = layout_obj.get("layoutProperties", {})
            available.append(
                f"{layout_obj.get('objectId')} ({props.get('name')}/{props.get('displayName')})"
            )
        return f"Error: Layout '{layout}' not found. Available layouts:\n" + "\n".join(
            available
        )

    # Generate a new slide ID
    new_slide_id = generate_object_id("slide")

    # Delete old slide and create new one with the layout in a single batch
    body = {
        "requests": [
            {"deleteObject": {"objectId": target_id}},
            {
                "createSlide": {
                    "objectId": new_slide_id,
                    "insertionIndex": target_index,
                    "slideLayoutReference": {"layoutId": layout_id},
                }
            },
        ]
    }

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    return f"""Slide Layout Changed Successfully:
- Presentation ID: {presentation_id}
- Old Slide ID: {target_id} (deleted)
- New Slide ID: {new_slide_id}
- Position: {target_index}
- Layout: {layout_display_name} ({layout_id})
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit

⚠️ NOTE: The slide was recreated with the new layout. Any previous content
was removed. Use get_slide_details() to see the new placeholders, then
fill them with text using insertText or update_text.

Use view_slide() to verify the visual appearance!"""


@server.tool()
@handle_http_errors("duplicate_slide", service_type="slides")
@require_google_service("slides", "slides")
async def duplicate_slide(
    service,
    user_google_email: str,
    presentation_id: str,
    source_slide_id: Optional[str] = None,
    source_slide_index: Optional[int] = None,
    insert_at: Optional[int] = None,
) -> str:
    """
    Duplicate (copy) a slide within the presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        source_slide_id (str, optional): The ID of the slide to copy.
        source_slide_index (int, optional): 0-based index of the slide to copy.
            Either source_slide_id or source_slide_index must be provided.
        insert_at (int, optional): 0-based index where to insert the copy.
            If not specified, inserts right after the source slide.

    Returns:
        str: Details about the duplicated slide including its new ID.

    Examples:
        # Copy slide and insert right after it
        duplicate_slide(presentation_id="abc123", source_slide_index=0)

        # Copy slide and insert at the beginning
        duplicate_slide(presentation_id="abc123", source_slide_id="p", insert_at=0)

        # Copy slide 2 and insert at end
        duplicate_slide(presentation_id="abc123", source_slide_index=1, insert_at=999)
    """
    logger.info(
        f"[duplicate_slide] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}', Source ID: {source_slide_id}, "
        f"Source Index: {source_slide_index}, Insert At: {insert_at}"
    )

    if source_slide_id is None and source_slide_index is None:
        return "Error: Either source_slide_id or source_slide_index must be provided."

    # Get presentation to resolve IDs and determine insert position
    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )
    slides = presentation.get("slides", [])

    source_id = source_slide_id
    source_idx = source_slide_index

    # Resolve source slide
    if source_slide_index is not None:
        if source_slide_index < 0 or source_slide_index >= len(slides):
            return f"Error: source_slide_index {source_slide_index} is out of range. Presentation has {len(slides)} slides."
        source_id = slides[source_slide_index].get("objectId")
        source_idx = source_slide_index
    else:
        # Find the index of the source slide
        for i, slide in enumerate(slides):
            if slide.get("objectId") == source_slide_id:
                source_idx = i
                break

    # Generate new ID for the duplicate
    new_slide_id = generate_object_id("slide")

    # Build object ID mapping (slide + all its elements)
    object_ids = {source_id: new_slide_id}

    # Get elements on the source slide to map their IDs too
    for slide in slides:
        if slide.get("objectId") == source_id:
            for element in slide.get("pageElements", []):
                old_id = element.get("objectId")
                if old_id:
                    object_ids[old_id] = generate_object_id("elem")
            break

    # Build duplicate request
    duplicate_request: Dict[str, Any] = {
        "objectId": source_id,
        "objectIds": object_ids,
    }

    body = {"requests": [{"duplicateObject": duplicate_request}]}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    # Move to target position if specified
    final_position = source_idx + 1 if source_idx is not None else len(slides)

    if insert_at is not None:
        # Clamp to valid range
        insert_at = max(0, min(insert_at, len(slides)))

        if insert_at != final_position:
            move_body = {
                "requests": [
                    {
                        "updateSlidesPosition": {
                            "slideObjectIds": [new_slide_id],
                            "insertionIndex": insert_at,
                        }
                    }
                ]
            }
            await asyncio.to_thread(
                service.presentations()
                .batchUpdate(presentationId=presentation_id, body=move_body)
                .execute
            )
            final_position = insert_at

    return f"""Slide Duplicated Successfully:
- Presentation ID: {presentation_id}
- Source Slide ID: {source_id}
- New Slide ID: {new_slide_id}
- Position: {final_position}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("add_text_box", service_type="slides")
@require_google_service("slides", "slides")
async def add_text_box(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: str,
    text: str,
    position: str = "center",
    x_inches: Optional[float] = None,
    y_inches: Optional[float] = None,
    width_inches: float = 8.0,
    height_inches: float = 1.0,
    font_size: Optional[int] = None,
    bold: bool = False,
    font_color: Optional[str] = None,
) -> str:
    """
    Add a text box to a slide.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str): The ID of the slide to add the text box to.
        text (str): The text content for the text box.
        position (str): Named position - 'center', 'top-left', 'top-center',
            'top-right', 'middle-left', 'middle-right', 'bottom-left',
            'bottom-center', 'bottom-right'. Default is 'center'.
            Ignored if x_inches and y_inches are provided.
        x_inches (float, optional): X position in inches from left edge.
        y_inches (float, optional): Y position in inches from top edge.
        width_inches (float): Width of text box in inches. Default 8.0.
        height_inches (float): Height of text box in inches. Default 1.0.
        font_size (int, optional): Font size in points. If not specified, uses default.
        bold (bool): Whether to make text bold. Default False.
        font_color (str, optional): Text color as hex code (e.g., "#FFFFFF" for white,
            "#000000" for black). Critical for dark backgrounds - use white text!

    Returns:
        str: Details about the created text box.

    ⚠️ VISUAL DESIGN TIP: For dark backgrounds, set font_color="#FFFFFF" (white).
    Use view_slide() to verify text is visible against the background!

    Examples:
        # Add centered text
        add_text_box(presentation_id="abc", slide_id="p", text="Hello World")

        # Add white text on dark background
        add_text_box(presentation_id="abc", slide_id="p", text="Title",
                    position="top-left", font_size=32, bold=True, font_color="#FFFFFF")

        # Add text at specific position
        add_text_box(presentation_id="abc", slide_id="p", text="Custom",
                    x_inches=1.0, y_inches=2.5, width_inches=4.0)
    """
    logger.info(
        f"[add_text_box] Invoked. Email: '{user_google_email}', "
        f"Slide: '{slide_id}', Position: {position}"
    )

    # Convert dimensions to EMU
    width_emu = inches_to_emu(width_inches)
    height_emu = inches_to_emu(height_inches)

    # Calculate position
    if x_inches is not None and y_inches is not None:
        x_emu = inches_to_emu(x_inches)
        y_emu = inches_to_emu(y_inches)
    else:
        x_emu, y_emu = calculate_position(position, width_emu, height_emu)

    # Generate object ID
    text_box_id = generate_object_id("textbox")

    # Build requests
    requests: List[Dict[str, Any]] = [
        {
            "createShape": {
                "objectId": text_box_id,
                "shapeType": "TEXT_BOX",
                "elementProperties": create_element_properties(
                    slide_id, width_emu, height_emu, x_emu, y_emu
                ),
            }
        },
        {"insertText": {"objectId": text_box_id, "text": text, "insertionIndex": 0}},
    ]

    # Add formatting if specified
    if font_size or bold or font_color:
        from gslides.slides_helpers import hex_to_slides_color

        style: Dict[str, Any] = {}
        fields = []

        if font_size:
            style["fontSize"] = {"magnitude": font_size, "unit": "PT"}
            fields.append("fontSize")

        if bold:
            style["bold"] = True
            fields.append("bold")

        if font_color:
            style["foregroundColor"] = {"opaqueColor": hex_to_slides_color(font_color)}
            fields.append("foregroundColor")

        requests.append(
            {
                "updateTextStyle": {
                    "objectId": text_box_id,
                    "textRange": {"type": "ALL"},
                    "style": style,
                    "fields": ",".join(fields),
                }
            }
        )

    # Execute requests
    body = {"requests": requests}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    return f"""Text Box Created Successfully:
- Presentation ID: {presentation_id}
- Slide ID: {slide_id}
- Text Box ID: {text_box_id}
- Position: {position if x_inches is None else f"({x_inches}, {y_inches}) inches"}
- Size: {width_inches} x {height_inches} inches
- Text: "{text[:50]}{"..." if len(text) > 50 else ""}"
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("add_image", service_type="slides")
@require_google_service("slides", "slides")
async def add_image(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: str,
    image_url: str,
    position: str = "center",
    x_inches: Optional[float] = None,
    y_inches: Optional[float] = None,
    width_inches: float = 4.0,
    height_inches: float = 3.0,
) -> str:
    """
    Add an image to a slide from a URL.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str): The ID of the slide to add the image to.
        image_url (str): URL of the image to insert. Must be publicly accessible.
        position (str): Named position - 'center', 'top-left', 'top-center',
            'top-right', 'middle-left', 'middle-right', 'bottom-left',
            'bottom-center', 'bottom-right'. Default is 'center'.
        x_inches (float, optional): X position in inches from left edge.
        y_inches (float, optional): Y position in inches from top edge.
        width_inches (float): Width of image in inches. Default 4.0.
        height_inches (float): Height of image in inches. Default 3.0.

    Returns:
        str: Details about the inserted image.

    Examples:
        # Add centered image
        add_image(presentation_id="abc", slide_id="p",
                 image_url="https://example.com/image.png")

        # Add image in specific position
        add_image(presentation_id="abc", slide_id="p",
                 image_url="https://example.com/logo.png",
                 position="top-right", width_inches=2.0, height_inches=1.0)
    """
    logger.info(
        f"[add_image] Invoked. Email: '{user_google_email}', "
        f"Slide: '{slide_id}', URL: '{image_url[:50]}...'"
    )

    # Convert dimensions to EMU
    width_emu = inches_to_emu(width_inches)
    height_emu = inches_to_emu(height_inches)

    # Calculate position
    if x_inches is not None and y_inches is not None:
        x_emu = inches_to_emu(x_inches)
        y_emu = inches_to_emu(y_inches)
    else:
        x_emu, y_emu = calculate_position(position, width_emu, height_emu)

    # Generate object ID
    image_id = generate_object_id("image")

    # Build request
    request = {
        "createImage": {
            "objectId": image_id,
            "url": image_url,
            "elementProperties": create_element_properties(
                slide_id, width_emu, height_emu, x_emu, y_emu
            ),
        }
    }

    body = {"requests": [request]}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    return f"""Image Added Successfully:
- Presentation ID: {presentation_id}
- Slide ID: {slide_id}
- Image ID: {image_id}
- Source URL: {image_url}
- Position: {position if x_inches is None else f"({x_inches}, {y_inches}) inches"}
- Size: {width_inches} x {height_inches} inches
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("list_layouts", is_read_only=True, service_type="slides")
@require_google_service("slides", "slides_read")
async def list_layouts(
    service,
    user_google_email: str,
    presentation_id: str,
) -> str:
    """
    List all available slide layouts in a presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.

    Returns:
        str: List of available layouts with their IDs and names.

    Note:
        Use the layout ID or name with add_slide to create slides with specific layouts.
    """
    logger.info(
        f"[list_layouts] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}'"
    )

    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )

    layouts = presentation.get("layouts", [])

    layout_info = []
    for layout in layouts:
        layout_id = layout.get("objectId", "Unknown")
        props = layout.get("layoutProperties", {})
        name = props.get("name", "Unknown")
        display_name = props.get("displayName", name)

        layout_info.append(
            f"  - ID: {layout_id}, Name: {name}, Display: {display_name}"
        )

    return f"""Available Layouts for Presentation {presentation_id}:
- Total Layouts: {len(layouts)}

Layouts:
{chr(10).join(layout_info) if layout_info else "  No layouts found"}

Usage: Use the ID or Name with add_slide(layout="...")"""


@server.tool()
@handle_http_errors("get_slide_details", is_read_only=True, service_type="slides")
@require_google_service("slides", "slides_read")
async def get_slide_details(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: Optional[str] = None,
    slide_index: Optional[int] = None,
) -> str:
    """
    Get detailed information about a specific slide including all elements.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str, optional): The ID of the slide.
        slide_index (int, optional): 0-based index of the slide.
            Either slide_id or slide_index must be provided.

    Returns:
        str: Detailed information about the slide and all its elements.

    ⚠️ VISUAL DESIGN TIP: This returns positions, sizes, and text content, but NOT
    colors, fonts, or background styling. To see the ACTUAL VISUAL APPEARANCE, use:
        view_slide(presentation_id, slide_index=N)
    then read_file() the image to compare source and target slides visually.
    Visual design (colors, backgrounds, fonts) is as important as content!

    Examples:
        get_slide_details(presentation_id="abc", slide_id="p")
        get_slide_details(presentation_id="abc", slide_index=0)
    """
    logger.info(
        f"[get_slide_details] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}', Slide ID: {slide_id}, Index: {slide_index}"
    )

    if slide_id is None and slide_index is None:
        return "Error: Either slide_id or slide_index must be provided."

    # Get full presentation data
    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )

    slides = presentation.get("slides", [])

    # Find the target slide
    target_slide = None
    target_idx = slide_index

    if slide_index is not None:
        if slide_index < 0 or slide_index >= len(slides):
            return f"Error: slide_index {slide_index} is out of range. Presentation has {len(slides)} slides."
        target_slide = slides[slide_index]
    else:
        for i, slide in enumerate(slides):
            if slide.get("objectId") == slide_id:
                target_slide = slide
                target_idx = i
                break

    if not target_slide:
        return f"Error: Slide with ID '{slide_id}' not found."

    actual_slide_id = target_slide.get("objectId", "Unknown")

    # Collect element details
    elements_info = []
    for element in target_slide.get("pageElements", []):
        elem_id = element.get("objectId", "Unknown")
        elem_type = get_element_type(element)
        bounds = get_element_bounds(element)

        # Build element info string
        info_parts = [f"    - ID: {elem_id}", f"      Type: {elem_type}"]

        if bounds:
            info_parts.append(
                f"      Position: ({bounds['x_inches']:.2f}, {bounds['y_inches']:.2f}) inches"
            )
            info_parts.append(
                f"      Size: {bounds['width_inches']:.2f} x {bounds['height_inches']:.2f} inches"
            )

        # Extract text content if it's a shape
        if "shape" in element:
            text = extract_text_from_shape(element["shape"])
            if text:
                # Truncate long text
                display_text = text[:100] + "..." if len(text) > 100 else text
                display_text = display_text.replace("\n", "\\n")
                info_parts.append(f'      Text: "{display_text}"')

        # Table info
        if "table" in element:
            table = element["table"]
            rows = table.get("rows", 0)
            cols = table.get("columns", 0)
            info_parts.append(f"      Dimensions: {rows} rows x {cols} columns")

        # Image info
        if "image" in element:
            image = element["image"]
            source_url = image.get("sourceUrl", "")
            if source_url:
                info_parts.append(f"      Source: {source_url[:80]}...")

        elements_info.append("\n".join(info_parts))

    # Check for speaker notes
    notes_info = ""
    notes_page = target_slide.get("slideProperties", {}).get("notesPage", {})
    if notes_page:
        notes_props = notes_page.get("notesProperties", {})
        notes_shape_id = notes_props.get("speakerNotesObjectId", "")
        if notes_shape_id:
            # Find the notes shape and extract text
            for elem in notes_page.get("pageElements", []):
                if elem.get("objectId") == notes_shape_id:
                    if "shape" in elem:
                        notes_text = extract_text_from_shape(elem["shape"])
                        if notes_text:
                            notes_info = f"\nSpeaker Notes:\n  {notes_text[:200]}{'...' if len(notes_text) > 200 else ''}"
                    break

    return f"""Slide Details:
- Presentation ID: {presentation_id}
- Slide ID: {actual_slide_id}
- Slide Index: {target_idx}
- Total Elements: {len(target_slide.get("pageElements", []))}

Elements:
{chr(10).join(elements_info) if elements_info else "  No elements on this slide"}
{notes_info}
URL: https://docs.google.com/presentation/d/{presentation_id}/edit#slide=id.{actual_slide_id}"""


@server.tool()
@handle_http_errors("add_shape", service_type="slides")
@require_google_service("slides", "slides")
async def add_shape(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: str,
    shape_type: str = "RECTANGLE",
    position: str = "center",
    x_inches: Optional[float] = None,
    y_inches: Optional[float] = None,
    width_inches: float = 2.0,
    height_inches: float = 2.0,
    fill_color: Optional[str] = None,
    outline_color: Optional[str] = None,
    text: Optional[str] = None,
) -> str:
    """
    Add a shape to a slide.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str): The ID of the slide to add the shape to.
        shape_type (str): Type of shape. Options include:
            - RECTANGLE, ROUND_RECTANGLE, ELLIPSE
            - TRIANGLE, RIGHT_TRIANGLE, PARALLELOGRAM
            - TRAPEZOID, PENTAGON, HEXAGON
            - ARROW_EAST, ARROW_NORTH, ARROW_WEST, ARROW_SOUTH
            - STAR_4, STAR_5, STAR_6, STAR_8
            - HEART, CLOUD, LIGHTNING_BOLT
            - Plus many more. Default is RECTANGLE.
        position (str): Named position - 'center', 'top-left', etc.
        x_inches (float, optional): X position in inches.
        y_inches (float, optional): Y position in inches.
        width_inches (float): Width in inches. Default 2.0.
        height_inches (float): Height in inches. Default 2.0.
        fill_color (str, optional): Fill color as hex (e.g., "#FF0000") or None for no fill.
        outline_color (str, optional): Outline color as hex.
        text (str, optional): Text to place inside the shape.

    Returns:
        str: Details about the created shape.

    Examples:
        # Add a blue rectangle
        add_shape(presentation_id="abc", slide_id="p", shape_type="RECTANGLE",
                 fill_color="#0000FF")

        # Add an arrow pointing right
        add_shape(presentation_id="abc", slide_id="p", shape_type="ARROW_EAST",
                 position="middle-right", width_inches=1.5, height_inches=0.5)

        # Add a circle with text
        add_shape(presentation_id="abc", slide_id="p", shape_type="ELLIPSE",
                 text="Click Here", fill_color="#00FF00")
    """
    from gslides.slides_helpers import hex_to_slides_color

    logger.info(
        f"[add_shape] Invoked. Email: '{user_google_email}', "
        f"Slide: '{slide_id}', Shape: {shape_type}"
    )

    # Convert dimensions to EMU
    width_emu = inches_to_emu(width_inches)
    height_emu = inches_to_emu(height_inches)

    # Calculate position
    if x_inches is not None and y_inches is not None:
        x_emu = inches_to_emu(x_inches)
        y_emu = inches_to_emu(y_inches)
    else:
        x_emu, y_emu = calculate_position(position, width_emu, height_emu)

    # Generate object ID
    shape_id = generate_object_id("shape")

    # Build requests
    requests: List[Dict[str, Any]] = [
        {
            "createShape": {
                "objectId": shape_id,
                "shapeType": shape_type.upper(),
                "elementProperties": create_element_properties(
                    slide_id, width_emu, height_emu, x_emu, y_emu
                ),
            }
        }
    ]

    # Add fill color if specified
    if fill_color:
        color = hex_to_slides_color(fill_color)
        requests.append(
            {
                "updateShapeProperties": {
                    "objectId": shape_id,
                    "shapeProperties": {
                        "shapeBackgroundFill": {"solidFill": {"color": color}}
                    },
                    "fields": "shapeBackgroundFill.solidFill.color",
                }
            }
        )

    # Add outline color if specified
    if outline_color:
        color = hex_to_slides_color(outline_color)
        requests.append(
            {
                "updateShapeProperties": {
                    "objectId": shape_id,
                    "shapeProperties": {
                        "outline": {"outlineFill": {"solidFill": {"color": color}}}
                    },
                    "fields": "outline.outlineFill.solidFill.color",
                }
            }
        )

    # Add text if specified
    if text:
        requests.append(
            {"insertText": {"objectId": shape_id, "text": text, "insertionIndex": 0}}
        )

    # Execute requests
    body = {"requests": requests}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    return f"""Shape Created Successfully:
- Presentation ID: {presentation_id}
- Slide ID: {slide_id}
- Shape ID: {shape_id}
- Shape Type: {shape_type}
- Position: {position if x_inches is None else f"({x_inches}, {y_inches}) inches"}
- Size: {width_inches} x {height_inches} inches
- Fill Color: {fill_color or "default"}
- Text: {f'"{text}"' if text else "none"}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("reorder_slides", service_type="slides")
@require_google_service("slides", "slides")
async def reorder_slides(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_ids: Optional[List[str]] = None,
    slide_indexes: Optional[List[int]] = None,
    insert_at: int = 0,
) -> str:
    """
    Move one or more slides to a new position in the presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_ids (List[str], optional): List of slide IDs to move.
        slide_indexes (List[int], optional): List of slide indexes (0-based) to move.
            Either slide_ids or slide_indexes must be provided.
        insert_at (int): The 0-based index where the slides should be inserted.
            Default is 0 (beginning of presentation).

    Returns:
        str: Confirmation of the reordering.

    Examples:
        # Move slide at index 3 to the beginning
        reorder_slides(presentation_id="abc", slide_indexes=[3], insert_at=0)

        # Move multiple slides to position 2
        reorder_slides(presentation_id="abc", slide_ids=["p", "slide2"], insert_at=2)
    """
    import json as json_lib

    logger.info(
        f"[reorder_slides] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}', Insert at: {insert_at}"
    )

    # Handle string input from CLI (JSON parsing for Optional types)
    if isinstance(slide_ids, str):
        try:
            slide_ids = json_lib.loads(slide_ids)
        except json_lib.JSONDecodeError:
            slide_ids = [slide_ids]  # Treat as single ID

    if isinstance(slide_indexes, str):
        try:
            slide_indexes = json_lib.loads(slide_indexes)
        except json_lib.JSONDecodeError:
            slide_indexes = [int(slide_indexes)]  # Treat as single index

    if slide_ids is None and slide_indexes is None:
        return "Error: Either slide_ids or slide_indexes must be provided."

    target_ids = slide_ids

    # Convert indexes to IDs if needed
    if slide_indexes is not None:
        presentation = await asyncio.to_thread(
            service.presentations().get(presentationId=presentation_id).execute
        )
        slides = presentation.get("slides", [])

        target_ids = []
        for idx in slide_indexes:
            if idx < 0 or idx >= len(slides):
                return f"Error: slide_index {idx} is out of range. Presentation has {len(slides)} slides."
            target_ids.append(slides[idx].get("objectId"))

    # Execute reorder
    body = {
        "requests": [
            {
                "updateSlidesPosition": {
                    "slideObjectIds": target_ids,
                    "insertionIndex": insert_at,
                }
            }
        ]
    }

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    return f"""Slides Reordered Successfully:
- Presentation ID: {presentation_id}
- Slides Moved: {target_ids}
- New Position: {insert_at}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("add_speaker_notes", service_type="slides")
@require_google_service("slides", "slides")
async def add_speaker_notes(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: Optional[str] = None,
    slide_index: Optional[int] = None,
    notes: str = "",
    append: bool = False,
) -> str:
    """
    Add or replace speaker notes on a slide.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str, optional): The ID of the slide.
        slide_index (int, optional): 0-based index of the slide.
            Either slide_id or slide_index must be provided.
        notes (str): The speaker notes text to add.
        append (bool): If True, append to existing notes. If False (default),
            replace existing notes.

    Returns:
        str: Confirmation of the speaker notes update.

    Examples:
        # Add notes to first slide
        add_speaker_notes(presentation_id="abc", slide_index=0,
                         notes="Remember to mention the Q4 results")

        # Append to existing notes
        add_speaker_notes(presentation_id="abc", slide_id="p",
                         notes="\\n- Additional point", append=True)
    """
    logger.info(
        f"[add_speaker_notes] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}', Slide ID: {slide_id}, Index: {slide_index}"
    )

    if slide_id is None and slide_index is None:
        return "Error: Either slide_id or slide_index must be provided."

    # Get presentation to find the speaker notes shape ID
    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )
    slides = presentation.get("slides", [])

    # Find target slide
    target_slide = None
    if slide_index is not None:
        if slide_index < 0 or slide_index >= len(slides):
            return f"Error: slide_index {slide_index} is out of range."
        target_slide = slides[slide_index]
    else:
        for slide in slides:
            if slide.get("objectId") == slide_id:
                target_slide = slide
                break

    if not target_slide:
        return "Error: Slide not found."

    actual_slide_id = target_slide.get("objectId")

    # Get speaker notes shape ID
    notes_page = target_slide.get("slideProperties", {}).get("notesPage", {})
    notes_props = notes_page.get("notesProperties", {})
    notes_shape_id = notes_props.get("speakerNotesObjectId", "")

    if not notes_shape_id:
        return "Error: Could not find speaker notes shape for this slide."

    requests: List[Dict[str, Any]] = []

    # If not appending, delete existing text first
    if not append:
        # Get current text length to delete it
        for elem in notes_page.get("pageElements", []):
            if elem.get("objectId") == notes_shape_id:
                if "shape" in elem:
                    existing_text = extract_text_from_shape(elem["shape"])
                    if existing_text:
                        requests.append(
                            {
                                "deleteText": {
                                    "objectId": notes_shape_id,
                                    "textRange": {"type": "ALL"},
                                }
                            }
                        )
                break

    # Insert new notes
    requests.append(
        {"insertText": {"objectId": notes_shape_id, "text": notes, "insertionIndex": 0}}
    )

    # Execute requests
    body = {"requests": requests}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    action = "appended to" if append else "set on"
    return f"""Speaker Notes Updated Successfully:
- Presentation ID: {presentation_id}
- Slide ID: {actual_slide_id}
- Action: Notes {action} slide
- Notes Preview: "{notes[:100]}{"..." if len(notes) > 100 else ""}"
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("add_table", service_type="slides")
@require_google_service("slides", "slides")
async def add_table(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: str,
    rows: int,
    columns: int,
    data: Optional[List[List[str]]] = None,
    position: str = "center",
    x_inches: Optional[float] = None,
    y_inches: Optional[float] = None,
    width_inches: float = 8.0,
    height_inches: float = 3.0,
) -> str:
    """
    Add a table to a slide, optionally with data.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str): The ID of the slide to add the table to.
        rows (int): Number of rows in the table.
        columns (int): Number of columns in the table.
        data (List[List[str]], optional): 2D list of data to populate the table.
            First row can be headers. Example: [["Name", "Age"], ["Alice", "30"]]
        position (str): Named position - 'center', 'top-left', etc.
        x_inches (float, optional): X position in inches.
        y_inches (float, optional): Y position in inches.
        width_inches (float): Width in inches. Default 8.0.
        height_inches (float): Height in inches. Default 3.0.

    Returns:
        str: Details about the created table.

    Examples:
        # Create empty 3x4 table
        add_table(presentation_id="abc", slide_id="p", rows=3, columns=4)

        # Create table with data
        add_table(presentation_id="abc", slide_id="p", rows=2, columns=3,
                 data=[["Name", "Role", "Team"],
                       ["Alice", "Engineer", "Platform"]])
    """
    import json as json_lib

    logger.info(
        f"[add_table] Invoked. Email: '{user_google_email}', "
        f"Slide: '{slide_id}', Size: {rows}x{columns}"
    )

    # Handle string input from CLI (JSON parsing for Optional types)
    if isinstance(data, str):
        try:
            data = json_lib.loads(data)
        except json_lib.JSONDecodeError:
            data = None

    # Convert dimensions to EMU
    width_emu = inches_to_emu(width_inches)
    height_emu = inches_to_emu(height_inches)

    # Calculate position
    if x_inches is not None and y_inches is not None:
        x_emu = inches_to_emu(x_inches)
        y_emu = inches_to_emu(y_inches)
    else:
        x_emu, y_emu = calculate_position(position, width_emu, height_emu)

    # Generate object ID
    table_id = generate_object_id("table")

    # Build requests
    requests: List[Dict[str, Any]] = [
        {
            "createTable": {
                "objectId": table_id,
                "elementProperties": {
                    "pageObjectId": slide_id,
                    "transform": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "translateX": x_emu,
                        "translateY": y_emu,
                        "unit": "EMU",
                    },
                },
                "rows": rows,
                "columns": columns,
            }
        }
    ]

    # Add data if provided
    if data:
        for row_idx, row_data in enumerate(data):
            if row_idx >= rows:
                break
            for col_idx, cell_text in enumerate(row_data):
                if col_idx >= columns:
                    break
                if cell_text:  # Only add if there's text
                    requests.append(
                        {
                            "insertText": {
                                "objectId": table_id,
                                "cellLocation": {
                                    "rowIndex": row_idx,
                                    "columnIndex": col_idx,
                                },
                                "text": str(cell_text),
                                "insertionIndex": 0,
                            }
                        }
                    )

    # Execute requests
    body = {"requests": requests}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    data_info = f"{len(data)} rows of data" if data else "empty"
    return f"""Table Created Successfully:
- Presentation ID: {presentation_id}
- Slide ID: {slide_id}
- Table ID: {table_id}
- Dimensions: {rows} rows x {columns} columns
- Data: {data_info}
- Position: {position if x_inches is None else f"({x_inches}, {y_inches}) inches"}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("move_element", service_type="slides")
@require_google_service("slides", "slides")
async def move_element(
    service,
    user_google_email: str,
    presentation_id: str,
    element_id: str,
    x_inches: Optional[float] = None,
    y_inches: Optional[float] = None,
) -> str:
    """
    Move an element to a new position on the slide.

    Use this to match element positions when duplicating slides. The positions
    from layout placeholders may differ from manually positioned elements.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        element_id (str): The ID of the element to move.
        x_inches (float, optional): New X position in inches from left edge.
        y_inches (float, optional): New Y position in inches from top edge.
            At least one of x_inches or y_inches must be provided.

    Returns:
        str: Confirmation of the move.

    Examples:
        # Move element to specific Y position (keep X the same)
        move_element(element_id="title", y_inches=2.30)

        # Move element to specific position
        move_element(element_id="textbox", x_inches=0.5, y_inches=3.0)
    """
    logger.info(
        f"[move_element] Invoked. Email: '{user_google_email}', "
        f"Element: '{element_id}', X: {x_inches}, Y: {y_inches}"
    )

    if x_inches is None and y_inches is None:
        return "Error: At least one of x_inches or y_inches must be provided."

    # Get current element to preserve unchanged values
    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )

    # Find the element
    element = None
    for slide in presentation.get("slides", []):
        for elem in slide.get("pageElements", []):
            if elem.get("objectId") == element_id:
                element = elem
                break
        if element:
            break

    if not element:
        return f"Error: Element '{element_id}' not found."

    current_transform = element.get("transform", {})
    current_x = current_transform.get("translateX", 0)
    current_y = current_transform.get("translateY", 0)
    scale_x = current_transform.get("scaleX", 1)
    scale_y = current_transform.get("scaleY", 1)

    # Calculate new position
    new_x = inches_to_emu(x_inches) if x_inches is not None else current_x
    new_y = inches_to_emu(y_inches) if y_inches is not None else current_y

    # Build the request
    request = {
        "updatePageElementTransform": {
            "objectId": element_id,
            "transform": {
                "scaleX": scale_x,
                "scaleY": scale_y,
                "translateX": new_x,
                "translateY": new_y,
                "unit": "EMU",
            },
            "applyMode": "ABSOLUTE",
        }
    }

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body={"requests": [request]})
        .execute
    )

    return f"""Element Moved Successfully:
- Presentation ID: {presentation_id}
- Element ID: {element_id}
- New Position: ({x_inches if x_inches else "unchanged"}, {y_inches if y_inches else "unchanged"}) inches
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("format_text", service_type="slides")
@require_google_service("slides", "slides")
async def format_text(
    service,
    user_google_email: str,
    presentation_id: str,
    element_id: str,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
    underline: Optional[bool] = None,
    font_size: Optional[int] = None,
    font_color: Optional[str] = None,
    font_family: Optional[str] = None,
    start_index: Optional[int] = None,
    end_index: Optional[int] = None,
) -> str:
    """
    Apply formatting to text in a shape or text box.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        element_id (str): The ID of the shape/text box to format.
        bold (bool, optional): Set text bold.
        italic (bool, optional): Set text italic.
        underline (bool, optional): Set text underlined.
        font_size (int, optional): Font size in points.
        font_color (str, optional): Text color as hex (e.g., "#FF0000").
        font_family (str, optional): Font family name (e.g., "Arial", "Roboto").
        start_index (int, optional): Start index of text to format (0-based).
        end_index (int, optional): End index of text to format.
            If start_index and end_index are not provided, formats all text.

    Returns:
        str: Confirmation of the formatting applied.

    Examples:
        # Make all text bold and larger
        format_text(presentation_id="abc", element_id="textbox_123",
                   bold=True, font_size=24)

        # Make specific text red
        format_text(presentation_id="abc", element_id="textbox_123",
                   font_color="#FF0000", start_index=0, end_index=5)

        # Change font family
        format_text(presentation_id="abc", element_id="shape_456",
                   font_family="Georgia", italic=True)
    """
    from gslides.slides_helpers import hex_to_slides_color

    logger.info(
        f"[format_text] Invoked. Email: '{user_google_email}', Element: '{element_id}'"
    )

    # Build style and fields
    style: Dict[str, Any] = {}
    fields = []

    if bold is not None:
        style["bold"] = bold
        fields.append("bold")

    if italic is not None:
        style["italic"] = italic
        fields.append("italic")

    if underline is not None:
        style["underline"] = underline
        fields.append("underline")

    if font_size is not None:
        style["fontSize"] = {"magnitude": font_size, "unit": "PT"}
        fields.append("fontSize")

    if font_color is not None:
        style["foregroundColor"] = {"opaqueColor": hex_to_slides_color(font_color)}
        fields.append("foregroundColor")

    if font_family is not None:
        style["fontFamily"] = font_family
        fields.append("fontFamily")

    if not fields:
        return "Error: No formatting options specified."

    # Build text range
    text_range: Dict[str, Any] = {"type": "ALL"}
    if start_index is not None and end_index is not None:
        text_range = {
            "type": "FIXED_RANGE",
            "startIndex": start_index,
            "endIndex": end_index,
        }

    # Build request
    request = {
        "updateTextStyle": {
            "objectId": element_id,
            "textRange": text_range,
            "style": style,
            "fields": ",".join(fields),
        }
    }

    body = {"requests": [request]}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    formatting_applied = ", ".join(fields)
    range_info = (
        "all text"
        if text_range["type"] == "ALL"
        else f"characters {start_index}-{end_index}"
    )

    return f"""Text Formatted Successfully:
- Presentation ID: {presentation_id}
- Element ID: {element_id}
- Formatting Applied: {formatting_applied}
- Range: {range_info}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors(
    "get_effective_text_style", is_read_only=True, service_type="slides"
)
@require_google_service("slides", "slides_read")
async def get_effective_text_style(
    service,
    user_google_email: str,
    presentation_id: str,
    element_id: str,
) -> str:
    """
    Get the COMPLETE effective text style for an element, resolving all inheritance.

    This is CRITICAL for understanding what styling is actually being rendered.
    The Google Slides API often returns None for styles that are inherited from
    placeholders, layouts, masters, or themes. This tool resolves the full
    inheritance chain to show you the actual rendered values.

    Use this tool to:
    - Understand what fonts/colors are actually being used
    - Copy styles from one element to another
    - Debug why text looks different than expected
    - Know what styling to apply when creating new content

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        element_id (str): The ID of the shape/text box to analyze.

    Returns:
        str: Complete style information including:
            - font_family: The font being used (e.g., "Noto Sans")
            - font_weight: Weight 100-900 (300=light, 400=normal, 700=bold)
            - font_size_pt: Size in points
            - font_color: Hex color or theme reference
            - bold, italic, underline: Text decorations
            - line_spacing: Percentage (100 = single space)

    ⚠️ IMPORTANT: When duplicating or recreating content, ALWAYS use this tool
    to get the source element's effective style, then apply those values to
    your new content using insert_text_with_style or format_text.

    Examples:
        # Check what font a title is using
        get_effective_text_style(presentation_id="abc", element_id="title_123")
        # Returns: font_family="Noto Sans", font_weight=300, font_size_pt=48, ...

        # Then use those values when creating new content:
        insert_text_with_style(..., font_family="Noto Sans", font_weight=300, ...)
    """
    logger.info(
        f"[get_effective_text_style] Invoked. Email: '{user_google_email}', "
        f"Element: '{element_id}'"
    )

    # Get the full presentation to resolve inheritance
    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )

    # Find the element
    element = None
    for slide in presentation.get("slides", []):
        for elem in slide.get("pageElements", []):
            if elem.get("objectId") == element_id:
                element = elem
                break
        if element:
            break

    if not element:
        return f"Error: Element '{element_id}' not found in presentation."

    if "shape" not in element:
        return f"Error: Element '{element_id}' is not a text shape."

    # Resolve effective style
    style = resolve_effective_text_style(presentation, element)

    # Also get the text content for context
    text_content = extract_text_from_shape(element.get("shape", {}))

    # Get placeholder info if any
    placeholder = element.get("shape", {}).get("placeholder", {})
    ph_type = placeholder.get("type", "None")
    ph_parent = placeholder.get("parentObjectId", "None")

    return f"""Effective Text Style for Element:
- Presentation ID: {presentation_id}
- Element ID: {element_id}
- Text Content: {repr(text_content[:50])}{"..." if len(text_content) > 50 else ""}
- Placeholder Type: {ph_type}
- Parent Placeholder: {ph_parent}

RESOLVED STYLE (including inheritance):
- font_family: {style["font_family"]}
- font_weight: {style["font_weight"]} (300=light, 400=normal, 700=bold)
- font_size_pt: {style["font_size_pt"]}
- font_color: {style["font_color"]}
- bold: {style["bold"]}
- italic: {style["italic"]}
- underline: {style["underline"]}
- line_spacing: {style["line_spacing"]}%

⚠️ To copy this style to another element, use:
insert_text_with_style(..., font_family="{style["font_family"]}", 
    font_weight={style["font_weight"]}, font_size_pt={style["font_size_pt"]}, 
    font_color="{style["font_color"]}")

Or use copy_style_from="{element_id}" parameter to copy automatically."""


@server.tool()
@handle_http_errors("insert_text_with_style", service_type="slides")
@require_google_service("slides", "slides")
async def insert_text_with_style(
    service,
    user_google_email: str,
    presentation_id: str,
    element_id: str,
    text: str,
    # Explicit style parameters
    font_family: Optional[str] = None,
    font_size_pt: Optional[float] = None,
    font_weight: Optional[int] = None,
    font_color: Optional[str] = None,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
    underline: Optional[bool] = None,
    line_spacing: Optional[int] = None,
    # Copy style from source
    copy_style_from: Optional[str] = None,
    copy_style_from_presentation: Optional[str] = None,
) -> str:
    """
    Insert text into an element WITH complete styling applied.

    This is the RECOMMENDED way to add text to slides. Unlike bare insertText
    which creates unstyled text, this tool ensures your text has proper
    formatting applied.

    You can either:
    1. Specify explicit style parameters (font_family, font_size_pt, etc.)
    2. Copy style from another element (copy_style_from parameter)
    3. Combine both - copy base style and override specific properties

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        element_id (str): The ID of the shape/text box to insert text into.
        text (str): The text content to insert.

        Style parameters (optional):
            font_family (str): Font name (e.g., "Noto Sans", "Arial")
            font_size_pt (float): Font size in points (e.g., 40.0)
            font_weight (int): Weight 100-900 (300=light, 400=normal, 700=bold)
            font_color (str): Hex color (e.g., "#FFFFFF" for white)
            bold (bool): Whether text should be bold
            italic (bool): Whether text should be italic
            underline (bool): Whether text should be underlined
            line_spacing (int): Line spacing percentage (100 = single)

        Copy style parameters (optional):
            copy_style_from (str): Element ID to copy style from
            copy_style_from_presentation (str): Presentation ID for copy source
                (defaults to same presentation)

    Returns:
        str: Confirmation with the applied styling.

    ⚠️ CRITICAL: Always use this tool instead of bare insertText to avoid
    creating unstyled text that doesn't match the presentation's design.

    Examples:
        # Insert text with explicit styling
        insert_text_with_style(
            presentation_id="abc", element_id="title_box",
            text="My Title",
            font_family="Noto Sans", font_size_pt=48, font_weight=300
        )

        # Copy style from another element
        insert_text_with_style(
            presentation_id="abc", element_id="new_title",
            text="Copied Style Title",
            copy_style_from="original_title"
        )

        # Copy style from different presentation
        insert_text_with_style(
            presentation_id="new_pres", element_id="title",
            text="My Title",
            copy_style_from="orig_title",
            copy_style_from_presentation="orig_pres_id"
        )

        # Copy style and override specific properties
        insert_text_with_style(
            presentation_id="abc", element_id="title",
            text="Modified Style",
            copy_style_from="original_title",
            font_size_pt=36  # Override just the size
        )
    """
    logger.info(
        f"[insert_text_with_style] Invoked. Email: '{user_google_email}', "
        f"Element: '{element_id}', Text length: {len(text)}"
    )

    # Resolve the style to apply
    final_style = {
        "font_family": font_family,
        "font_size_pt": font_size_pt,
        "font_weight": font_weight,
        "font_color": font_color,
        "bold": bold,
        "italic": italic,
        "underline": underline,
        "line_spacing": line_spacing,
    }

    # If copying style from another element, get its effective style first
    source_style_info = ""
    if copy_style_from:
        source_pres_id = copy_style_from_presentation or presentation_id

        source_presentation = await asyncio.to_thread(
            service.presentations().get(presentationId=source_pres_id).execute
        )

        # Find the source element
        source_element = None
        for slide in source_presentation.get("slides", []):
            for elem in slide.get("pageElements", []):
                if elem.get("objectId") == copy_style_from:
                    source_element = elem
                    break
            if source_element:
                break

        if not source_element:
            return f"Error: Source element '{copy_style_from}' not found."

        # Get effective style from source
        source_style = resolve_effective_text_style(source_presentation, source_element)
        source_style_info = f"\nCopied style from: {copy_style_from}"

        # Apply source style for any properties not explicitly overridden
        for key, value in source_style.items():
            if final_style.get(key) is None:
                final_style[key] = value

    # Build the requests: delete existing + insert + style
    requests: List[Dict[str, Any]] = []

    # First, get current text length to delete it
    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )

    current_text_length = 0
    for slide in presentation.get("slides", []):
        for elem in slide.get("pageElements", []):
            if elem.get("objectId") == element_id:
                current_text = extract_text_from_shape(elem.get("shape", {}))
                current_text_length = len(current_text) + 1  # +1 for newline
                break

    # Delete existing text if any
    if current_text_length > 1:
        requests.append(
            {
                "deleteText": {
                    "objectId": element_id,
                    "textRange": {"type": "ALL"},
                }
            }
        )

    # Insert new text
    requests.append(
        {
            "insertText": {
                "objectId": element_id,
                "text": text,
                "insertionIndex": 0,
            }
        }
    )

    # Apply styling
    style_requests = create_text_style_requests(
        element_id,
        font_family=final_style.get("font_family"),
        font_size_pt=final_style.get("font_size_pt"),
        font_weight=final_style.get("font_weight"),
        font_color=final_style.get("font_color"),
        bold=final_style.get("bold"),
        italic=final_style.get("italic"),
        underline=final_style.get("underline"),
        line_spacing=final_style.get("line_spacing"),
    )
    requests.extend(style_requests)

    # Execute all requests
    body = {"requests": requests}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    # Format applied styles for output
    applied_styles = []
    for key, value in final_style.items():
        if value is not None:
            applied_styles.append(f"{key}={value}")

    return f"""Text Inserted With Style Successfully:
- Presentation ID: {presentation_id}
- Element ID: {element_id}
- Text: {repr(text[:50])}{"..." if len(text) > 50 else ""}{source_style_info}

Applied Styling:
{chr(10).join(f"  - {s}" for s in applied_styles)}

- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("get_presentation_theme", is_read_only=True, service_type="slides")
@require_google_service("slides", "slides_read")
async def get_presentation_theme(
    service,
    user_google_email: str,
    presentation_id: str,
) -> str:
    """
    Get the presentation's theme information including default fonts and colors.

    Use this tool when creating NEW content to know what fonts and colors
    to use to match the presentation's design. This is especially important
    when you're not copying from an existing element.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.

    Returns:
        str: Theme information including:
            - Master slide name
            - Available layouts and their purposes
            - Common fonts used in the theme
            - Theme colors

    ⚠️ USE THIS when creating new slides/content to ensure consistency
    with the presentation's design language.

    Examples:
        # Check what fonts a presentation uses before adding content
        get_presentation_theme(presentation_id="abc123")
        # Shows: Title font = Noto Sans 300, Body font = Arial 400, etc.
    """
    logger.info(
        f"[get_presentation_theme] Invoked. Email: '{user_google_email}', "
        f"Presentation: '{presentation_id}'"
    )

    presentation = await asyncio.to_thread(
        service.presentations().get(presentationId=presentation_id).execute
    )

    output_parts = [
        "Presentation Theme Information:",
        f"- Presentation ID: {presentation_id}",
        f"- Title: {presentation.get('title', 'Untitled')}",
        "",
    ]

    # Get master info
    masters = presentation.get("masters", [])
    if masters:
        output_parts.append("MASTER SLIDES:")
        for master in masters:
            master_id = master.get("objectId")
            master_name = master.get("masterProperties", {}).get(
                "displayName", "Unnamed"
            )
            output_parts.append(f"  - {master_name} (ID: {master_id})")

            # Extract common fonts from master
            fonts_found: Dict[str, set] = {"title": set(), "body": set()}
            for elem in master.get("pageElements", [])[:10]:
                if "shape" in elem and "text" in elem["shape"]:
                    for te in elem["shape"]["text"].get("textElements", []):
                        if "textRun" in te:
                            style = te["textRun"].get("style", {})
                            wff = style.get("weightedFontFamily", {})
                            if wff.get("fontFamily"):
                                font_str = f"{wff['fontFamily']} (weight {wff.get('weight', 400)})"
                                fonts_found["body"].add(font_str)

            if fonts_found["body"]:
                output_parts.append(
                    f"    Fonts: {', '.join(list(fonts_found['body'])[:5])}"
                )
        output_parts.append("")

    # Get layouts
    layouts = presentation.get("layouts", [])
    if layouts:
        output_parts.append("AVAILABLE LAYOUTS:")
        for layout in layouts:
            props = layout.get("layoutProperties", {})
            layout_id = layout.get("objectId")
            name = props.get("name", "?")
            display = props.get("displayName", "?")
            output_parts.append(f"  - {display} (name={name}, ID={layout_id})")

            # Show placeholder types in this layout
            placeholders = []
            for elem in layout.get("pageElements", []):
                ph = elem.get("shape", {}).get("placeholder", {})
                if ph.get("type"):
                    placeholders.append(ph.get("type"))
            if placeholders:
                output_parts.append(f"    Placeholders: {', '.join(set(placeholders))}")
        output_parts.append("")

    # Recommend common patterns
    output_parts.extend(
        [
            "RECOMMENDATIONS FOR NEW CONTENT:",
            "1. Use get_effective_text_style() on an existing element to see exact fonts",
            "2. Use the same layout IDs when creating slides with add_slide(layout=...)",
            "3. Use insert_text_with_style() with copy_style_from to match existing styling",
            "",
            f"URL: https://docs.google.com/presentation/d/{presentation_id}/edit",
        ]
    )

    return "\n".join(output_parts)


@server.tool()
@handle_http_errors("update_text", service_type="slides")
@require_google_service("slides", "slides")
async def update_text(
    service,
    user_google_email: str,
    presentation_id: str,
    element_id: str,
    new_text: str,
    replace_all: bool = True,
    start_index: Optional[int] = None,
    end_index: Optional[int] = None,
) -> str:
    """
    Update or replace text in a shape or text box.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        element_id (str): The ID of the shape/text box to update.
        new_text (str): The new text content.
        replace_all (bool): If True (default), replace all existing text.
            If False, use start_index and end_index to replace a range.
        start_index (int, optional): Start index of text to replace (0-based).
            Required if replace_all is False.
        end_index (int, optional): End index of text to replace.
            Required if replace_all is False.

    Returns:
        str: Confirmation of the text update.

    Examples:
        # Replace all text in a text box
        update_text(presentation_id="abc", element_id="textbox_123",
                   new_text="New content here")

        # Replace specific range of text
        update_text(presentation_id="abc", element_id="textbox_123",
                   new_text="UPDATED", replace_all=False,
                   start_index=0, end_index=5)
    """
    logger.info(
        f"[update_text] Invoked. Email: '{user_google_email}', "
        f"Element: '{element_id}', Replace all: {replace_all}"
    )

    requests: List[Dict[str, Any]] = []

    if replace_all:
        # Delete all existing text, then insert new
        requests.append(
            {"deleteText": {"objectId": element_id, "textRange": {"type": "ALL"}}}
        )
        requests.append(
            {
                "insertText": {
                    "objectId": element_id,
                    "text": new_text,
                    "insertionIndex": 0,
                }
            }
        )
    else:
        if start_index is None or end_index is None:
            return (
                "Error: start_index and end_index required when replace_all is False."
            )

        # Delete the range, then insert
        requests.append(
            {
                "deleteText": {
                    "objectId": element_id,
                    "textRange": {
                        "type": "FIXED_RANGE",
                        "startIndex": start_index,
                        "endIndex": end_index,
                    },
                }
            }
        )
        requests.append(
            {
                "insertText": {
                    "objectId": element_id,
                    "text": new_text,
                    "insertionIndex": start_index,
                }
            }
        )

    body = {"requests": requests}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    range_info = "all text" if replace_all else f"characters {start_index}-{end_index}"
    return f"""Text Updated Successfully:
- Presentation ID: {presentation_id}
- Element ID: {element_id}
- Range: {range_info}
- New Text: "{new_text[:50]}{"..." if len(new_text) > 50 else ""}"
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("add_bullet_list", service_type="slides")
@require_google_service("slides", "slides")
async def add_bullet_list(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: str,
    items: List[str],
    list_type: str = "BULLET",
    position: str = "center",
    x_inches: Optional[float] = None,
    y_inches: Optional[float] = None,
    width_inches: float = 8.0,
    height_inches: float = 3.0,
    font_size: Optional[int] = None,
) -> str:
    """
    Add a bulleted or numbered list to a slide.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str): The ID of the slide to add the list to.
        items (List[str]): List of text items for the list.
        list_type (str): Type of list - "BULLET" or "NUMBERED". Default "BULLET".
        position (str): Named position - 'center', 'top-left', etc.
        x_inches (float, optional): X position in inches.
        y_inches (float, optional): Y position in inches.
        width_inches (float): Width in inches. Default 8.0.
        height_inches (float): Height in inches. Default 3.0.
        font_size (int, optional): Font size in points.

    Returns:
        str: Details about the created list.

    Examples:
        # Add bullet list
        add_bullet_list(presentation_id="abc", slide_id="p",
                       items=["First point", "Second point", "Third point"])

        # Add numbered list
        add_bullet_list(presentation_id="abc", slide_id="p",
                       items=["Step 1", "Step 2", "Step 3"],
                       list_type="NUMBERED", position="top-left")
    """
    import json as json_lib

    logger.info(
        f"[add_bullet_list] Invoked. Email: '{user_google_email}', "
        f"Slide: '{slide_id}', Items: {len(items) if isinstance(items, list) else 'parsing...'}"
    )

    # Handle string input from CLI
    if isinstance(items, str):
        try:
            items = json_lib.loads(items)
        except json_lib.JSONDecodeError:
            items = [items]  # Treat as single item

    if not items:
        return "Error: items list cannot be empty."

    # Convert dimensions to EMU
    width_emu = inches_to_emu(width_inches)
    height_emu = inches_to_emu(height_inches)

    # Calculate position
    if x_inches is not None and y_inches is not None:
        x_emu = inches_to_emu(x_inches)
        y_emu = inches_to_emu(y_inches)
    else:
        x_emu, y_emu = calculate_position(position, width_emu, height_emu)

    # Generate object ID
    list_box_id = generate_object_id("list")

    # Build text with newlines
    list_text = "\n".join(items)

    # Determine bullet preset
    bullet_preset = "BULLET_DISC_CIRCLE_SQUARE"
    if list_type.upper() == "NUMBERED":
        bullet_preset = "NUMBERED_DIGIT_ALPHA_ROMAN"

    # Build requests
    requests: List[Dict[str, Any]] = [
        {
            "createShape": {
                "objectId": list_box_id,
                "shapeType": "TEXT_BOX",
                "elementProperties": create_element_properties(
                    slide_id, width_emu, height_emu, x_emu, y_emu
                ),
            }
        },
        {
            "insertText": {
                "objectId": list_box_id,
                "text": list_text,
                "insertionIndex": 0,
            }
        },
        {
            "createParagraphBullets": {
                "objectId": list_box_id,
                "textRange": {"type": "ALL"},
                "bulletPreset": bullet_preset,
            }
        },
    ]

    # Add font size if specified
    if font_size:
        requests.append(
            {
                "updateTextStyle": {
                    "objectId": list_box_id,
                    "textRange": {"type": "ALL"},
                    "style": {"fontSize": {"magnitude": font_size, "unit": "PT"}},
                    "fields": "fontSize",
                }
            }
        )

    # Execute requests
    body = {"requests": requests}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    return f"""Bullet List Created Successfully:
- Presentation ID: {presentation_id}
- Slide ID: {slide_id}
- List ID: {list_box_id}
- List Type: {list_type}
- Items: {len(items)}
- Position: {position if x_inches is None else f"({x_inches}, {y_inches}) inches"}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("set_slide_background", service_type="slides")
@require_google_service("slides", "slides")
async def set_slide_background(
    service,
    user_google_email: str,
    presentation_id: str,
    slide_id: Optional[str] = None,
    slide_index: Optional[int] = None,
    color: Optional[str] = None,
    image_url: Optional[str] = None,
) -> str:
    """
    Set the background of a slide to a solid color or image.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        slide_id (str, optional): The ID of the slide.
        slide_index (int, optional): 0-based index of the slide.
            Either slide_id or slide_index must be provided.
        color (str, optional): Background color as hex (e.g., "#FF0000").
        image_url (str, optional): URL of background image.
            Either color or image_url must be provided.

    Returns:
        str: Confirmation of the background change.

    ⚠️ VISUAL DESIGN TIP: After setting the background, use view_slide() to verify
    the result. If using a dark background, remember to set text colors to white
    or light colors using format_text(font_color="#FFFFFF").

    Examples:
        # Set solid blue background
        set_slide_background(presentation_id="abc", slide_index=0, color="#0066CC")

        # Set background image
        set_slide_background(presentation_id="abc", slide_id="p",
                            image_url="https://example.com/bg.jpg")
    """
    from gslides.slides_helpers import hex_to_slides_color

    logger.info(
        f"[set_slide_background] Invoked. Email: '{user_google_email}', "
        f"Slide ID: {slide_id}, Index: {slide_index}"
    )

    if slide_id is None and slide_index is None:
        return "Error: Either slide_id or slide_index must be provided."

    if color is None and image_url is None:
        return "Error: Either color or image_url must be provided."

    target_id = slide_id

    # Look up slide ID if using index
    if slide_index is not None:
        presentation = await asyncio.to_thread(
            service.presentations().get(presentationId=presentation_id).execute
        )
        slides = presentation.get("slides", [])

        if slide_index < 0 or slide_index >= len(slides):
            return f"Error: slide_index {slide_index} is out of range."

        target_id = slides[slide_index].get("objectId")

    # Build the background fill
    if color:
        rgb_color = hex_to_slides_color(color)
        page_background_fill = {"solidFill": {"color": rgb_color}}
        fields = "pageBackgroundFill.solidFill.color"
    else:
        page_background_fill = {"stretchedPictureFill": {"contentUrl": image_url}}
        fields = "pageBackgroundFill.stretchedPictureFill.contentUrl"

    # Build request
    request = {
        "updatePageProperties": {
            "objectId": target_id,
            "pageProperties": {"pageBackgroundFill": page_background_fill},
            "fields": fields,
        }
    }

    body = {"requests": [request]}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    bg_type = f"color {color}" if color else f"image {image_url[:50]}..."
    return f"""Slide Background Updated Successfully:
- Presentation ID: {presentation_id}
- Slide ID: {target_id}
- Background: {bg_type}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("replace_all_text", service_type="slides")
@require_google_service("slides", "slides")
async def replace_all_text(
    service,
    user_google_email: str,
    presentation_id: str,
    find_text: str,
    replace_text: str,
    match_case: bool = True,
) -> str:
    """
    Find and replace text throughout the entire presentation.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        find_text (str): The text to find.
        replace_text (str): The text to replace it with.
        match_case (bool): Whether to match case. Default True.

    Returns:
        str: Confirmation of the replacement.

    Examples:
        # Replace company name throughout presentation
        replace_all_text(presentation_id="abc", find_text="Acme Corp",
                        replace_text="New Company Inc")

        # Case-insensitive replacement
        replace_all_text(presentation_id="abc", find_text="old",
                        replace_text="new", match_case=False)
    """
    logger.info(
        f"[replace_all_text] Invoked. Email: '{user_google_email}', "
        f"Find: '{find_text}', Replace: '{replace_text}'"
    )

    request = {
        "replaceAllText": {
            "containsText": {"text": find_text, "matchCase": match_case},
            "replaceText": replace_text,
        }
    }

    body = {"requests": [request]}

    result = await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    # Get number of replacements from response
    replies = result.get("replies", [])
    occurrences = 0
    if replies and "replaceAllText" in replies[0]:
        occurrences = replies[0]["replaceAllText"].get("occurrencesChanged", 0)

    return f"""Text Replaced Successfully:
- Presentation ID: {presentation_id}
- Find: "{find_text}"
- Replace: "{replace_text}"
- Match Case: {match_case}
- Occurrences Replaced: {occurrences}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("add_link", service_type="slides")
@require_google_service("slides", "slides")
async def add_link(
    service,
    user_google_email: str,
    presentation_id: str,
    element_id: str,
    url: Optional[str] = None,
    slide_id: Optional[str] = None,
    start_index: Optional[int] = None,
    end_index: Optional[int] = None,
) -> str:
    """
    Add a hyperlink to text in a shape or text box.

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation.
        element_id (str): The ID of the shape/text box containing the text.
        url (str, optional): The URL to link to (e.g., "https://example.com").
        slide_id (str, optional): ID of a slide to link to (for internal links).
            Either url or slide_id must be provided.
        start_index (int, optional): Start index of text to make into link.
        end_index (int, optional): End index of text to make into link.
            If not provided, links all text in the element.

    Returns:
        str: Confirmation of the link creation.

    Examples:
        # Link all text to a URL
        add_link(presentation_id="abc", element_id="textbox_123",
                url="https://www.google.com")

        # Link specific text range
        add_link(presentation_id="abc", element_id="textbox_123",
                url="https://example.com", start_index=0, end_index=10)

        # Link to another slide
        add_link(presentation_id="abc", element_id="textbox_123",
                slide_id="slide_456")
    """
    logger.info(
        f"[add_link] Invoked. Email: '{user_google_email}', "
        f"Element: '{element_id}', URL: {url}, Slide: {slide_id}"
    )

    if url is None and slide_id is None:
        return "Error: Either url or slide_id must be provided."

    # Build link target
    link: Dict[str, Any] = {}
    if url:
        link["url"] = url
    else:
        link["slideIndex"] = None  # Will be looked up
        link["relativeLink"] = "SLIDE"
        # For internal links, we need to use pageObjectId
        link = {"pageObjectId": slide_id}

    # Build text range
    text_range: Dict[str, Any] = {"type": "ALL"}
    if start_index is not None and end_index is not None:
        text_range = {
            "type": "FIXED_RANGE",
            "startIndex": start_index,
            "endIndex": end_index,
        }

    # Build request
    request = {
        "updateTextStyle": {
            "objectId": element_id,
            "textRange": text_range,
            "style": {"link": link},
            "fields": "link",
        }
    }

    body = {"requests": [request]}

    await asyncio.to_thread(
        service.presentations()
        .batchUpdate(presentationId=presentation_id, body=body)
        .execute
    )

    link_target = url if url else f"slide {slide_id}"
    range_info = (
        "all text"
        if text_range["type"] == "ALL"
        else f"characters {start_index}-{end_index}"
    )

    return f"""Link Added Successfully:
- Presentation ID: {presentation_id}
- Element ID: {element_id}
- Link Target: {link_target}
- Range: {range_info}
- URL: https://docs.google.com/presentation/d/{presentation_id}/edit"""


# =============================================================================
# Template and Copy Tools
# =============================================================================


@server.tool()
@handle_http_errors("copy_presentation", service_type="slides")
@require_google_service("drive", "drive_file")
async def copy_presentation(
    service,
    user_google_email: str,
    presentation_id: str,
    new_title: Optional[str] = None,
    destination_folder_id: Optional[str] = None,
) -> str:
    """
    Create a copy of an existing presentation, preserving all visual design,
    masters, layouts, themes, and content.

    ⚠️ VISUAL DESIGN: This is the BEST way to preserve exact visual styling when
    you need to duplicate a presentation. The copy will have identical:
    - Background colors/images
    - Master slide templates
    - Theme colors and fonts
    - All content, images, and formatting

    Args:
        user_google_email (str): The user's Google email address. Required.
        presentation_id (str): The ID of the presentation to copy.
        new_title (str, optional): Title for the new copy. If not provided,
            the copy will be named "Copy of [original title]".
        destination_folder_id (str, optional): ID of the folder to place the
            copy in. If not provided, copy goes to root of My Drive.

    Returns:
        str: Details about the new presentation including ID and URL.

    Examples:
        # Make a copy with new title
        copy_presentation(presentation_id="abc123", new_title="Q1 2025 Report")

        # Copy to specific folder
        copy_presentation(presentation_id="abc123",
                         new_title="Template Copy",
                         destination_folder_id="folder123")
    """
    logger.info(
        f"[copy_presentation] Invoked. Email: '{user_google_email}', "
        f"Source: '{presentation_id}', New Title: {new_title}"
    )

    file_metadata = {}
    if new_title:
        file_metadata["name"] = new_title
    if destination_folder_id:
        file_metadata["parents"] = [destination_folder_id]

    result = await asyncio.to_thread(
        service.files().copy(fileId=presentation_id, body=file_metadata).execute
    )

    new_id = result.get("id")
    new_name = result.get("name")

    logger.info(f"[copy_presentation] Created copy: {new_id}")

    return f"""Presentation Copied Successfully:

- New Presentation ID: {new_id}
- Title: {new_name}
- URL: https://docs.google.com/presentation/d/{new_id}/edit

✅ All visual styling preserved:
- Master slides and layouts
- Theme colors and fonts
- Background designs
- Images and formatting

Original: https://docs.google.com/presentation/d/{presentation_id}/edit"""


@server.tool()
@handle_http_errors("create_presentation_from_template", service_type="slides")
@require_google_service("drive", "drive_file")
async def create_presentation_from_template(
    service,
    user_google_email: str,
    template_presentation_id: str,
    new_title: str,
    clear_slides: bool = True,
    destination_folder_id: Optional[str] = None,
) -> str:
    """
    Create a new presentation based on an existing template, preserving all
    visual design (masters, layouts, themes) but optionally clearing the content.

    ⚠️ VISUAL DESIGN: This is the recommended way to create a new presentation
    with the same visual styling as another presentation. Use this when you
    want to BUILD NEW CONTENT but keep the same:
    - Background colors/images (from master slides)
    - Theme colors and fonts
    - Logo placements
    - Layout templates

    Args:
        user_google_email (str): The user's Google email address. Required.
        template_presentation_id (str): The ID of the presentation to use as template.
        new_title (str): Title for the new presentation.
        clear_slides (bool): If True (default), deletes all slides from the copy
            leaving just the master/theme. Set to False to keep template content.
        destination_folder_id (str, optional): ID of the folder to place the
            new presentation in. If not provided, goes to root of My Drive.

    Returns:
        str: Details about the new presentation including ID and URL.

    Examples:
        # Create new presentation with company template styling
        create_presentation_from_template(
            template_presentation_id="abc123",
            new_title="Q1 2025 Metrics"
        )

        # Keep template slides as starting point
        create_presentation_from_template(
            template_presentation_id="abc123",
            new_title="My Version",
            clear_slides=False
        )

    ⚠️ NOTE: This creates a NEW presentation with a new ID. To apply a template
    to an existing presentation, you must either:
    1. Copy slides from the existing presentation to the new templated one
    2. Manually recreate the visual elements (the Google Slides API does not
       support importing master slides into an existing presentation)
    """
    from auth.google_auth import get_authenticated_google_service
    from auth.scopes import SLIDES_SCOPE

    logger.info(
        f"[create_presentation_from_template] Invoked. Email: '{user_google_email}', "
        f"Template: '{template_presentation_id}', Title: {new_title}, Clear: {clear_slides}"
    )

    # Step 1: Copy the template presentation using Drive service (injected by decorator)
    file_metadata = {"name": new_title}
    if destination_folder_id:
        file_metadata["parents"] = [destination_folder_id]

    result = await asyncio.to_thread(
        service.files()
        .copy(fileId=template_presentation_id, body=file_metadata)
        .execute
    )

    new_id = result.get("id")
    logger.info(f"[create_presentation_from_template] Created copy: {new_id}")

    slides_cleared = 0

    # Step 2: If clear_slides is True, delete all slides from the copy
    if clear_slides:
        # Get Slides service to delete slides
        slides_service, _ = await get_authenticated_google_service(
            service_name="slides",
            version="v1",
            tool_name="create_presentation_from_template",
            user_google_email=user_google_email,
            required_scopes=[SLIDES_SCOPE],
        )

        # Get the presentation to find all slide IDs
        pres = await asyncio.to_thread(
            slides_service.presentations().get(presentationId=new_id).execute
        )

        slides = pres.get("slides", [])

        if len(slides) > 1:
            # Delete all slides except the first one (can't delete all slides)
            # Then we'll add a blank slide and delete the first one
            delete_requests = [
                {"deleteObject": {"objectId": slide["objectId"]}}
                for slide in slides[1:]  # Skip first slide
            ]

            if delete_requests:
                await asyncio.to_thread(
                    slides_service.presentations()
                    .batchUpdate(
                        presentationId=new_id, body={"requests": delete_requests}
                    )
                    .execute
                )

            slides_cleared = len(slides) - 1

            # Now add a new slide and delete the first one
            # Get layouts to find TITLE layout first (has styled background)
            # Fall back to BLANK if no TITLE layout found
            layouts = pres.get("layouts", [])
            layout_id = None
            for layout in layouts:
                props = layout.get("layoutProperties", {})
                name = props.get("displayName", "").upper()
                # Prefer TITLE layouts as they typically have the styled background
                if name == "TITLE SLIDE" or props.get("name", "").upper() == "TITLE":
                    layout_id = layout.get("objectId")
                    break
            # Fall back to BLANK if no title layout
            if not layout_id:
                for layout in layouts:
                    props = layout.get("layoutProperties", {})
                    name = props.get("displayName", "").upper()
                    if "BLANK" in name:
                        layout_id = layout.get("objectId")
                        break

            if layout_id:
                # Add a slide with the selected layout (TITLE or BLANK)
                add_request = {
                    "createSlide": {"slideLayoutReference": {"layoutId": layout_id}}
                }
                await asyncio.to_thread(
                    slides_service.presentations()
                    .batchUpdate(
                        presentationId=new_id, body={"requests": [add_request]}
                    )
                    .execute
                )

                # Delete the original first slide
                first_slide_id = slides[0]["objectId"]
                await asyncio.to_thread(
                    slides_service.presentations()
                    .batchUpdate(
                        presentationId=new_id,
                        body={
                            "requests": [{"deleteObject": {"objectId": first_slide_id}}]
                        },
                    )
                    .execute
                )
                slides_cleared += 1

        logger.info(
            f"[create_presentation_from_template] Cleared {slides_cleared} slides"
        )

    clear_msg = (
        f"\n✅ Cleared {slides_cleared} template slides - ready for new content"
        if clear_slides
        else ""
    )

    return f"""Presentation Created from Template:

- New Presentation ID: {new_id}
- Title: {new_title}
- URL: https://docs.google.com/presentation/d/{new_id}/edit
- Template: https://docs.google.com/presentation/d/{template_presentation_id}/edit

✅ Visual styling preserved:
- Master slides and layouts
- Theme colors and fonts  
- Background designs
- Logo placements{clear_msg}

💡 Use view_slide(slide_index=0) to verify the visual design was preserved.
💡 Use add_slide() to add new slides - they will inherit the template styling."""


# Create comment management tools for slides
_comment_tools = create_comment_tools("presentation", "presentation_id")
read_presentation_comments = _comment_tools["read_comments"]
create_presentation_comment = _comment_tools["create_comment"]
reply_to_presentation_comment = _comment_tools["reply_to_comment"]
resolve_presentation_comment = _comment_tools["resolve_comment"]

# Aliases for backwards compatibility and intuitive naming
read_slide_comments = read_presentation_comments
create_slide_comment = create_presentation_comment
reply_to_slide_comment = reply_to_presentation_comment
resolve_slide_comment = resolve_presentation_comment
