# Google Workspace MCP Server (Indeed Fork)

> **Indeed Internal Fork** of [taylorwilsdon/google_workspace_mcp](https://github.com/taylorwilsdon/google_workspace_mcp)

Full natural language control over Google Calendar, Drive, Gmail, Docs, Sheets, Slides, Forms, Tasks, and Chat through MCP clients, AI assistants, and developer tools.

---

## Quick Start

### Run with uvx (Recommended)

Run directly without cloning the repo. Requires [uv](https://docs.astral.sh/uv/) installed.

```bash
# From the GitLab repo
uvx --from 'git+ssh://git@code.corp.indeed.com/ai4dp/google-workspace-mcp.git' \
  google-workspace-mcp --single-user
```

**Claude Code** — add via CLI:
```bash
claude mcp add google-workspace --transport stdio -- \
  uvx --from 'git+ssh://git@code.corp.indeed.com/ai4dp/google-workspace-mcp.git' \
  google-workspace-mcp --single-user
```

Or add manually to your `.mcp.json`:
```json
{
  "mcpServers": {
    "google-workspace": {
      "type": "stdio",
      "command": "uvx",
      "args": [
        "--from", "git+ssh://git@code.corp.indeed.com/ai4dp/google-workspace-mcp.git",
        "google-workspace-mcp",
        "--single-user"
      ]
    }
  }
}
```

**Cursor** — add to `~/.cursor/mcp.json` using the same JSON format above.

First tool use triggers OAuth — complete sign-in and credentials are saved to `~/.google_workspace_mcp/credentials/`.

> **Tip:** Add `--tools gmail drive calendar` to load only specific services, or `--tool-tier core` for a reduced tool set.

#### Pre-approving read-only tools (Claude Code)

The repo includes `mcp-permissions.json` with all read-only tools pre-approved so Claude Code won't prompt you for every query. Merge the `permissions` block into your `.claude/settings.json` or `.claude/settings.local.json`:

```bash
# One-liner to merge into your local settings
jq -s '.[0] * .[1]' ~/.claude/settings.local.json mcp-permissions.json > /tmp/merged.json \
  && mv /tmp/merged.json ~/.claude/settings.local.json
```

### Run with ToolHive

```bash
# First, create the credentials directory
mkdir -p ~/.google_workspace_mcp/credentials

# Run with ToolHive (mkdir ensures the tmp cache dir exists after OS cleanup)
mkdir -p /tmp/google_workspace_mcp && \
thv run harbor.indeed.tech/ai4dp/google-workspace-mcp:latest \
  --name indeed-google-workspace \
  --transport streamable-http \
  -v ~/.google_workspace_mcp/credentials:/app/store_creds \
  -v /tmp/google_workspace_mcp:/tmp/google_workspace_mcp
```

ToolHive automatically pulls the image if needed and registers the server with Cursor. First tool use triggers OAuth → complete sign-in → credentials saved for persistence.

**Required flags explained:**
- `--transport streamable-http` - Required! ToolHive defaults to stdio, but our image uses HTTP
- `-v ~/.google_workspace_mcp/credentials:...` - Bind mount for credential persistence (same path used by local development)
- `-v /tmp/google_workspace_mcp:...` - Bind mount so `download_doc_image` cached files are accessible on the host

> **Note:** OAuth callback URLs are automatically detected from the Host header, so no `--proxy-port` flag is needed.

> **Note:** This server is not yet in the Indeed ToolHive registry. Once added, you'll be able to run simply: `thv run google-workspace-mcp`

**To stop/restart:**
```bash
thv stop indeed-google-workspace
thv start indeed-google-workspace

# Or remove completely:
thv rm indeed-google-workspace
```

**To update to the latest version:**
```bash
docker pull harbor.indeed.tech/ai4dp/google-workspace-mcp:latest
thv rm indeed-google-workspace
mkdir -p /tmp/google_workspace_mcp && \
thv run harbor.indeed.tech/ai4dp/google-workspace-mcp:latest \
  --name indeed-google-workspace \
  --transport streamable-http \
  -v ~/.google_workspace_mcp/credentials:/app/store_creds \
  -v /tmp/google_workspace_mcp:/tmp/google_workspace_mcp
```

Your credentials are preserved in the bind mount directory across updates.

### Alternative: Run with Docker Directly

If you're not using ToolHive:

```bash
# Create credentials directory and run
mkdir -p ~/.google_workspace_mcp/credentials
docker run -d \
  --name gws-mcp \
  -p 18922:18922 \
  -v ~/.google_workspace_mcp/credentials:/app/store_creds \
  harbor.indeed.tech/ai4dp/google-workspace-mcp:latest

# Verify it's running
curl http://localhost:18922/health
```

Then add to your MCP config (`~/.cursor/mcp.json`):

```json
{
  "mcpServers": {
    "google-workspace": {
      "url": "http://localhost:18922/mcp",
      "type": "http"
    }
  }
}
```

### Authenticate

Use any Google Workspace tool in your MCP client (e.g., "Search my Google Drive"). This triggers the OAuth flow - click the authorization link and complete sign-in. Tokens are saved to `~/.google_workspace_mcp/credentials/` and persist across restarts.

### Troubleshooting

- **"Loading tools" forever in Cursor?** Make sure you included `--transport streamable-http`. Without it, ToolHive defaults to stdio mode which won't work.
- **OAuth callback fails?** Ensure `--proxy-port 18922` matches the port the server expects. This is required for Google's OAuth redirect.

---

## Features

| Service | Capabilities |
|---------|-------------|
| **Gmail** | Search, read, send, draft, labels, filters, batch operations |
| **Drive** | Search, read, create, update, share, permissions (Office format support) |
| **Calendar** | List, create, modify, delete events |
| **Docs** | Create, read, edit, tables, lists, headers/footers |
| **Sheets** | Read, write, append, format, conditional formatting |
| **Slides** | Create, read, update presentations |
| **Forms** | Create forms, manage responses |
| **Tasks** | Full task and task list management |
| **Chat** | List spaces, send/search messages |
| **Search** | Google Custom Search integration |

### Recent Additions (v1.7.1 sync)

- **Gmail Filters**: Create, list, and delete Gmail filters programmatically
- **Drive Sharing**: Share files, manage permissions, transfer ownership, generate shareable links
- **Sheets Conditional Formatting**: Update and delete rules by index, gradient color scales

---

## Tool Tiers

Choose a tier that matches your needs:

| Tier | Flag | Description |
|------|------|-------------|
| **Core** | `--tool-tier core` | Essential tools for everyday tasks |
| **Extended** | `--tool-tier extended` | Core + management features |
| **Complete** | `--tool-tier complete` | All available tools |

Or load specific services: `--tools gmail drive calendar`

---

## Configuration

### Bundled Credentials (Default)

This fork includes bundled OAuth credentials from the `developer-productivity-openctx` Google Cloud project. **No configuration needed** - just run and authenticate.

### Override Credentials (Optional)

To use different credentials, set environment variables:

```bash
export GOOGLE_OAUTH_CLIENT_ID="your-client-id"
export GOOGLE_OAUTH_CLIENT_SECRET="your-secret"
```

### Required Google APIs

The following APIs must be enabled in the Google Cloud project. For the bundled credentials, these are already enabled:

- Google Calendar API
- Google Drive API
- Gmail API
- Google Docs API
- Google Sheets API
- Google Slides API
- Google Forms API
- Google Tasks API
- Google Chat API
- Custom Search API (optional)

---

## Local Development Setup

For contributors or if you need to run from source:

### Prerequisites

This project uses [uv](https://docs.astral.sh/uv/) for dependency management. It's auto-installed via Indeed's system-setup. If you don't have it, run:

```bash
update-managed-repos && system-setup
```

### Setup

```bash
# Clone the repo
git clone git@code.corp.indeed.com:ai4dp/google-workspace-mcp.git
cd google-workspace-mcp

# Install dependencies
uv sync
```

### Running Locally

```bash
# Run with tool optimizer
uv run main.py --optimizer

# Run with specific tools
uv run main.py --tools gmail drive calendar

# Run with specific tools AND optimizer
uv run main.py --optimizer --tools gmail drive calendar

# Or run with a tool tier
uv run main.py --tool-tier core
```

### Example MCP Config (Local)

```json
{
  "mcpServers": {
    "google_workspace": {
      "command": "uvx",
      "args": [
        "--from", "/path/to/google-workspace-mcp",
        "google-workspace-mcp",
        "--single-user"
      ]
    }
  }
}
```

Or using `uv run` directly (equivalent):

```json
{
  "mcpServers": {
    "google_workspace": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/path/to/google-workspace-mcp",
        "main.py",
        "--single-user"
      ]
    }
  }
}
```

### CLI Usage

Use tools directly without running the MCP server. Helpful for testing or scripting:

```bash
# List all available tools
uv run python tools_cli.py --list

# Get detailed info about a specific tool
uv run python tools_cli.py --info get_doc_content

# Call a tool directly
uv run python tools_cli.py --tool search_drive \
  --query "quarterly report" \
  --user_google_email you@example.com

# Interactive REPL mode
uv run python tools_cli.py --interactive
```

### Transport Modes

```bash
# Default: stdio mode (for MCP clients)
uv run main.py --tools gmail drive

# HTTP mode (for debugging, web interfaces)
uv run main.py --transport streamable-http --tools gmail drive

# Single-user mode (simplified auth)
uv run main.py --single-user --tools gmail

# Optimizer mode (semantic tool discovery - reduces context usage)
uv run main.py --optimizer --tools gmail drive
```

### Development Commands

```bash
# Install dev dependencies
uv sync --group dev

# Run linter
uv run ruff check .

# Run tests
uv run pytest

# Build Docker image locally
docker build -t google-workspace-mcp .
```

See `AGENTS.md` for detailed development guidelines.

---

## OAuth 2.1 & Advanced Modes

<details>
<summary>Multi-user / Production Setup</summary>

### OAuth 2.1 Mode

For multi-user bearer token authentication:

```bash
export MCP_ENABLE_OAUTH21=true
uv run main.py --transport streamable-http
```

### Stateless Mode

For containerized environments (no file writes):

```bash
export MCP_ENABLE_OAUTH21=true
export WORKSPACE_MCP_STATELESS_MODE=true
uv run main.py --transport streamable-http
```

### External OAuth Provider

For integration with external auth systems:

```bash
export MCP_ENABLE_OAUTH21=true
export EXTERNAL_OAUTH21_PROVIDER=true
uv run main.py --transport streamable-http
```

</details>

---

## Credential Storage

**All modes:** Tokens are stored at `~/.google_workspace_mcp/credentials/{email}.json`

When running with ToolHive or Docker, the bind mount maps this host directory into the container at `/app/store_creds`. This means:
- Credentials persist across container restarts
- Credentials work seamlessly if you switch between ToolHive, Docker, and local development
- You can inspect/backup credentials directly on your filesystem

Override with: `export GOOGLE_MCP_CREDENTIALS_DIR="/path/to/credentials"`

### Storage Backends (Advanced)

For multi-instance deployments, configure a shared storage backend:

| Backend | Environment Variable | Use Case |
|---------|---------------------|----------|
| **Memory** (default) | `STORAGE_BACKEND=memory` | Single instance, tokens lost on restart |
| **Disk** | `STORAGE_BACKEND=disk` | Single instance, persists across restarts |
| **Valkey** | `STORAGE_BACKEND=valkey` | Multi-instance, distributed token storage |

Valkey requires: `VALKEY_HOST`, `VALKEY_PORT`, and optionally `VALKEY_PASSWORD`.

---

## Upstream vs Fork

| Feature | Upstream (taylorwilsdon) | Indeed Fork |
|---------|-------------------------|-------------|
| **Installation** | `uvx workspace-mcp`, DXT, PyPI | `uvx --from git+ssh://...`, Docker from Harbor |
| **OAuth Setup** | Required (provide your own) | Bundled (zero-config) |
| **Docker Images** | Docker Hub | `harbor.indeed.tech/ai4dp/google-workspace-mcp` |
| **Support** | GitHub Issues | Internal |

**Do NOT use** `uvx workspace-mcp`, the DXT installer, or Docker Hub images - these install the upstream version. Use the full GitLab git URL with `--from` as shown in the Quick Start section.

---

## License

MIT License - see `LICENSE` file.
