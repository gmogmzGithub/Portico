import logging
import json
import os
from typing import List, Optional
from importlib import metadata

from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.middleware import Middleware

from fastmcp import FastMCP
from fastmcp.server.auth.providers.google import GoogleProvider

from auth.oauth21_session_store import get_oauth21_session_store, set_auth_provider
from auth.google_auth import handle_auth_callback, start_auth_flow, check_client_secrets
from auth.mcp_session_middleware import MCPSessionMiddleware
from auth.oauth_responses import (
    create_error_response,
    create_success_response,
    create_server_error_response,
)
from auth.auth_info_middleware import AuthInfoMiddleware
from auth.scopes import SCOPES, get_current_scopes  # noqa
from core.config import (
    USER_GOOGLE_EMAIL,
    get_transport_mode,
    set_transport_mode as _set_transport_mode,
    get_oauth_redirect_uri as get_oauth_redirect_uri_for_current_mode,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_auth_provider: Optional[GoogleProvider] = None
_legacy_callback_registered = False

session_middleware = Middleware(MCPSessionMiddleware)


# Custom FastMCP that adds secure middleware stack for OAuth 2.1
class SecureFastMCP(FastMCP):
    def streamable_http_app(self) -> "Starlette":
        """Override to add secure middleware stack for OAuth 2.1."""
        app = super().streamable_http_app()

        # Add middleware in order (first added = outermost layer)
        # Session Management - extracts session info for MCP context
        app.user_middleware.insert(0, session_middleware)

        # Rebuild middleware stack
        app.middleware_stack = app.build_middleware_stack()
        logger.info("Added middleware stack: Session Management")
        return app


server = SecureFastMCP(
    name="google_workspace",
    auth=None,
)

# Add the AuthInfo middleware to inject authentication into FastMCP context
auth_info_middleware = AuthInfoMiddleware()
server.add_middleware(auth_info_middleware)


def _parse_bool_env(value: str) -> bool:
    """Parse environment variable string to boolean."""
    return value.lower() in ("1", "true", "yes", "on")


def set_transport_mode(mode: str):
    """Sets the transport mode for the server."""
    _set_transport_mode(mode)
    logger.info(f"Transport: {mode}")


def _ensure_legacy_callback_route() -> None:
    global _legacy_callback_registered
    if _legacy_callback_registered:
        return
    server.custom_route("/oauth2callback", methods=["GET"])(legacy_oauth2_callback)
    _legacy_callback_registered = True


def configure_server_for_http():
    """
    Configures the authentication provider for HTTP transport.
    This must be called BEFORE server.run().
    """
    global _auth_provider

    transport_mode = get_transport_mode()

    if transport_mode != "streamable-http":
        return

    # Use centralized OAuth configuration
    from auth.oauth_config import get_oauth_config

    config = get_oauth_config()

    # Check if OAuth 2.1 is enabled via centralized config
    oauth21_enabled = config.is_oauth21_enabled()

    if oauth21_enabled:
        if not config.is_configured():
            logger.warning("OAuth 2.1 enabled but OAuth credentials not configured")
            return

        def validate_and_derive_jwt_key(
            jwt_signing_key_override: str | None, client_secret: str
        ) -> bytes:
            """Validate JWT signing key override and derive the final JWT key."""
            if jwt_signing_key_override:
                if len(jwt_signing_key_override) < 12:
                    logger.warning(
                        "OAuth 2.1: FASTMCP_SERVER_AUTH_GOOGLE_JWT_SIGNING_KEY is less than 12 characters; "
                        "use a longer secret to improve key derivation strength."
                    )
                return derive_jwt_key(
                    low_entropy_material=jwt_signing_key_override,
                    salt="fastmcp-jwt-signing-key",
                )
            else:
                return derive_jwt_key(
                    high_entropy_material=client_secret,
                    salt="fastmcp-jwt-signing-key",
                )

        try:
            # Import common dependencies for storage backends
            from key_value.aio.wrappers.encryption import FernetEncryptionWrapper
            from cryptography.fernet import Fernet
            from fastmcp.server.auth.jwt_issuer import derive_jwt_key

            required_scopes: List[str] = sorted(get_current_scopes())

            client_storage = None
            jwt_signing_key_override = (
                os.getenv("FASTMCP_SERVER_AUTH_GOOGLE_JWT_SIGNING_KEY", "").strip()
                or None
            )
            storage_backend = (
                os.getenv("WORKSPACE_MCP_OAUTH_PROXY_STORAGE_BACKEND", "")
                .strip()
                .lower()
            )
            valkey_host = os.getenv("WORKSPACE_MCP_OAUTH_PROXY_VALKEY_HOST", "").strip()

            # Determine storage backend: valkey, disk, memory (default)
            use_valkey = storage_backend == "valkey" or bool(valkey_host)
            use_disk = storage_backend == "disk"

            if use_valkey:
                try:
                    from key_value.aio.stores.valkey import ValkeyStore

                    valkey_port_raw = os.getenv(
                        "WORKSPACE_MCP_OAUTH_PROXY_VALKEY_PORT", "6379"
                    ).strip()
                    valkey_db_raw = os.getenv(
                        "WORKSPACE_MCP_OAUTH_PROXY_VALKEY_DB", "0"
                    ).strip()

                    valkey_port = int(valkey_port_raw)
                    valkey_db = int(valkey_db_raw)
                    valkey_use_tls_raw = os.getenv(
                        "WORKSPACE_MCP_OAUTH_PROXY_VALKEY_USE_TLS", ""
                    ).strip()
                    valkey_use_tls = (
                        _parse_bool_env(valkey_use_tls_raw)
                        if valkey_use_tls_raw
                        else valkey_port == 6380
                    )

                    valkey_request_timeout_ms_raw = os.getenv(
                        "WORKSPACE_MCP_OAUTH_PROXY_VALKEY_REQUEST_TIMEOUT_MS", ""
                    ).strip()
                    valkey_connection_timeout_ms_raw = os.getenv(
                        "WORKSPACE_MCP_OAUTH_PROXY_VALKEY_CONNECTION_TIMEOUT_MS", ""
                    ).strip()

                    valkey_request_timeout_ms = (
                        int(valkey_request_timeout_ms_raw)
                        if valkey_request_timeout_ms_raw
                        else None
                    )
                    valkey_connection_timeout_ms = (
                        int(valkey_connection_timeout_ms_raw)
                        if valkey_connection_timeout_ms_raw
                        else None
                    )

                    valkey_username = (
                        os.getenv(
                            "WORKSPACE_MCP_OAUTH_PROXY_VALKEY_USERNAME", ""
                        ).strip()
                        or None
                    )
                    valkey_password = (
                        os.getenv(
                            "WORKSPACE_MCP_OAUTH_PROXY_VALKEY_PASSWORD", ""
                        ).strip()
                        or None
                    )

                    if not valkey_host:
                        valkey_host = "localhost"

                    client_storage = ValkeyStore(
                        host=valkey_host,
                        port=valkey_port,
                        db=valkey_db,
                        username=valkey_username,
                        password=valkey_password,
                    )

                    # Configure TLS and timeouts on the underlying Glide client config.
                    # ValkeyStore currently doesn't expose these settings directly.
                    glide_config = getattr(client_storage, "_client_config", None)
                    if glide_config is not None:
                        glide_config.use_tls = valkey_use_tls

                        is_remote_host = valkey_host not in {"localhost", "127.0.0.1"}
                        if valkey_request_timeout_ms is None and (
                            valkey_use_tls or is_remote_host
                        ):
                            # Glide defaults to 250ms if unset; increase for remote/TLS endpoints.
                            valkey_request_timeout_ms = 5000
                        if valkey_request_timeout_ms is not None:
                            glide_config.request_timeout = valkey_request_timeout_ms

                        if valkey_connection_timeout_ms is None and (
                            valkey_use_tls or is_remote_host
                        ):
                            valkey_connection_timeout_ms = 10000
                        if valkey_connection_timeout_ms is not None:
                            from glide_shared.config import (
                                AdvancedGlideClientConfiguration,
                            )

                            glide_config.advanced_config = (
                                AdvancedGlideClientConfiguration(
                                    connection_timeout=valkey_connection_timeout_ms
                                )
                            )

                    jwt_signing_key = validate_and_derive_jwt_key(
                        jwt_signing_key_override, config.client_secret
                    )

                    storage_encryption_key = derive_jwt_key(
                        high_entropy_material=jwt_signing_key.decode(),
                        salt="fastmcp-storage-encryption-key",
                    )

                    client_storage = FernetEncryptionWrapper(
                        key_value=client_storage,
                        fernet=Fernet(key=storage_encryption_key),
                    )
                    logger.info(
                        "OAuth 2.1: Using ValkeyStore for FastMCP OAuth proxy client_storage (host=%s, port=%s, db=%s, tls=%s)",
                        valkey_host,
                        valkey_port,
                        valkey_db,
                        valkey_use_tls,
                    )
                    if valkey_request_timeout_ms is not None:
                        logger.info(
                            "OAuth 2.1: Valkey request timeout set to %sms",
                            valkey_request_timeout_ms,
                        )
                    if valkey_connection_timeout_ms is not None:
                        logger.info(
                            "OAuth 2.1: Valkey connection timeout set to %sms",
                            valkey_connection_timeout_ms,
                        )
                    logger.info(
                        "OAuth 2.1: Applied Fernet encryption wrapper to Valkey client_storage (key derived from FASTMCP_SERVER_AUTH_GOOGLE_JWT_SIGNING_KEY or GOOGLE_OAUTH_CLIENT_SECRET)."
                    )
                except ImportError as exc:
                    logger.warning(
                        "OAuth 2.1: Valkey client_storage requested but Valkey dependencies are not installed (%s). "
                        "Install 'workspace-mcp[valkey]' (or 'py-key-value-aio[valkey]', which includes 'valkey-glide') "
                        "or unset WORKSPACE_MCP_OAUTH_PROXY_STORAGE_BACKEND/WORKSPACE_MCP_OAUTH_PROXY_VALKEY_HOST.",
                        exc,
                    )
                except ValueError as exc:
                    logger.warning(
                        "OAuth 2.1: Invalid Valkey configuration; falling back to default storage (%s).",
                        exc,
                    )
            elif use_disk:
                try:
                    from key_value.aio.stores.disk import DiskStore

                    disk_directory = os.getenv(
                        "WORKSPACE_MCP_OAUTH_PROXY_DISK_DIRECTORY", ""
                    ).strip()
                    if not disk_directory:
                        # Default to FASTMCP_HOME/oauth-proxy or ~/.fastmcp/oauth-proxy
                        fastmcp_home = os.getenv("FASTMCP_HOME", "").strip()
                        if fastmcp_home:
                            disk_directory = os.path.join(fastmcp_home, "oauth-proxy")
                        else:
                            disk_directory = os.path.expanduser(
                                "~/.fastmcp/oauth-proxy"
                            )

                    client_storage = DiskStore(directory=disk_directory)

                    jwt_signing_key = validate_and_derive_jwt_key(
                        jwt_signing_key_override, config.client_secret
                    )

                    storage_encryption_key = derive_jwt_key(
                        high_entropy_material=jwt_signing_key.decode(),
                        salt="fastmcp-storage-encryption-key",
                    )

                    client_storage = FernetEncryptionWrapper(
                        key_value=client_storage,
                        fernet=Fernet(key=storage_encryption_key),
                    )
                    logger.info(
                        "OAuth 2.1: Using DiskStore for FastMCP OAuth proxy client_storage (directory=%s)",
                        disk_directory,
                    )
                except ImportError as exc:
                    logger.warning(
                        "OAuth 2.1: Disk storage requested but dependencies not available (%s). "
                        "Falling back to default storage.",
                        exc,
                    )
            elif storage_backend == "memory":
                from key_value.aio.stores.memory import MemoryStore

                client_storage = MemoryStore()
                logger.info(
                    "OAuth 2.1: Using MemoryStore for FastMCP OAuth proxy client_storage"
                )
            # else: client_storage remains None, FastMCP uses its default

            # Ensure JWT signing key is always derived for all storage backends
            if "jwt_signing_key" not in locals():
                jwt_signing_key = validate_and_derive_jwt_key(
                    jwt_signing_key_override, config.client_secret
                )

            # Check if external OAuth provider is configured
            if config.is_external_oauth21_provider():
                # External OAuth mode: use custom provider that handles ya29.* access tokens
                from auth.external_oauth_provider import ExternalOAuthProvider

                provider = ExternalOAuthProvider(
                    client_id=config.client_id,
                    client_secret=config.client_secret,
                    base_url=config.get_oauth_base_url(),
                    redirect_path=config.redirect_path,
                    required_scopes=required_scopes,
                )
                # Disable protocol-level auth, expect bearer tokens in tool calls
                server.auth = None
                logger.info(
                    "OAuth 2.1 enabled with EXTERNAL provider mode - protocol-level auth disabled"
                )
                logger.info(
                    "Expecting Authorization bearer tokens in tool call headers"
                )
            else:
                # Standard OAuth 2.1 mode: use FastMCP's GoogleProvider
                provider = GoogleProvider(
                    client_id=config.client_id,
                    client_secret=config.client_secret,
                    base_url=config.get_oauth_base_url(),
                    redirect_path=config.redirect_path,
                    required_scopes=required_scopes,
                    client_storage=client_storage,
                    jwt_signing_key=jwt_signing_key,
                )
                # Enable protocol-level auth
                server.auth = provider
                logger.info(
                    "OAuth 2.1 enabled using FastMCP GoogleProvider with protocol-level auth"
                )

            # Always set auth provider for token validation in middleware
            set_auth_provider(provider)
            _auth_provider = provider
        except Exception as exc:
            logger.error(
                "Failed to initialize FastMCP GoogleProvider: %s", exc, exc_info=True
            )
            raise
    else:
        logger.info("OAuth 2.0 mode - Server will use legacy authentication.")
        server.auth = None
        _auth_provider = None
        set_auth_provider(None)
        _ensure_legacy_callback_route()


def get_auth_provider() -> Optional[GoogleProvider]:
    """Gets the global authentication provider instance."""
    return _auth_provider


@server.custom_route("/health", methods=["GET"])
async def health_check(request: Request):
    try:
        version = metadata.version("workspace-mcp")
    except metadata.PackageNotFoundError:
        version = "dev"
    return JSONResponse(
        {
            "status": "healthy",
            "service": "workspace-mcp",
            "version": version,
            "transport": get_transport_mode(),
        }
    )


@server.custom_route("/attachments/{file_id}", methods=["GET"])
async def serve_attachment(file_id: str):
    """Serve a stored attachment file."""
    from core.attachment_storage import get_attachment_storage

    storage = get_attachment_storage()
    metadata = storage.get_attachment_metadata(file_id)

    if not metadata:
        return JSONResponse(
            {"error": "Attachment not found or expired"}, status_code=404
        )

    file_path = storage.get_attachment_path(file_id)
    if not file_path:
        return JSONResponse({"error": "Attachment file not found"}, status_code=404)

    return FileResponse(
        path=str(file_path),
        filename=metadata["filename"],
        media_type=metadata["mime_type"],
    )


async def legacy_oauth2_callback(request: Request) -> HTMLResponse:
    state = request.query_params.get("state")
    code = request.query_params.get("code")
    error = request.query_params.get("error")

    if error:
        msg = (
            f"Authentication failed: Google returned an error: {error}. State: {state}."
        )
        logger.error(msg)
        return create_error_response(msg)

    if not code:
        msg = "Authentication failed: No authorization code received from Google."
        logger.error(msg)
        return create_error_response(msg)

    try:
        error_message = check_client_secrets()
        if error_message:
            return create_server_error_response(error_message)

        logger.info(f"OAuth callback: Received code (state: {state}).")

        mcp_session_id = None
        if hasattr(request, "state") and hasattr(request.state, "session_id"):
            mcp_session_id = request.state.session_id

        verified_user_id, credentials = handle_auth_callback(
            scopes=get_current_scopes(),
            authorization_response=str(request.url),
            redirect_uri=get_oauth_redirect_uri_for_current_mode(),
            session_id=mcp_session_id,
        )

        logger.info(
            f"OAuth callback: Successfully authenticated user: {verified_user_id}."
        )

        try:
            store = get_oauth21_session_store()

            store.store_session(
                user_email=verified_user_id,
                access_token=credentials.token,
                refresh_token=credentials.refresh_token,
                token_uri=credentials.token_uri,
                client_id=credentials.client_id,
                client_secret=credentials.client_secret,
                scopes=credentials.scopes,
                expiry=credentials.expiry,
                session_id=f"google-{state}",
                mcp_session_id=mcp_session_id,
            )
            logger.info(
                f"Stored Google credentials in OAuth 2.1 session store for {verified_user_id}"
            )
        except Exception as e:
            logger.error(f"Failed to store credentials in OAuth 2.1 store: {e}")

        return create_success_response(verified_user_id)
    except Exception as e:
        logger.error(f"Error processing OAuth callback: {str(e)}", exc_info=True)
        return create_server_error_response(str(e))


@server.tool()
async def start_google_auth(
    service_name: str, user_google_email: str = USER_GOOGLE_EMAIL
) -> str:
    """
    Manually initiate Google OAuth authentication flow.

    NOTE: This tool should typically NOT be called directly. The authentication system
    automatically handles credential checks and prompts for authentication when needed.
    Only use this tool if:
    1. You need to re-authenticate with different credentials
    2. You want to proactively authenticate before using other tools
    3. The automatic authentication flow failed and you need to retry

    In most cases, simply try calling the Google Workspace tool you need - it will
    automatically handle authentication if required.
    """
    if not user_google_email:
        raise ValueError("user_google_email must be provided.")

    error_message = check_client_secrets()
    if error_message:
        return f"**Authentication Error:** {error_message}"

    try:
        auth_message = await start_auth_flow(
            user_google_email=user_google_email,
            service_name=service_name,
            redirect_uri=get_oauth_redirect_uri_for_current_mode(),
        )
        return auth_message
    except Exception as e:
        logger.error(f"Failed to start Google authentication flow: {e}", exc_info=True)
        return f"**Error:** An unexpected error occurred: {e}"


@server.tool()
async def get_tool_hints(category: str) -> str:
    """
    Get onboarding hints and best practices for a category of tools.

    **CALL THIS BEFORE starting work with a new tool category!**
    Returns essential tips, gotchas, and recommended patterns.

    Args:
        category: Tool category - one of:
            - "docs" - Google Docs tools (formatting, tables, markdown)
            - "sheets" - Google Sheets tools
            - "drive" - Google Drive tools
            - "gmail" - Gmail tools
            - "calendar" - Calendar tools

    Returns:
        Markdown-formatted hints and best practices for the category.

    Example:
        get_tool_hints(category="docs")
        → Returns tips on batch operations, table handling, markdown import, etc.
    """
    hints = {
        "docs": """# Google Docs Tool Hints

## Quick Start
- Use `batch_edit_doc` for multiple operations - more efficient than individual calls
- Use `get_doc_content` to read before modifying
- Always specify `user_google_email` parameter

## Positioning Text
Prefer search-based positioning over index-based:
```python
# Good: Search-based (resilient to document changes)
{"type": "insert", "search": "Introduction", "position": "after", "text": "New content"}

# Risky: Index-based (breaks if document changes)
{"type": "insert", "index": 150, "text": "New content"}
```

## Tables
- Use `create_table_with_data` for new tables (pass 2D array)
- Use `modify_table` for updating existing table cells
- **Do NOT use batch_edit_doc for table modifications** - batch can only INSERT tables

## Markdown Import (`insert_markdown`)
- Tables need blank lines before them (auto-fixed by the tool)
- Horizontal rules (`---`) render as thin tables (no native HR in Google Docs)
- Links in tables are preserved
- Test with files in `tests/example_docs/`

**Google API Limitations (not fixable):**
- Mixed nested lists (numbered + bullet sub-items) become single type with different glyphs:
  - Source: `1. Parent` → `- Child` becomes `1. Parent` → `a. Child`
  - All levels use the same list type (DECIMAL→ALPHA→ROMAN)
- Blank lines between list items may create empty list entries
- Code blocks render as plain text (no syntax highlighting in Google Docs)
- For precise list control, use `insert_doc_elements` with `nesting_levels` parameter

## Multi-Tab Documents
- Use `list_doc_tabs` to discover tab IDs
- Pass `tab_id` parameter to target specific tabs
- Without `tab_id`, operations default to first tab

## Danger Zones
- `find_and_replace_doc` operates GLOBALLY - creates auto-savepoint
- Use `max_replacements` parameter to limit scope
- Undo only works within same session

## Recommended Patterns
1. Read document structure first: `get_doc_content(format="plain")`
2. Use batch operations: `batch_edit_doc` with multiple ops
3. Preview before executing: `preview=True` parameter
4. For cleanup: `modify_table` cell-by-cell is safest
""",
        "sheets": """# Google Sheets Tool Hints

## Quick Start
- Use `get_spreadsheet_info` to understand sheet structure
- Use `read_sheet_range` for reading data
- Use `update_sheet_range` for writing data

## Range Notation
- A1 notation: `Sheet1!A1:C10` or just `A1:C10`
- Named ranges: Use range name directly
- Full column: `A:A`
- Full row: `1:1`

## Writing Data
- Pass data as 2D array: `[["A1", "B1"], ["A2", "B2"]]`
- `update_sheet_range` overwrites existing data
- `append_to_sheet` adds rows at the end

## Formulas
- Include `=` prefix: `"=SUM(A1:A10)"`
- Formulas are evaluated after write
- Use `read_sheet_range(value_render="FORMULA")` to see formulas

## Multiple Sheets
- List sheets: `get_spreadsheet_info`
- Create sheet: `create_sheet`
- Delete sheet: `delete_sheet`
- Specify sheet in range: `Sheet2!A1:B10`

## Batch Operations
- Use `batch_update_sheet` for multiple updates
- More efficient than individual calls
- Atomic - all succeed or all fail
""",
        "drive": """# Google Drive Tool Hints

## Quick Start
- Use `search_drive_files` to find files by name or type
- Use `list_drive_files` to list folder contents
- File IDs are used for all operations

## Search Syntax
- By name: `name contains "report"`
- By type: `mimeType = "application/vnd.google-apps.document"`
- Combined: `name contains "Q4" and mimeType = "application/pdf"`

## Common MIME Types
- Google Doc: `application/vnd.google-apps.document`
- Google Sheet: `application/vnd.google-apps.spreadsheet`
- PDF: `application/pdf`
- Folder: `application/vnd.google-apps.folder`

## File Operations
- `copy_drive_file` - Duplicate a file
- `move_drive_file` - Move between folders
- `delete_drive_file` - Move to trash (use `permanent=True` for permanent delete)

## Sharing
- `share_drive_file` - Set permissions
- `get_file_permissions` - View current sharing
- Roles: "reader", "writer", "commenter", "owner"
""",
        "gmail": """# Gmail Tool Hints

## Quick Start
- Use `search_gmail_messages` to find emails
- Use `send_gmail_message` to send new emails
- Use `reply_to_gmail_message` for replies

## Search Syntax
Gmail search operators work:
- `from:user@example.com`
- `to:team@company.com`
- `subject:quarterly report`
- `has:attachment`
- `after:2024/01/01`
- `is:unread`

## Sending Emails
- `to` can be comma-separated for multiple recipients
- `cc` and `bcc` are optional
- `body` supports plain text or HTML

## Attachments
- Use `file_id` to attach Drive files
- Or `attachment_path` for local files
- Multiple attachments supported as array

## Labels
Use `modify_gmail_message_labels` or `batch_modify_gmail_message_labels` to change labels.

**System labels:** INBOX, UNREAD, STARRED, IMPORTANT, TRASH, SPAM, SENT, DRAFT

**Common operations:**
- Mark as read: remove UNREAD label
- Mark as unread: add UNREAD label
- Archive: remove INBOX label (message stays in All Mail)
- Move to inbox: add INBOX label
- Delete: add TRASH label
- Star: add STARRED label

**Important:** Labels are independent - modifying one does NOT affect others.
Removing UNREAD will not remove INBOX. Removing INBOX will not affect UNREAD.

**Custom labels:** Use `manage_gmail_label` to create/update/delete custom labels.
""",
        "calendar": """# Google Calendar Tool Hints

## Quick Start
- Use `list_calendar_events` to see upcoming events
- Use `create_calendar_event` to add events
- Use `get_calendar_event` for event details

## Time Formats
- ISO 8601: `2024-12-15T10:00:00-08:00`
- All-day events: Just date `2024-12-15`
- Always include timezone or use UTC

## Recurring Events
- Use `recurrence` parameter with RRULE
- Example: `RRULE:FREQ=WEEKLY;BYDAY=MO,WE,FR`
- Modify single instance vs entire series

## Attendees
- Array of email addresses
- Automatically sends invitations
- Check `attendee_response` for RSVPs

## Multiple Calendars
- Default is primary calendar
- Use `calendar_id` for other calendars
- List calendars with `list_calendars`
""",
        "slides": """# Google Slides Tool Hints

## ⚠️ CRITICAL: Visual Design is as Important as Content!
Presentations are VISUAL media. The look and feel is just as important as the text content.
**ALWAYS check the visual appearance** using `view_slide` before considering a slide complete.

## ⚠️ TEXT STYLING IS COMPLEX - READ THIS!
Text styling involves inheritance from: element → placeholder → layout → master → theme.
**NEVER use bare `insertText`** - it creates unstyled text that won't match the design!

**ALWAYS use these tools instead:**
- `get_effective_text_style` - See the ACTUAL rendered font/size/color (resolves inheritance)
- `insert_text_with_style` - Insert text WITH complete styling in one operation
- `get_presentation_theme` - See what fonts/colors the presentation uses

## Before Starting ANY Slide Work
1. **Visual check**: `view_slide` on source to see the actual appearance
2. **Get effective styles**: `get_effective_text_style` on source elements to see fonts/sizes
3. **Understand the theme**: `get_presentation_theme` to see available layouts and fonts
4. **Use correct layout**: `list_layouts` to find layouts that match desired background/logo

## Style Copying Workflow
When duplicating or recreating content:
```python
# 1. Get effective style from source element
get_effective_text_style(presentation_id="source", element_id="title_elem")
# Returns: font_family=Noto Sans, font_weight=300, font_size_pt=40

# 2. Insert text with copied style  
insert_text_with_style(
    element_id="dest_elem",
    text="My Title",
    copy_style_from="source_title",  # Auto-copies all styling!
    copy_style_from_presentation="source_pres_id"
)
```

## Creating New Content
When creating from scratch (not copying):
```python
# 1. Check presentation theme for available fonts
get_presentation_theme(presentation_id="...")

# 2. Use explicit styling
insert_text_with_style(
    element_id="title",
    text="My Title",
    font_family="Noto Sans",
    font_size_pt=40,
    font_weight=300  # 300=light, 400=normal, 700=bold
)
```

## Layout Selection is CRITICAL
Layouts contain:
- Background images (wave patterns, gradients)
- Logos (company branding in corners)
- Pre-styled placeholders with correct fonts/colors

```python
# List available layouts
list_layouts(presentation_id="...")

# Use specific layout when creating slides
add_slide(presentation_id="...", layout="g3adf3da1fe0_0_58")  # Use layout ID

# Or use layout name
add_slide(presentation_id="...", layout="CUSTOM")  # By name
```

## Visual Design Checklist
- [ ] Background: Use correct layout (not just solid color)
- [ ] Fonts: Check `get_effective_text_style` matches source
- [ ] Font weights: 300=light, 400=normal, 700=bold
- [ ] Text colors: Use theme colors when possible (THEME:LIGHT1)
- [ ] Logos: Come from layouts - use correct layout ID

## Quick Start Tools
| Tool | Purpose |
|------|---------|
| `view_slide` | Download thumbnail for visual comparison |
| `get_effective_text_style` | See actual rendered style (resolves inheritance) |
| `insert_text_with_style` | Insert text WITH styling (copy or explicit) |
| `get_presentation_theme` | See fonts/colors/layouts in presentation |
| `list_layouts` | See available layouts and their IDs |
| `add_slide` | Create slide with specific layout |

## Danger Zones
- **NEVER use bare insertText** - creates unstyled text
- **Layouts can't be changed after creation** - must delete and recreate slide
- **Font inheritance is complex** - always verify with `get_effective_text_style`
- **Theme colors** may render as "THEME:LIGHT1" - these inherit from theme

## Positioning
- Positions are in inches from top-left corner
- Standard slide is 10" wide x 5.625" tall
- Placeholder positions come from layouts - use layout for consistency
""",
    }

    category_lower = category.lower()
    if category_lower not in hints:
        available = ", ".join(hints.keys())
        return f"Unknown category '{category}'. Available categories: {available}"

    return hints[category_lower]


# Optimizer mode tools (conditionally registered)
def register_optimizer_tools():
    """Register optimizer tools for on-demand tool discovery."""
    from core.optimizer import get_optimizer, OptimizerNotReadyError

    @server.tool()
    async def google_workspace_find_tool(query: str, top_k: int = 10) -> str:
        """
        Semantic search for Google Workspace tools by description.

        This is the FIRST STEP in using Google Workspace tools in optimizer mode.
        Use this tool to discover which tools are available for your task.

        **IMPORTANT**: Before using tools in a new category (docs, sheets, gmail, etc.),
        call get_tool_hints(category="<service>") to get essential tips and avoid common mistakes!

        WORKFLOW:
        1. Use this tool (google_workspace_find_tool) to search for relevant tools
        2. Call get_tool_hints(category) for the service you're about to use
        3. Use google_workspace_describe_tool to get the full schema of a tool
        4. Use google_workspace_call_tool to execute the tool with proper arguments

        Args:
            query: Natural language description of what you're trying to do
                   Examples:
                   - "send an email"
                   - "create a document"
                   - "list calendar events"
                   - "search for files in drive"
            top_k: Number of top matching tools to return (default: 10)

        Returns:
            JSON array of matching tools with:
            - name: The tool name to use in describe_tool and call_tool
            - excerpt: Brief description of what the tool does
            - score: Similarity score (higher is better match)
            - hint: A reminder about get_tool_hints (included at end of results)

        Example:
            Query: "send an email"
            Returns: [{"name": "send_gmail_message", "excerpt": "Send an email...", "score": 0.85}]
        """
        optimizer = get_optimizer()
        if optimizer is None:
            return json.dumps({"error": "Optimizer not initialized"}, indent=2)

        try:
            results = optimizer.find_similar_tools(query, top_k)
            # Always append a reminder about get_tool_hints
            results.append(
                {
                    "name": "get_tool_hints",
                    "hint": "RECOMMENDED: Call get_tool_hints(category='docs'|'sheets'|'gmail'|'drive'|'calendar') before using tools in a new category to get essential tips!",
                    "score": None,
                }
            )
            return json.dumps(results, indent=2)
        except OptimizerNotReadyError as e:
            # Return a structured response that indicates retry is needed
            return json.dumps(
                {
                    "status": "initializing",
                    "message": e.message,
                    "retry_after_seconds": e.retry_after_seconds,
                },
                indent=2,
            )
        except Exception as e:
            logger.error(f"Error in google_workspace_find_tool: {e}", exc_info=True)
            return json.dumps({"error": str(e)}, indent=2)

    @server.tool()
    async def google_workspace_describe_tool(name: str) -> str:
        """
        Get the full definition and parameter schema of a specific tool.

        This is the SECOND STEP after finding a tool with google_workspace_find_tool.
        Use this to understand what parameters the tool requires before calling it.

        WORKFLOW:
        1. google_workspace_find_tool - Search for tools
        2. Use THIS tool to get the full schema
        3. google_workspace_call_tool - Execute with proper arguments

        Args:
            name: The exact tool name from google_workspace_find_tool results
                  (e.g., "send_gmail_message", "create_doc", "list_calendar_events")

        Returns:
            JSON object with:
            - name: Tool name
            - description: Full description of what the tool does
            - inputSchema: Complete JSON schema of all parameters (required and optional)

        Example:
            Input: name="send_gmail_message"
            Returns: {
              "name": "send_gmail_message",
              "description": "Send an email message via Gmail...",
              "inputSchema": {
                "type": "object",
                "properties": {
                  "to": {"type": "string", "description": "Recipient email"},
                  "subject": {"type": "string", "description": "Email subject"},
                  ...
                },
                "required": ["to", "subject", "body"]
              }
            }
        """
        optimizer = get_optimizer()
        if optimizer is None:
            return json.dumps({"error": "Optimizer not initialized"}, indent=2)

        try:
            definition = optimizer.get_tool_definition(name)
            return json.dumps(definition, indent=2)
        except ValueError as e:
            return json.dumps({"error": str(e)}, indent=2)
        except Exception as e:
            logger.error(f"Error in google_workspace_describe_tool: {e}", exc_info=True)
            return json.dumps({"error": str(e)}, indent=2)

    @server.tool()
    async def google_workspace_list_tools(service: str = None) -> str:
        """
        List all available Google Workspace tool names, optionally filtered by service.

        Use this as an alternative to google_workspace_find_tool when you want to
        browse all available tools or see all tools for a specific service.

        IMPORTANT: This tool should ONLY be used when you know the specific service you need
        (e.g., 'gmail', 'docs', 'sheets'). For general task-based discovery, use
        google_workspace_find_tool instead with a natural language query.

        RECOMMENDED USAGE:
        - ✅ GOOD: list_tools(service='gmail') - when you know you need Gmail tools
        - ✅ GOOD: After find_tool narrows down to a service, list all tools in that service
        - ❌ AVOID: list_tools() with no filter - this dumps all tools and defeats the optimizer's purpose
        - ❌ AVOID: Using this as your first step - use find_tool for semantic search instead

        Args:
            service: Optional service name to filter by. Valid values:
                    - 'gmail' - Email tools
                    - 'docs' - Google Docs tools
                    - 'sheets' - Google Sheets tools
                    - 'drive' - Google Drive tools
                    - 'calendar' - Google Calendar tools
                    - 'slides' - Google Slides tools
                    - 'forms' - Google Forms tools
                    - 'tasks' - Google Tasks tools
                    - 'chat' - Google Chat tools
                    - 'search' - Custom Search tools
                    - None (default) - All tools (use sparingly!)

        Returns:
            JSON array of tool names that you can then describe or call

        Example Workflow:
            1. find_tool('send an email') → identifies this is a Gmail task
            2. list_tools(service='gmail') → see all available Gmail tools
            3. describe_tool('send_gmail_message') → get full schema
            4. call_tool('send_gmail_message', args) → execute
        """
        optimizer = get_optimizer()
        if optimizer is None:
            return json.dumps({"error": "Optimizer not initialized"}, indent=2)

        try:
            tools = optimizer.list_all_tools(service=service)

            # Warn if returning too many tools without filtering
            if service is None and len(tools) > 20:
                return json.dumps(
                    {
                        "warning": f"Returning {len(tools)} tools without service filter. Consider using google_workspace_find_tool with a natural language query, or filter by service.",
                        "tools": tools,
                        "suggestion": "Use find_tool('your task description') for semantic search, or specify a service parameter to filter results.",
                    },
                    indent=2,
                )

            return json.dumps(tools, indent=2)
        except Exception as e:
            logger.error(f"Error in google_workspace_list_tools: {e}", exc_info=True)
            return json.dumps({"error": str(e)}, indent=2)

    @server.tool()
    async def google_workspace_call_tool(name: str, arguments: dict) -> str:
        """
        Execute a Google Workspace tool with the given arguments.

        This is the FINAL STEP after finding and understanding a tool.
        Use this to actually execute the tool and perform the action.

        COMPLETE WORKFLOW:
        1. google_workspace_find_tool - Search: "send an email"
           → Returns: [{"name": "send_gmail_message", ...}]

        2. google_workspace_describe_tool - Get schema: name="send_gmail_message"
           → Returns: Full parameter schema showing required fields: to, subject, body

        3. Use THIS tool to execute:
           name="send_gmail_message"
           arguments={"to": "user@example.com", "subject": "Hello", "body": "Message"}
           → Sends the actual email

        Args:
            name: The exact tool name from find_tool or describe_tool
                  (e.g., "send_gmail_message", "create_doc", "list_calendar_events")

            arguments: Dictionary of arguments matching the tool's inputSchema
                      - Must include all required parameters
                      - Can include optional parameters
                      - Parameter names and types must match the schema exactly

        Returns:
            The result from the tool execution (format varies by tool)
            - Success: Tool output (could be confirmation, data, resource URL, etc.)
            - Error: JSON with error details

        Example:
            Input:
              name="send_gmail_message"
              arguments={
                "to": "colleague@example.com",
                "subject": "Meeting Notes",
                "body": "Here are the notes from our meeting...",
                "user_google_email": "myemail@gmail.com"
              }
            Returns: "Email sent successfully. Message ID: abc123..."
        """
        optimizer = get_optimizer()
        if optimizer is None:
            return json.dumps({"error": "Optimizer not initialized"}, indent=2)

        try:
            # Call the underlying tool function
            result = await optimizer.call_tool(name, arguments)

            # If result is already a string, return it directly
            if isinstance(result, str):
                return result

            # Otherwise, convert to JSON
            return json.dumps({"result": result}, indent=2)
        except ValueError as e:
            return json.dumps({"error": str(e)}, indent=2)
        except Exception as e:
            logger.error(f"Error in google_workspace_call_tool: {e}", exc_info=True)
            return json.dumps({"error": str(e)}, indent=2)

    logger.info(
        "Registered 4 optimizer tools: find_tool, describe_tool, list_tools, call_tool"
    )
