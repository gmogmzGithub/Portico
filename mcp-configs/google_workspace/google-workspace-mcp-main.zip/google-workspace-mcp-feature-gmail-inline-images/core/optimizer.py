"""
Tool Optimizer for Google Workspace MCP Server

This module provides optional tool optimization through semantic search,
allowing LLMs to discover and use tools on-demand rather than loading
all tool schemas at once.

Requires: numpy, sentence-transformers
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading
from pathlib import Path
from typing import Optional, Any

try:
    import numpy as np

    # Check if sentence-transformers is available, but don't import yet (lazy load)
    import importlib.util

    _st_spec = importlib.util.find_spec("sentence_transformers")
    OPTIMIZER_AVAILABLE = _st_spec is not None
    del _st_spec
except ImportError:
    OPTIMIZER_AVAILABLE = False
    np = None

logger = logging.getLogger(__name__)

# Cache directory for embeddings
CACHE_DIR = Path(os.path.expanduser("~/.cache/google_workspace_mcp/optimizer"))
EMBEDDINGS_CACHE_FILE = CACHE_DIR / "tool_embeddings.npz"


class OptimizerNotReadyError(Exception):
    """Raised when optimizer embeddings are still being computed."""

    def __init__(self, message: str = "Optimizer is still initializing"):
        self.message = message
        self.retry_after_seconds = 3
        super().__init__(self.message)


class ToolOptimizer:
    """
    Optimizer that wraps a collection of tools for semantic search and on-demand retrieval.

    Initialization happens asynchronously in a background thread to avoid blocking
    server startup. Use is_ready() to check status or wait_until_ready() to block.
    """

    def __init__(self):
        if not OPTIMIZER_AVAILABLE:
            raise RuntimeError(
                "Optimizer mode requires numpy and sentence-transformers. "
                "Install with: pip install numpy sentence-transformers"
            )

        self.tools: dict[str, Any] = {}  # name -> tool definition
        self.tool_functions: dict[str, Any] = {}  # name -> actual tool function
        self.embeddings: Optional[np.ndarray] = None
        self.tool_names: list[str] = []
        self.embedding_model: Optional[Any] = None  # SentenceTransformer, lazy loaded
        self._initialized = False

        # Async initialization state
        self._embeddings_ready = threading.Event()
        self._init_error: Optional[Exception] = None
        self._init_thread: Optional[threading.Thread] = None

    def _compute_tools_hash(self, tools: dict[str, Any]) -> str:
        """Compute a hash of tool definitions for cache invalidation."""
        # Create a stable representation of tool names and descriptions
        tool_data = []
        for name in sorted(tools.keys()):
            tool = tools[name]
            tool_data.append(f"{name}:{tool.get('description', '')}")
        combined = "\n".join(tool_data)
        return hashlib.sha256(combined.encode()).hexdigest()[:16]

    def _load_cached_embeddings(
        self, tools_hash: str
    ) -> Optional[tuple[np.ndarray, list[str]]]:
        """Load embeddings from cache if valid."""
        if not EMBEDDINGS_CACHE_FILE.exists():
            return None

        try:
            data = np.load(EMBEDDINGS_CACHE_FILE, allow_pickle=True)
            cached_hash = str(data["tools_hash"])
            if cached_hash != tools_hash:
                logger.info("Cache invalidated: tools have changed")
                return None

            embeddings = data["embeddings"]
            tool_names = list(data["tool_names"])
            logger.info(f"Loaded cached embeddings for {len(tool_names)} tools")
            return embeddings, tool_names
        except Exception as e:
            logger.warning(f"Failed to load cached embeddings: {e}")
            return None

    def _save_embeddings_cache(
        self, embeddings: np.ndarray, tool_names: list[str], tools_hash: str
    ) -> None:
        """Save embeddings to cache."""
        try:
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            np.savez(
                EMBEDDINGS_CACHE_FILE,
                embeddings=embeddings,
                tool_names=np.array(tool_names, dtype=object),
                tools_hash=tools_hash,
            )
            logger.info(f"Saved embeddings cache to {EMBEDDINGS_CACHE_FILE}")
        except Exception as e:
            logger.warning(f"Failed to save embeddings cache: {e}")

    def initialize(self, tools: dict[str, Any], tool_functions: dict[str, Any]) -> None:
        """
        Initialize the optimizer with a collection of tools.

        This method returns immediately and performs embedding computation in a
        background thread. Use is_ready() to check status or wait_until_ready()
        to block until embeddings are available.

        Args:
            tools: Dictionary mapping tool names to tool definitions
                   Each tool should have 'name', 'description', 'inputSchema', and 'service'
            tool_functions: Dictionary mapping tool names to their actual callable functions
        """
        if self._initialized:
            logger.warning("Optimizer already initialized, skipping")
            return

        # Store tools immediately (these are available right away)
        self.tools = tools
        self.tool_functions = tool_functions
        self.tool_names = list(tools.keys())
        self._initialized = True

        logger.info(
            f"Initializing optimizer with {len(self.tool_names)} tools (background)"
        )

        # Start background initialization
        self._init_thread = threading.Thread(
            target=self._do_initialize_embeddings,
            name="optimizer-init",
            daemon=True,
        )
        self._init_thread.start()

    def _do_initialize_embeddings(self) -> None:
        """Background thread: load model and compute embeddings."""
        try:
            # Lazy import of sentence_transformers to avoid blocking main thread
            # This import is the heavy one (~5-8s) that loads PyTorch
            from sentence_transformers import SentenceTransformer

            # Determine device - default to CPU for reliability (MPS can be flaky)
            # Set OPTIMIZER_DEVICE=mps or OPTIMIZER_DEVICE=cuda to use GPU
            device = os.environ.get("OPTIMIZER_DEVICE", "cpu")

            # Compute hash for cache invalidation
            tools_hash = self._compute_tools_hash(self.tools)

            # Try to load from cache first
            cached = self._load_cached_embeddings(tools_hash)
            if cached is not None:
                embeddings, cached_tool_names = cached
                # Verify tool names match (order matters for embedding lookup)
                if cached_tool_names == self.tool_names:
                    self.embeddings = embeddings
                    # Only load model - skip embedding computation
                    logger.info(
                        f"Loading embedding model (all-MiniLM-L6-v2) on {device}..."
                    )
                    self.embedding_model = SentenceTransformer(
                        "all-MiniLM-L6-v2", device=device
                    )
                    self._embeddings_ready.set()
                    logger.info(
                        "Optimizer initialization complete (using cached embeddings)"
                    )
                    return
                else:
                    logger.info("Tool names changed, recomputing embeddings")

            # Initialize embedding model (using a small, fast model)
            logger.info(f"Loading embedding model (all-MiniLM-L6-v2) on {device}...")
            self.embedding_model = SentenceTransformer(
                "all-MiniLM-L6-v2", device=device
            )

            # Compute embeddings for all tools
            if self.tool_names:
                texts = []
                for name in self.tool_names:
                    tool = self.tools[name]
                    # Combine name and description for better semantic matching
                    text = f"{name}: {tool.get('description', '')}"
                    texts.append(text)

                logger.info("Computing embeddings for all tools...")
                self.embeddings = self.embedding_model.encode(
                    texts, convert_to_numpy=True
                )
                logger.info(f"Embeddings computed with shape {self.embeddings.shape}")

                # Save to cache for next time
                self._save_embeddings_cache(
                    self.embeddings, self.tool_names, tools_hash
                )

            self._embeddings_ready.set()
            logger.info("Optimizer initialization complete")

        except Exception as e:
            logger.error(f"Optimizer initialization failed: {e}", exc_info=True)
            self._init_error = e
            self._embeddings_ready.set()  # Unblock waiters even on error

    def is_ready(self) -> bool:
        """Check if embeddings are ready for semantic search."""
        return self._embeddings_ready.is_set() and self._init_error is None

    def wait_until_ready(self, timeout: Optional[float] = None) -> bool:
        """
        Block until embeddings are ready.

        Args:
            timeout: Maximum seconds to wait. None = wait forever.

        Returns:
            True if ready, False if timeout occurred.

        Raises:
            RuntimeError: If initialization failed with an error.
        """
        ready = self._embeddings_ready.wait(timeout=timeout)
        if ready and self._init_error is not None:
            raise RuntimeError(f"Optimizer initialization failed: {self._init_error}")
        return ready

    def find_similar_tools(self, query: str, top_k: int = 10) -> list[dict]:
        """
        Find tools similar to the query using semantic search.

        Args:
            query: Natural language description of what you're looking for
            top_k: Number of top matches to return

        Returns:
            List of dictionaries with 'name', 'excerpt', and 'score' keys

        Raises:
            OptimizerNotReadyError: If embeddings are still being computed
            RuntimeError: If initialization failed
        """
        if not self._initialized:
            raise RuntimeError("Optimizer not initialized")

        # Check if embeddings are ready
        if not self._embeddings_ready.is_set():
            raise OptimizerNotReadyError(
                "Optimizer is still loading embeddings. Please retry in a few seconds."
            )

        # Check for initialization error
        if self._init_error is not None:
            raise RuntimeError(f"Optimizer initialization failed: {self._init_error}")

        if self.embedding_model is None or self.embeddings is None:
            return []

        # Embed the query
        query_embedding = self.embedding_model.encode([query], convert_to_numpy=True)[0]

        # Compute cosine similarity
        # Normalize vectors
        query_norm = query_embedding / np.linalg.norm(query_embedding)
        embeddings_norm = self.embeddings / np.linalg.norm(
            self.embeddings, axis=1, keepdims=True
        )

        # Dot product gives cosine similarity for normalized vectors
        similarities = np.dot(embeddings_norm, query_norm)

        # Get top-k indices
        top_indices = np.argsort(similarities)[::-1][:top_k]

        results = []
        for idx in top_indices:
            name = self.tool_names[idx]
            tool = self.tools[name]
            desc = tool.get("description", "")
            # Truncate description for excerpt
            excerpt = desc[:150] + "..." if len(desc) > 150 else desc
            results.append(
                {"name": name, "excerpt": excerpt, "score": float(similarities[idx])}
            )

        return results

    def get_tool_definition(self, name: str) -> dict:
        """
        Get the full definition of a specific tool.

        This method works immediately after initialize() returns, without waiting
        for embeddings to be computed.

        Args:
            name: Name of the tool

        Returns:
            Dictionary with 'name', 'description', and 'inputSchema'

        Raises:
            ValueError: If tool not found
            RuntimeError: If optimizer not initialized
        """
        if not self._initialized:
            raise RuntimeError("Optimizer not initialized")

        if name not in self.tools:
            raise ValueError(f"Tool '{name}' not found")

        tool = self.tools[name]
        return {
            "name": tool.get("name", name),
            "description": tool.get("description", ""),
            "inputSchema": tool.get("inputSchema", {}),
        }

    def list_all_tools(self, service: Optional[str] = None) -> list[str]:
        """
        Get a list of all available tool names, optionally filtered by service.

        This method works immediately after initialize() returns, without waiting
        for embeddings to be computed.

        Args:
            service: Optional service name to filter by (e.g., 'gmail', 'docs', 'sheets')

        Returns:
            List of tool names
        """
        if not self._initialized:
            raise RuntimeError("Optimizer not initialized")

        if service is None:
            return self.tool_names.copy()

        # Filter tools by service
        filtered_tools = []
        for name in self.tool_names:
            tool = self.tools[name]
            tool_service = tool.get("service", "")
            if tool_service.lower() == service.lower():
                filtered_tools.append(name)

        return filtered_tools

    async def call_tool(self, name: str, arguments: dict) -> Any:
        """
        Execute a tool by name with the given arguments.

        This method works immediately after initialize() returns, without waiting
        for embeddings to be computed.

        Args:
            name: Name of the tool to call
            arguments: Dictionary of arguments to pass to the tool

        Returns:
            Result from the tool execution

        Raises:
            ValueError: If tool not found
            RuntimeError: If optimizer not initialized
        """
        if not self._initialized:
            raise RuntimeError("Optimizer not initialized")

        if name not in self.tool_functions:
            raise ValueError(f"Tool '{name}' not found")

        tool_func = self.tool_functions[name]

        # Call the tool function with unpacked arguments
        # Handle both sync and async functions
        import inspect

        if inspect.iscoroutinefunction(tool_func):
            result = await tool_func(**arguments)
        else:
            result = tool_func(**arguments)

        return result


# Global optimizer instance
_optimizer_instance: Optional[ToolOptimizer] = None


def get_optimizer() -> Optional[ToolOptimizer]:
    """Get the global optimizer instance."""
    return _optimizer_instance


def initialize_optimizer(
    tools: dict[str, Any], tool_functions: dict[str, Any]
) -> ToolOptimizer:
    """
    Initialize the global optimizer instance.

    Args:
        tools: Dictionary mapping tool names to tool definitions
        tool_functions: Dictionary mapping tool names to their callable functions

    Returns:
        The initialized optimizer instance
    """
    global _optimizer_instance

    if not OPTIMIZER_AVAILABLE:
        raise RuntimeError(
            "Optimizer mode requires numpy and sentence-transformers. "
            "Install with: pip install numpy sentence-transformers"
        )

    _optimizer_instance = ToolOptimizer()
    _optimizer_instance.initialize(tools, tool_functions)
    return _optimizer_instance


def is_optimizer_available() -> bool:
    """Check if optimizer dependencies are installed."""
    return OPTIMIZER_AVAILABLE
