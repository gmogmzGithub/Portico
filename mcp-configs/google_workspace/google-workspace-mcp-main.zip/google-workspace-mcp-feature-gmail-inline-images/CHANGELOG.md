# Changelog

All notable changes to this project (Indeed fork) are documented in this file.

## [0.2.0] - 2026-03-31

### Changed
- README: Make uvx the recommended installation method, move ToolHive down

### Fixed
- Comments: Paginate Drive API comments to return all results
- Docker: Ensure temp dir exists in docker-compose for `download_doc_image` (MCRET-8580)

## [0.1.9] - 2026-03-23

### Fixed
- Docker: Add `/tmp` volume mount for `download_doc_image` tool (MCRET-8580)
- Docker: Fix build - add `--no-project` to `uv run` for model download
- Docker: Fix build - skip project install during `uv sync`

## [0.1.8] - 2026-03-19

### Added
- uvx support for running the server without installing
- MCP permissions configuration (`mcp-permissions.json`)
- PKCE OAuth tests

### Fixed
- PKCE OAuth flow bug

## [0.1.7] - 2026-03-19

### Added
- `download_doc_image` tool for downloading images from Google Docs (MCRET-8580)

### Fixed
- CODEOWNERS syntax - use `@username` format on single line

## [0.1.6] - 2026-03-18

### Fixed
- Tab ID passthrough across multiple docs tools (MCRET-8632)
- Undo capture/replay `tab_id` and conditional `includeTabsContent` (MCRET-8632)

### Added
- `tab_id` support for reading/extraction tools (MCRET-8556)
- CODEOWNERS file

## [0.1.5] - 2026-02-06

### Fixed
- IPv6 host parsing in OAuth port detection
- Reduced excessive log noise

## [0.1.4] - 2026-01-14

### Added
- Upstream sync with workspace-mcp v1.7.1 (conditional formatting tools)
- Missing `gmail.settings.basic` scope for filter tools

### Fixed
- JSON array parsing in `tools_cli.py`

## [0.1.3] - 2026-01-09

### Fixed
- Gmail label tool documentation improved for agent clarity

## [0.1.2] - 2026-01-08

### Fixed
- `FieldInfo` JSON serialization error in Gmail label tools
- `Body` object serialization error in Gmail send/draft tools
- CLI parsing of `Optional[List]` parameters
- Test isolation issues in slides and drive tests

## [0.1.1] - 2025-12-18

### Added
- Docker image optimized for ToolHive integration
- Pre-download sentence-transformers model during Docker build
- Optimizer mode enabled by default in Docker image
- GitLab CI pipeline for Docker builds (Kaniko)
- Calendar improvements: RSVP, free/busy, available slots, OOO, focus time
- Slides styling and positioning tools
- High-level slides convenience tools (3 batches)
- ADR for CPU-only PyTorch decision
- Port resolution unit tests

### Fixed
- CPU-only PyTorch to fix CI OOM
- ToolHive port compatibility (port 18922)
- Timezone bug in `find_available_slots` working hours

## [0.1.0] - 2025-12-12

### Added
- Dynamic OAuth port detection from Host header
- Bundled OAuth client credentials as fallback
- `insert_markdown` tool with code blocks, blockquotes, HR support
- Document savepoint tools for safe editing
- Multi-tab support for Google Docs tools
- `get_tool_hints` tool for agent guidance
- `insert_list_item` tool for precise list insertion
- Atomic batch undo support for `batch_edit_doc`
- `convert_to_list` operation in `batch_edit_doc`
- `export_doc_as_markdown` tool
- Google Sheets: cell formatting, notes, borders, conditional formatting
- Google Sheets: row/column manipulation, sort, find & replace
- Google Sheets: `freeze_panes`, `merge_cells`, `batch_update_sheet`
- Google Sheets: `copy_range`, `append_sheet_values`, `read_sheet_formulas`
- Google Drive: `delete_drive_file` tool
- Slides: text extraction from `get_presentation`
- Calendar: recurrence support, `get_events_times_only`
- `tools_cli.py` for manual MCP tool testing
- Optimizer mode for large tool sets
- Integration test framework with real API calls
- Ruff linting and formatting (95 files)
- AGENTS.md development guide
- ADR-002: text-anchored comment API limitation

### Fixed
- `modify_event` preserving start/end times
- Heading search now case-insensitive by default
- `supportsAllDrives` handling in docs API calls
- `DocsErrorBuilder.invalid_param` -> `invalid_param_value`
- Tuple unpacking for `ensure_oauth_callback_available`
- Sheet name prefix handling in range parameters
- `clear_conditional_formatting` for default sheet (sheetId=0)
- JSON string parsing for `condition_values`

### Removed
- Deprecated `get_doc_section` and `get_text_formatting` tools
- Upstream publishing files (helm-chart, manifest.json, smithery.yaml)
