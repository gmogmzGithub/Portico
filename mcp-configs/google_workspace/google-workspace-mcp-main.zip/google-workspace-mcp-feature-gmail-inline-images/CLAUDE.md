Read and act on @AGENTS.md
