# Zoom API Integration Planning

**Created:** 2024-12-17  
**Status:** Planning (P2 - Future Work)  
**Prerequisite:** Calendar improvements Segment C (zoom_link parameter)

## Overview

This document outlines what's required to implement automatic Zoom meeting creation when scheduling calendar events. Currently, we only support adding an existing Zoom link to events. Full integration would automatically create Zoom meetings via the Zoom API.

---

## Current State

### What We Have
- `add_google_meet` parameter on `create_event` — creates Google Meet automatically
- Planned: `zoom_link` parameter — accepts user-provided Zoom URL

### What We Don't Have
- Automatic Zoom meeting creation
- Zoom OAuth credentials for Indeed
- Zoom API integration module

---

## Why We Can't Do This Today

The Google Calendar API's `conferenceData` field only supports conference solutions registered as Google Workspace Add-ons. While Zoom has a Calendar Add-on for the UI, **it cannot be triggered via the Calendar API**.

To create Zoom meetings programmatically, we need to use the **Zoom API directly**.

---

## Requirements for Full Zoom Integration

### 1. Zoom API Credentials

**Server-to-Server OAuth App (Recommended)**
- Create app at https://marketplace.zoom.us/
- App type: "Server-to-Server OAuth"
- No user interaction required for auth
- Uses client credentials grant

**Required Scopes:**
- `meeting:write:admin` or `meeting:write` — Create meetings
- `user:read:admin` — Get user info for meeting creation

**Open Questions:**
- [ ] Does Indeed have an existing Zoom Server-to-Server OAuth app?
- [ ] Who manages Indeed's Zoom admin account?
- [ ] What's the approval process for new Zoom apps?

### 2. Credential Storage

Options:
1. **Environment variables** — `ZOOM_CLIENT_ID`, `ZOOM_CLIENT_SECRET`, `ZOOM_ACCOUNT_ID`
2. **Bundled credentials** — Similar to `auth/bundled_credentials.py` pattern
3. **Secret manager** — For production deployment

### 3. New Module Structure

```
zoom/
├── __init__.py
├── zoom_auth.py          # OAuth token management
├── zoom_client.py        # API client wrapper
└── zoom_meetings.py      # Meeting creation logic
```

### 4. API Implementation

**Zoom Meeting Creation:**
```python
# POST https://api.zoom.us/v2/users/{userId}/meetings
{
    "topic": "Meeting Title",
    "type": 2,  # Scheduled meeting
    "start_time": "2024-12-20T10:00:00Z",
    "duration": 60,  # minutes
    "timezone": "America/Chicago",
    "settings": {
        "host_video": True,
        "participant_video": True,
        "join_before_host": True,
        "waiting_room": False,
        "auto_recording": "none"
    }
}
```

**Response includes:**
- `join_url` — URL for participants
- `start_url` — URL for host
- `password` — Meeting password
- `id` — Zoom meeting ID

### 5. Calendar Integration

```python
async def create_event(
    ...
    # Existing (Segment C):
    zoom_link: Optional[str] = None,
    
    # New (Zoom API integration):
    add_zoom_meeting: bool = False,
    zoom_topic: Optional[str] = None,  # Defaults to event summary
    zoom_password: bool = True,  # Auto-generate password
    zoom_waiting_room: bool = False,
    zoom_host_video: bool = True,
    zoom_participant_video: bool = True,
) -> str:
```

**Workflow:**
1. If `add_zoom_meeting=True`, call Zoom API to create meeting
2. Extract `join_url` and `password` from response
3. Add to calendar event `location` and `description`
4. Return confirmation with both calendar and Zoom links

---

## Implementation Estimate

| Task | Effort |
|------|--------|
| Zoom OAuth setup & credential management | 2-4 hours |
| Zoom API client module | 2-3 hours |
| Meeting creation logic | 2-3 hours |
| Calendar integration | 1-2 hours |
| Testing (unit + integration) | 2-3 hours |
| Documentation | 1 hour |
| **Total** | **10-16 hours** |

---

## Risks & Considerations

### Security
- Zoom credentials must be stored securely
- Server-to-Server OAuth creates meetings as admin user
- Need to handle meeting ownership correctly

### User Experience
- Zoom meeting creation adds latency to event creation
- Error handling if Zoom API fails (still create calendar event?)
- Rate limiting on Zoom API

### Organizational
- Need Zoom admin approval for app creation
- May need security review for new OAuth integration
- Zoom API terms of service compliance

---

## Alternative Approaches

### Option A: Personal Meeting IDs (Current Plan)
Users provide their PMI link via `zoom_link` parameter.
- ✅ No Zoom API needed
- ✅ Works immediately
- ❌ Users must know their PMI
- ❌ No unique meeting creation

### Option B: Zoom Calendar Add-on
Instruct users to install Zoom Calendar Add-on and use it via Google Calendar UI.
- ✅ No development needed
- ❌ Not automatable via API
- ❌ Requires manual user action

### Option C: Full Zoom API Integration (This Doc)
Automatic meeting creation via Zoom API.
- ✅ Full automation
- ✅ Unique meetings per event
- ❌ Requires Zoom credentials
- ❌ More complex implementation

---

## Next Steps

Before implementing:

1. **[ ] Identify Zoom Admin Contact** — Who manages Indeed's Zoom account?
2. **[ ] Check Existing Apps** — Does Indeed already have a Zoom Server-to-Server OAuth app?
3. **[ ] Security Review** — What's required for new OAuth integrations?
4. **[ ] Prioritization** — Is this higher priority than other calendar features?

---

## References

- [Zoom API - Create Meeting](https://developers.zoom.us/docs/api/meetings/#tag/meetings/POST/users/{userId}/meetings)
- [Zoom Server-to-Server OAuth](https://developers.zoom.us/docs/internal-apps/s2s-oauth/)
- [Zoom Meeting Types](https://developers.zoom.us/docs/api/meetings/#meeting-types)
- [Zoom API Rate Limits](https://developers.zoom.us/docs/api/rest/rate-limits/)




