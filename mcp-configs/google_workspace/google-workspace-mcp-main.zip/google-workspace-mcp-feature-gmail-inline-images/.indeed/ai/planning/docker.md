# Publish google-workspace-mcp as Docker Image

## Problem

Currently the MCP tool requires git clone + manual setup. To use with ToolHive effectively, we need a published Docker image that can be pulled and run consistently.

## Current State

- Dockerfile exists and works for local `docker-compose` usage
- Tool is currently run via `git clone` + `uv run main.py`
- No internal image registry integration yet
- Auth uses volume-mounted credentials (`store_creds:/app/store_creds`)

## Proposed Solution

Create an optimized Dockerfile for ToolHive and publish to Indeed's internal Docker registry (`harbor.indeed.tech` or `registry.corp.indeed.com`).

---

## Unknowns & Assumptions

### Assumptions (to validate during testing)

1. **ToolHive supports volume mounts** - We assume `thv run` can mount persistent volumes for credential storage
2. **OAuth callback accessible** - Container port 8000 can receive OAuth callbacks from browser
3. **Registry choice** - Using `harbor.indeed.tech/ai4dp/google-workspace-mcp` (common pattern from deepsearch)
4. **Image naming** - Following pattern `<registry>/<team>/<image-name>:<tag>`

### Unknowns

1. **ToolHive volume mount syntax** - Need to discover the exact `thv run` flags for volumes
2. **ToolHive port exposure** - How does ToolHive expose container ports for OAuth callbacks?
3. **ToolHive secrets handling** - Does ToolHive have its own secret injection that we should use instead?
4. **OAuth callback URL** - What URL will the browser redirect to? (localhost? ToolHive proxy?)

### Backup Plans

| If this fails... | Try this instead... |
|------------------|---------------------|
| Volume mounts don't work | Use `WORKSPACE_MCP_STATELESS_MODE=true` (session-only tokens, re-auth each time) |
| OAuth callback unreachable | Use `EXTERNAL_OAUTH21_PROVIDER=true` (ToolHive manages auth) |
| Harbor registry access issues | Use `registry.corp.indeed.com/ai4dp/...` instead |
| Port 8000 conflicts | Make port configurable via `PORT` env var (already supported) |

---

## Implementation Steps

### 1. Optimize Dockerfile

**File:** `Dockerfile`

**Changes:**
- Add multi-stage build for smaller image (optional optimization)
- Ensure `store_creds` directory has correct permissions
- Make entrypoint more flexible for ToolHive args
- Add labels for image metadata

**Current entrypoint:**
```dockerfile
ENTRYPOINT ["/bin/sh", "-c"]
CMD ["uv run main.py --transport streamable-http ${TOOL_TIER:+--tool-tier \"$TOOL_TIER\"} ${TOOLS:+--tools $TOOLS}"]
```

**Optimized entrypoint:**
```dockerfile
# More flexible - allows thv to pass args directly
ENTRYPOINT ["uv", "run", "main.py", "--transport", "streamable-http"]
CMD []
```

### 2. Create TOOLHIVE.md Documentation

**File:** `TOOLHIVE.md`

**Contents:**
- Quick start with `thv run`
- Volume mount instructions for persistent auth
- Environment variables reference
- First-time OAuth setup instructions
- Troubleshooting guide

### 3. Create Build Script

**File:** `scripts/docker-build.sh`

**Features:**
- Build image with proper tags (version + latest)
- Push to Indeed internal registry
- Support for CI/CD integration
- Version from `pyproject.toml` or git tag

**Example:**
```bash
#!/bin/bash
REGISTRY="harbor.indeed.tech"
IMAGE="ai4dp/google-workspace-mcp"
VERSION="${1:-$(git describe --tags --always)}"

docker build -t "${REGISTRY}/${IMAGE}:${VERSION}" -t "${REGISTRY}/${IMAGE}:latest" .
docker push "${REGISTRY}/${IMAGE}:${VERSION}"
docker push "${REGISTRY}/${IMAGE}:latest"
```

### 4. Add GitLab CI Pipeline (Optional)

**File:** `.gitlab-ci.yml` (or add to existing)

**Pattern from deepsearch:**
```yaml
build-docker:
  stage: build
  script:
    - docker login -u $CI_REGISTRY_USER -p $CI_REGISTRY_PASSWORD $CI_REGISTRY
    - docker build -t $CI_REGISTRY_IMAGE:$CI_COMMIT_SHORT_SHA .
    - docker push $CI_REGISTRY_IMAGE:$CI_COMMIT_SHORT_SHA
```

---

## Test Plan

### Phase 1: Local Docker Testing

1. **Build locally**
   ```bash
   docker build -t google-workspace-mcp:test .
   ```

2. **Run with docker-compose** (known working)
   ```bash
   docker-compose up
   # Verify: curl http://localhost:8000/health
   ```

3. **Test OAuth flow**
   - Open browser to trigger auth
   - Verify credentials saved to volume
   - Restart container, verify auth persists

### Phase 2: ToolHive Testing (Validate Assumptions)

1. **Basic run** - Does `thv run` work at all?
   ```bash
   thv run harbor.indeed.tech/ai4dp/google-workspace-mcp:latest
   ```

2. **Volume mount test** - Can we persist credentials?
   ```bash
   # Try various volume mount syntaxes
   thv run --volume ~/.google_workspace_mcp:/app/store_creds ...
   thv run -v ~/.google_workspace_mcp:/app/store_creds ...
   thv run --mount source=~/.google_workspace_mcp,target=/app/store_creds ...
   ```

3. **Port exposure test** - Can OAuth callback work?
   ```bash
   # Check if port is accessible
   curl http://localhost:8000/health
   # Try OAuth flow in browser
   ```

4. **Env var test** - Can we pass configuration?
   ```bash
   thv run -e TOOL_TIER=core -e PORT=9000 ...
   ```

### Phase 3: Auth Flow Validation

| Test Case | Expected Result | Fallback if Fails |
|-----------|-----------------|-------------------|
| First OAuth flow | Browser opens, user auths, tokens saved | Check callback URL accessibility |
| Container restart | Auth persists, no re-auth needed | Verify volume mount worked |
| Token refresh | Access token auto-refreshes via refresh token | Check refresh token was stored |
| 30-day idle | Refresh token still works | May need to re-auth (Google policy) |

### Phase 4: Registry Push Testing

1. **Manual push**
   ```bash
   docker login harbor.indeed.tech
   docker push harbor.indeed.tech/ai4dp/google-workspace-mcp:test
   ```

2. **Verify pull**
   ```bash
   docker pull harbor.indeed.tech/ai4dp/google-workspace-mcp:test
   ```

---

## Success Criteria

- [x] Image builds successfully
- [x] Image runs via `docker-compose` with persistent auth
- [ ] Image runs via `thv run` (basic functionality) - requires ToolHive testing
- [ ] OAuth flow works and tokens persist across restarts - requires manual testing
- [ ] Image published to Indeed internal registry - requires registry access
- [x] Documentation complete in `TOOLHIVE.md`
- [x] Build script works for local and CI use

---

## Files to Create/Modify

| File | Action | Purpose |
|------|--------|---------|
| `Dockerfile` | Modify | Optimize entrypoint for ToolHive |
| `TOOLHIVE.md` | Create | Usage documentation |
| `scripts/docker-build.sh` | Create | Build and push automation |
| `.gitlab-ci.yml` | Modify (optional) | CI/CD pipeline for auto-builds |

---

## Auth Modes Reference

The MCP server supports multiple auth modes. For ToolHive, we recommend:

### Primary: Volume-Mounted Credentials (Recommended)

```bash
# Assumes thv supports volume mounts
thv run \
  -v ~/.google_workspace_mcp/credentials:/app/store_creds \
  -e GOOGLE_MCP_CREDENTIALS_DIR=/app/store_creds \
  harbor.indeed.tech/ai4dp/google-workspace-mcp:latest
```

- User auths once via browser
- Tokens (including refresh token) persist on host
- Same experience as local `uv run main.py`

### Fallback A: Stateless Mode

```bash
thv run \
  -e MCP_ENABLE_OAUTH21=true \
  -e WORKSPACE_MCP_STATELESS_MODE=true \
  harbor.indeed.tech/ai4dp/google-workspace-mcp:latest
```

- No persistent storage needed
- Tokens live in memory only
- **Requires re-auth each session**

### Fallback B: External OAuth Provider

```bash
thv run \
  -e MCP_ENABLE_OAUTH21=true \
  -e EXTERNAL_OAUTH21_PROVIDER=true \
  harbor.indeed.tech/ai4dp/google-workspace-mcp:latest
```

- ToolHive manages OAuth via its proxy
- MCP server expects bearer tokens in headers
- Depends on ToolHive's OAuth support being configured

---

## Next Steps

1. Start with Dockerfile optimization
2. Create build script and test locally
3. Test with ToolHive to validate assumptions
4. Document findings in TOOLHIVE.md
5. Push to registry once validated
