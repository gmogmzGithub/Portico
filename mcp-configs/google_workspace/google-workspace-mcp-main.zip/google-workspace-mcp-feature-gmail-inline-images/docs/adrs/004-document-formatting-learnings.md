# 004. Document Formatting and Tool Usage Learnings

Date: 2024-12-13

## Status

Implemented (2024-12-13)

## Context

An LLM agent created a technical document ("MR Rework Analysis") using our Google Docs tools. The resulting document had significant formatting issues:

1. **Corrupted Table**: Two separate tables (Ecosystem Distribution and Domain Distribution) were merged into one table with garbled headers like "EcosystemDomain", "CountCount", and data like "69%11.9%"

2. **Orphaned Placeholder Text**: Text like `[Table insert`, `ed below]`, `[Metrics Table Below]`, and `[Ecosystem table insert` was left in the document, suggesting the agent was following a template but didn't clean up

3. **No Visual Styling**: Despite proper heading structure (H1, H2, H3), no visual formatting was applied - headings looked identical to body text

4. **Plain Technical Content**: File paths, code snippets, and technical terms were unformatted plain text

We investigated the root causes and documented learnings to improve future outcomes.

## Findings

### Tool Danger Zones

1. **`find_and_replace_doc` is dangerous for cleanup**: It operates globally without context. When attempting to delete orphaned "Ecos" text, it replaced ALL occurrences including valid "Ecosystem" text throughout the document.

2. **Undo doesn't persist across sessions**: The `undo_doc_operation` tool only works within a single CLI/MCP session. Mistakes made via disconnected tool calls are essentially permanent.

3. **Index-based deletions can fail across element boundaries**: Trying to delete text that spans paragraphs or touches table boundaries returns "Invalid deletion range" errors.

### Tool Success Patterns

1. **`modify_table` is excellent for fixes**: Cell-by-cell updates are safe and precise. This should be the recommended approach for table repairs.

2. **`format_all_occurrences` works well for consistent styling**: Safe for applying patterns like monospace fonts to file paths.

3. **Search-based positioning in `batch_edit_doc` is safer than index-based**: Using `search + position` avoids the drift issues with index-based operations.

### Tool Discovery Issues

The tool tiers configuration (`core/tool_tiers.yaml`) is missing many of the best document formatting tools:

**Currently in docs tier config:**
- Core: `get_doc_content`, `create_doc`, `modify_doc_text`
- Extended: `export_doc_to_pdf`, `search_docs`, `find_and_replace_doc`, `list_docs_in_folder`, `insert_doc_elements`

**Missing from tier config but highly useful:**
- `batch_edit_doc` (recommended batch editing tool!)
- `format_all_occurrences` (bulk formatting)
- `modify_table` (table cell updates)
- `debug_table_structure` (table inspection - in complete tier but unlisted)
- `create_table_with_data` (reliable table creation)
- `format_doc_text` (now removed/renamed?)
- Various list and heading tools

This means agents using tiered tool access may not discover the most useful formatting tools.

## Decision

### Implemented Changes (2024-12-13)

1. ✅ **Updated `tool_tiers.yaml`** to include missing formatting tools:
   - Added `batch_edit_doc` to core (recommended batch tool)
   - Added `format_all_occurrences` to extended
   - Added `modify_table` to extended
   - Added `create_table_with_data` to extended
   - Ensured `debug_table_structure` is in complete tier
   - Added new savepoint tools to extended tier

2. ✅ **Added `max_replacements` parameter to `find_and_replace_doc`**:
   - Limits the number of occurrences replaced
   - Example: `find_and_replace_doc(..., max_replacements=3)` replaces only first 3

3. ✅ **Added warnings to `find_and_replace_doc` docstring**:
   - Prominent ⚠️ WARNING about global operation
   - Safety features documented (preview, max_replacements, savepoints)
   - Clear comparison with `modify_doc_text` for single replacements

4. ✅ **Created savepoint tools for recovery**:
   - `create_doc_savepoint(document_id, name)`: Creates a named version checkpoint
   - `list_doc_savepoints(document_id)`: Lists available checkpoints
   - Uses Drive API's `keepForever` to preserve revisions
   - Savepoint names stored in file `appProperties`

5. ✅ **Auto-savepoint before risky operations**:
   - `find_and_replace_doc` now auto-creates a savepoint before global replacement
   - Controlled via `create_savepoint=True` (default) parameter
   - Response includes savepoint info with restore instructions
   - If something goes wrong: File → Version history → Restore this version

### Why Savepoints Instead of Programmatic Undo?

**Persistent undo was considered and rejected:**
- Stale data problem: Document may be edited externally between operation and undo
- Multi-document complexity: How to key, when to purge, orphaned entries?
- Concurrent access: Multiple agents/users with conflicting undo stacks
- False confidence: User thinks "I can undo" but undo silently corrupts document

**Google Drive Revisions API `restore()` doesn't exist:**
- API has `revisions.list()` and `revisions.get()` but **no `revisions.restore()`**
- To "restore" programmatically: export old revision → clear document → re-import
- This loses all formatting (export is plain text) and is destructive

**The savepoint approach is better:**
- Uses `keepForever=True` to create durable checkpoints
- User can restore via Google Docs UI (which does work!)
- No risk of stale data or concurrent access issues
- Response tells user exactly how to restore if needed

**The existing in-memory undo (via `history_manager.py`) still works for session-based undo:**
- It generates reverse operations (insert ↔ delete, etc.)
- It's atomic and preserves formatting
- Works within a session, sufficient for persistent MCP servers

### Future Actions

6. **Consider a "styling preset" system**: When creating content, automatically apply sensible styling

7. **Create a `format_doc_from_markdown` tool**: A single tool that takes Markdown input and creates a fully-styled Google Doc

8. **Tool consolidation**: 143 tools is overwhelming. Consider:
   - Combining related tools
   - Better categorization in prompts
   - Smart tool suggestion based on context

9. **Template-based document creation**: Provide template tools that handle common patterns

## Consequences

### Positive

- Agents will have access to better tools for formatting tasks (tool_tiers.yaml updated)
- Reduced risk of corrupted output from `find_and_replace_doc` (max_replacements, auto-savepoints)
- Clear recovery path when things go wrong (savepoint + version history instructions)
- Better warnings help agents choose safer alternatives

### Negative

- Savepoints consume storage (marked as keepForever, not auto-deleted)
- Slightly slower operations due to savepoint creation (can be disabled with `create_savepoint=False`)
- `max_replacements` is capped at 100 to prevent API overload (uses individual delete/insert operations)

### Note on Backward Compatibility

`find_and_replace_doc` now supports optional auto-savepoints. The Drive scope is requested
dynamically only when `create_savepoint=True` (default). If Drive scope is unavailable:
- A warning is logged
- The find/replace operation proceeds without a savepoint
- Users see guidance to either add Drive scope or use `create_savepoint=False`

This means existing integrations with only `docs` scope continue to work - they just won't
have the new savepoint safety feature.

## Alternatives Considered

1. **Do nothing**: Accept that document quality depends on agent skill. Rejected because the tools themselves contribute to failures.

2. **Remove dangerous tools**: Could remove `find_and_replace_doc` entirely. Rejected because it's useful when used correctly; better to add warnings.

3. **Mandatory styling on content creation**: Every `insert` operation automatically styles content. Rejected as too opinionated; better as opt-in feature.

## Related

- ADR 001: Auto-clean blank lines for lists (related cleanup behavior)
- ADR 003: Optimizer mode for large tool sets (tool discovery)
- `core/tool_tiers.yaml`: Tool tier configuration
- `core/optimizer.py`: Semantic tool search

## Appendix: Markdown Import Learnings (2024-12-14)

When using `insert_markdown` to import markdown content:

### Tables Need Blank Lines
Google's markdown parser requires a blank line before tables for proper recognition.

**This fails** (table rendered as text):
```markdown
**By Priority:**
| Tier | Count |
|------|-------|
| High | 10    |
```

**This works** (table rendered as native table):
```markdown
**By Priority:**

| Tier | Count |
|------|-------|
| High | 10    |
```

The `normalize_markdown_tables()` helper in `docs_helpers.py` automatically fixes this.

### Horizontal Rules
- Markdown `---` is recognized by Google's parser
- Rendered as a `borderBottom` paragraph style (not a native HR element)
- Looks correct visually but won't export back as `---`

### Links in Tables
- Links inside table cells are preserved during import
- The import extracts `textStyle.link` from each cell and reapplies after table creation

### Test with Example Docs
- `tests/example_docs/` contains realistic markdown documents for testing
- `MR_REVIEW_FINDINGS.md` - Large doc with 8 tables, lists, headings
- `ACTIONABLE_RECOMMENDATIONS.md` - Medium doc with nested structures
- `EXECUTIVE_BRIEF.md` - Simple doc for quick testing

## Appendix: Example Fixes Applied

During the investigation, these tools worked well for cleanup:

```python
# Style headings (batch_edit_doc with format operations)
{"type": "format", "search": "Executive Summary", "bold": True, "font_size": 16, "foreground_color": "#1a73e8"}

# Fix corrupted table cells (modify_table)
{"action": "update_cell", "row": 0, "column": 1, "text": "Count"}

# Format file paths (format_all_occurrences)
format_all_occurrences(search="output/", font_family="Roboto Mono", background_color="#f0f0f0")
```

These failed or caused issues:

```python
# Dangerous global replacement
find_and_replace_doc(find_text="Ecos", replace_text="")  # Broke valid "Ecosystem" text

# Index-based deletion across boundaries
{"type": "delete", "start_index": 7853, "end_index": 7859}  # Failed: invalid range
```

