# ADR 005: CPU-Only PyTorch for Docker Builds

## Status

Accepted

## Context

The MCP server's optimizer mode uses `sentence-transformers` for semantic tool discovery. This library depends on PyTorch, which by default includes CUDA libraries for GPU acceleration.

When building Docker images in GitLab CI using Kaniko, the build process was consistently getting OOMKilled (exit code 137) even with 16GB of memory allocated. The root cause was:

1. PyTorch's default installation includes ~2GB of NVIDIA CUDA libraries
2. Kaniko's "Taking snapshot of full filesystem" step requires holding the entire layer in memory
3. Combined with Python dependencies and the sentence-transformers model, this exceeded available memory

## Decision

Use CPU-only PyTorch by configuring `pyproject.toml` to use PyTorch's CPU-specific package index:

```toml
[[tool.uv.index]]
name = "pytorch-cpu"
url = "https://download.pytorch.org/whl/cpu"
explicit = true

[tool.uv.sources]
torch = { index = "pytorch-cpu" }
```

Key points:
- `explicit = true` ensures only `torch` uses this index, not transitive dependencies
- The lock file must be regenerated after this change

## Consequences

### Benefits

- **Smaller Docker image**: ~2GB reduction (no CUDA libraries)
- **Universal compatibility**: Works on any host without NVIDIA container runtime
- **CI builds succeed**: Kaniko can complete within memory limits
- **ToolHive friendly**: No GPU passthrough configuration required

### Trade-offs

- **Slightly slower inference**: CPU is slower than GPU for neural network inference
  - However, `all-MiniLM-L6-v2` is a tiny model (80MB)
  - Query embedding takes ~10-50ms on CPU (acceptable for interactive use)
  - Startup indexing of ~100 tools takes ~1-2 seconds

### Performance Analysis

The optimizer's workload is minimal:
- **Startup**: Embed ~100 tool descriptions once → ~1-2 seconds on CPU
- **Runtime**: Embed one search query per `find_tool()` call → ~10-50ms on CPU

GPU acceleration would be overkill for this use case. GPU benefits appear when processing thousands of documents or doing real-time batch inference.

## Alternatives Considered

1. **Increase CI memory further** (32GB, 64GB): Would work but wasteful; doesn't address image size
2. **Remove model pre-download**: Would cause slow first-run experience and network dependency
3. **Use a smaller embedding model**: Would sacrifice search quality
4. **Multi-stage Docker build**: More complex, still has memory issues during build

## References

- GitLab CI memory limits: https://indeed.atlassian.net/wiki/spaces/DeliveryTools/pages/198824896
- PyTorch CPU wheels: https://download.pytorch.org/whl/cpu
- sentence-transformers: https://www.sbert.net/

