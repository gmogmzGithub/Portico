# Google Slides MCP Tools - Feature Gap Analysis

**Date**: December 15, 2025  
**Updated**: December 15, 2025 (added high-level tools)
**Tested Presentation**: https://docs.google.com/presentation/d/1h8Pn31opxGMaiIEckOgR3UGavGzd-KMaRiW08vAnjQg/edit

## Summary

The Google Slides tools now include high-level convenience tools in addition to the raw batch API. The new tools hide the complexity of the Slides API and provide intuitive positioning helpers.

---

## Current Tools

### Core Tools
| Tool | Purpose | Status |
|------|---------|--------|
| `create_presentation` | Create new presentation | ✅ Works |
| `get_presentation` | Get presentation details | ✅ Works |
| `batch_update_presentation` | Apply batch API updates | ✅ Works (raw API) |
| `get_page` | Get slide details (basic) | ✅ Works |
| `get_page_thumbnail` | Get slide thumbnail URL | ✅ Works |
| `*_presentation_comment` | Comment operations | ✅ Works |

### NEW High-Level Tools (Added Dec 15, 2025)
| Tool | Purpose | Status |
|------|---------|--------|
| `add_slide` | Create slide with layout & position | ✅ NEW |
| `delete_slide` | Delete slide by ID or index | ✅ NEW |
| `duplicate_slide` | Copy slide to specific position | ✅ NEW |
| `add_text_box` | Add text with position helpers | ✅ NEW |
| `add_image` | Insert image from URL | ✅ NEW |
| `get_slide_details` | Full element info with positions | ✅ NEW |
| `list_layouts` | Show available layouts | ✅ NEW |

---

## Tested Operations (via batch_update_presentation)

All of these operations **work** but require knowing the Google Slides API format:

### Slide Operations
- ✅ Create blank slide: `{"createSlide": {"objectId": "...", "insertionIndex": N}}`
- ✅ Create slide with layout: `{"createSlide": {..., "slideLayoutReference": {"layoutId": "p4"}}}`
- ✅ Delete slide: `{"deleteObject": {"objectId": "slideId"}}`
- ✅ Reorder slides: `{"updateSlidesPosition": {"slideObjectIds": [...], "insertionIndex": N}}`
- ✅ Duplicate slide: `{"duplicateObject": {"objectId": "...", "objectIds": {...}}}`

### Text Operations
- ✅ Create text box: `{"createShape": {"shapeType": "TEXT_BOX", ...}}`
- ✅ Insert text: `{"insertText": {"objectId": "...", "text": "...", "insertionIndex": 0}}`
- ✅ Format text (bold, size): `{"updateTextStyle": {"style": {"bold": true, "fontSize": {...}}, "fields": "..."}}`
- ✅ Add hyperlinks: `{"updateTextStyle": {"style": {"link": {"url": "..."}}, "fields": "link"}}`
- ✅ Replace all text: `{"replaceAllText": {"containsText": {...}, "replaceText": "..."}}`

### Shape Operations  
- ✅ Create shapes: `{"createShape": {"shapeType": "RECTANGLE|ELLIPSE|...", ...}}`
- ✅ Change shape color: `{"updateShapeProperties": {"shapeProperties": {"shapeBackgroundFill": {...}}, "fields": "..."}}`
- ✅ Create lines: `{"createLine": {"lineCategory": "STRAIGHT", ...}}`

### Media Operations
- ✅ Insert image from URL: `{"createImage": {"url": "...", ...}}`
- ✅ Insert YouTube video: `{"createVideo": {"source": "YOUTUBE", "id": "videoId", ...}}`

### Table Operations
- ✅ Create table: `{"createTable": {"rows": N, "columns": M, ...}}`
- ✅ Insert text in cell: `{"insertText": {"cellLocation": {"rowIndex": R, "columnIndex": C}, ...}}`

### Speaker Notes
- ✅ Add speaker notes: `{"insertText": {"objectId": "speakerNotesId", ...}}`
  - **Note**: Requires finding the speaker notes object ID from `slideProperties.notesPage.notesProperties.speakerNotesObjectId`

---

## Feature Gaps & Improvement Suggestions

### Priority 1: High-Level Convenience Tools - ✅ DONE

| Tool | Purpose | Status |
|------|---------|--------|
| `add_slide` | Create slide with optional layout | ✅ Done |
| `delete_slide` | Delete a slide by ID or index | ✅ Done |
| `add_text_box` | Add text box with content | ✅ Done |
| `add_image` | Insert image from URL | ✅ Done |
| `duplicate_slide` | Copy a slide to position | ✅ Done |
| `list_layouts` | List available layouts | ✅ Done |
| `get_slide_details` | Full element info | ✅ Done |

### Priority 1b: Remaining High-Value Tools

| Suggested Tool | Purpose | Complexity |
|----------------|---------|------------|
| `add_shape` | Add shapes (rectangle, circle, etc.) | Medium |
| `update_text` | Modify existing text on slide | Medium |
| `format_text` | Apply formatting (bold, color, size) | Medium |
| `add_table` | Create and populate a table | High |
| `reorder_slides` | Change slide order | Low |

### Priority 2: Better Information Retrieval

| Gap | Current State | Improvement |
|-----|---------------|-------------|
| Layout info | Not shown | `get_presentation` should list available layouts |
| Element details | Basic info only | `get_page` should show colors, links, formatting |
| Speaker notes | Not shown | Add to `get_page` or new `get_speaker_notes` tool |
| Element positions | EMU units only | Convert to pixels or percentages |

### Priority 3: Missing Functionality

| Feature | Description |
|---------|-------------|
| **Template support** | Copy existing presentation as template |
| **Undo system** | Like gdocs has with `undo_doc_operation` |
| **Preview mode** | Show what changes would be made without applying |
| **List layouts** | New `get_presentation_layouts` tool |
| **Update title** | Simple `update_presentation_title` tool |
| **Master slides** | Tools to edit master slides |
| **Transitions** | Add slide transitions |
| **Animations** | Add object animations |
| **Charts** | Create and modify charts |
| **Word Art** | Create stylized text |

### Priority 4: Developer Experience

| Improvement | Description |
|-------------|-------------|
| **EMU helpers** | Convert pixels/inches to EMU units |
| **Position helpers** | Centering, alignment calculations |
| **Color helpers** | RGB hex to Google color format |
| **Batch builder** | Helper to construct batch requests |

---

## Known Issues / Bugs

### Bug 1: `get_page` Element Type Detection
The `get_page` tool shows "Unknown" type for images:
```
Element: ID image1, Type: Unknown
```
Should detect and report image elements properly.

### Bug 2: Missing Line Detection  
Lines created with `createLine` aren't shown in `get_page` element list.

### Bug 3: Table Text Not Shown
`get_presentation` doesn't extract/show text from table cells, only from shapes.

### Bug 4: Video Not Detected
Videos created with `createVideo` appear as unknown elements in `get_page`.

---

## Comparison with Google Docs Tools

| Feature | Docs | Slides |
|---------|------|--------|
| High-level edit tools | ✅ Many | ✅ 7 new tools |
| Preview mode | ✅ Yes | ❌ No |
| Undo system | ✅ Yes | ❌ No |
| Batch operations | ✅ batch_edit_doc | ✅ batch_update_presentation |
| Position helpers | N/A | ✅ Named positions |
| Layout support | N/A | ✅ list_layouts, add_slide |
| History tracking | ✅ Yes | ❌ No |
| Error handling | ✅ DocsErrorBuilder | ❌ Basic |

---

## Recommended Next Steps

### ✅ Completed (Dec 15, 2025)
- `add_slide` - with layout and position support
- `delete_slide` - by ID or index
- `duplicate_slide` - copy to specific position
- `add_text_box` - with position helpers
- `add_image` - insert from URL
- `list_layouts` - discover available layouts
- `get_slide_details` - full element info with positions
- EMU/position helper utilities (slides_helpers.py)

### Next Priority
1. **Quick wins** (1-2 days each):
   - `add_shape` - rectangles, circles, arrows
   - `reorder_slides` - change slide order
   - `add_speaker_notes` - add notes to slides
   - Fix `get_page` element type detection for images/videos

2. **Medium effort** (3-5 days each):
   - `add_table` with data population
   - `format_text` with common formatting options
   - `update_text` - modify existing text elements

3. **Higher effort** (1+ weeks):
   - Undo system
   - Preview mode
   - Template/copy presentation support

---

## Test Presentation Contents

The test presentation at the URL above contains examples of:
- Empty slide (slide 1)
- Slide with text box, image, rectangle, table, line, link (slide 2)
- Duplicated slide (slide 3)
- Slide created with layout + embedded YouTube video (slide 4)
- Speaker notes on slide 1

