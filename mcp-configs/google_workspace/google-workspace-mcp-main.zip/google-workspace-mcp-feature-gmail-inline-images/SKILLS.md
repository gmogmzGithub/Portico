# Google Workspace MCP - Agent Skills Guide

This guide contains critical knowledge for LLM agents using the Google Workspace MCP tools. Following these practices will help you avoid common mistakes and produce high-quality results.

---

## 🚨 Critical Safety Rules

### 1. Never Use `find_and_replace_doc` for Cleanup Without Preview

**WRONG:**
```python
# Trying to delete orphaned text - THIS IS DANGEROUS
find_and_replace_doc(find_text="TODO", replace_text="")
```

**RIGHT:**
```python
# ALWAYS preview first to see what will be affected
find_and_replace_doc(find_text="TODO", replace_text="", preview=True)

# If the preview looks safe, then proceed (with auto-savepoint):
find_and_replace_doc(find_text="TODO", replace_text="")
```

**Why:** `find_and_replace_doc` operates GLOBALLY. If you try to delete "Ecos" to clean up orphaned text, it will also break "Ecosystem" everywhere in the document.

### 2. Use `modify_doc_text` for Single Replacements

**WRONG:**
```python
# Global replacement when you only want to fix one instance
find_and_replace_doc(find_text="teh", replace_text="the")
```

**RIGHT:**
```python
# Target a specific occurrence
modify_doc_text(search="teh", position="replace", text="the", occurrence=1)
```

**Why:** `modify_doc_text` with `position="replace"` only affects ONE occurrence. Use `occurrence=1` for first, `occurrence=-1` for last.

### 3. Create Savepoints Before Major Changes

Before making significant edits to an important document:

```python
# Create a named checkpoint
create_doc_savepoint(document_id="...", name="Before reformatting")

# Now make your changes...
# If something goes wrong, tell the user:
# "You can restore from: File → Version history → See version history"
```

Note: `find_and_replace_doc` automatically creates savepoints by default.

---

## 📝 Document Formatting Best Practices

### Use `batch_edit_doc` for Multiple Operations

**WRONG:**
```python
# Multiple individual calls - slow and error-prone
modify_doc_text(search="Introduction", bold=True)
modify_doc_text(search="Conclusion", bold=True)
modify_doc_text(search="Summary", bold=True)
```

**RIGHT:**
```python
# Single batch call - atomic and efficient
batch_edit_doc(
    document_id="...",
    operations=[
        {"type": "format", "search": "Introduction", "bold": True, "font_size": 16},
        {"type": "format", "search": "Conclusion", "bold": True, "font_size": 16},
        {"type": "format", "search": "Summary", "bold": True, "font_size": 16},
    ]
)
```

### Use Search-Based Positioning, Not Index-Based

**WRONG:**
```python
# Index-based - fragile, indices shift as document changes
modify_doc_text(start_index=150, end_index=160, bold=True)
```

**RIGHT:**
```python
# Search-based - finds text by content, resilient to changes
modify_doc_text(search="Important Note", bold=True)
```

**Why:** Index positions change when text is added/removed. Search-based positioning finds text by content.

### Style Headings Consistently

When creating documents, apply visual styling to headings:

```python
batch_edit_doc(
    document_id="...",
    operations=[
        # H1 - Large, bold, colored
        {"type": "format", "search": "Main Title", "bold": True, "font_size": 24, "foreground_color": "#1a73e8"},
        # H2 - Medium, bold
        {"type": "format", "search": "Section Header", "bold": True, "font_size": 18, "foreground_color": "#1967d2"},
        # H3 - Smaller, bold
        {"type": "format", "search": "Subsection", "bold": True, "font_size": 14},
    ]
)
```

---

## 📊 Table Operations

### Use `modify_table` for Cell Updates

**WRONG:**
```python
# Trying to fix table data with find_and_replace
find_and_replace_doc(find_text="wrong data", replace_text="correct data")
```

**RIGHT:**
```python
# Precise cell-by-cell updates
modify_table(
    document_id="...",
    table_index=0,
    action="update_cell",
    row=1,
    column=2,
    text="correct data"
)
```

### Debug Table Structure First

Before modifying tables, understand their structure:

```python
# See the actual table layout
debug_table_structure(document_id="...", table_index=0)
```

This shows you:
- Number of rows and columns
- Cell contents
- Merged cells
- Header rows

### Create Tables with Data in One Call

**WRONG:**
```python
# Create empty table, then try to fill cells individually
insert_doc_elements(elements=[{"type": "table", "rows": 3, "columns": 3}])
# Then multiple modify_table calls...
```

**RIGHT:**
```python
# Create table with data in one operation
create_table_with_data(
    document_id="...",
    headers=["Name", "Count", "Percentage"],
    rows=[
        ["Python", "150", "45%"],
        ["JavaScript", "120", "36%"],
        ["Go", "63", "19%"],
    ],
    location="end"
)
```

---

## 🔧 Error Recovery

### When Things Go Wrong

1. **Check if a savepoint exists:**
   ```python
   list_doc_savepoints(document_id="...")
   ```

2. **Tell the user how to restore:**
   > "A savepoint was created before the operation. To restore:
   > File → Version history → See version history → Find the savepoint → Restore this version"

3. **For in-session mistakes, try undo:**
   ```python
   undo_doc_operation(document_id="...")
   ```
   Note: This only works within the same MCP session.

### Common Errors and Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| "Invalid deletion range" | Trying to delete across element boundaries (e.g., into a table) | Use search-based operations or work within a single paragraph |
| "Index out of bounds" | Document changed since you calculated indices | Re-read document and recalculate, or use search-based positioning |
| "No occurrences found" | Text doesn't exist or case mismatch | Check with `get_doc_content`, consider `match_case=False` |

---

## 📋 Tool Selection Guide

### For Text Operations

| Goal | Use This Tool |
|------|---------------|
| Add text at end of document | `modify_doc_text(location="end", text="...")` |
| Replace ONE occurrence | `modify_doc_text(search="...", position="replace", text="...")` |
| Replace ALL occurrences | `find_and_replace_doc(find_text="...", replace_text="...", preview=True)` first! |
| Format specific text | `modify_doc_text(search="...", bold=True, ...)` |
| Format ALL occurrences of text | `format_all_occurrences(search="...", bold=True)` |
| Multiple operations at once | `batch_edit_doc(operations=[...])` |

### For Tables

| Goal | Use This Tool |
|------|---------------|
| Create table with data | `create_table_with_data(...)` |
| Update a cell | `modify_table(action="update_cell", ...)` |
| Add/delete rows/columns | `modify_table(action="add_row"/"delete_column"/...)` |
| Understand table structure | `debug_table_structure(...)` |

### For Safety

| Goal | Use This Tool |
|------|---------------|
| Create checkpoint before risky edit | `create_doc_savepoint(name="...")` |
| List available checkpoints | `list_doc_savepoints(...)` |
| Preview what will change | Add `preview=True` to most write operations |
| Undo last operation (same session) | `undo_doc_operation(...)` |

---

## ✅ Pre-Flight Checklist

Before making document changes, ask yourself:

1. **Do I understand the current document state?**
   - Have I read the document with `get_doc_content`?
   - For tables, have I used `debug_table_structure`?

2. **Am I using the right tool?**
   - Single replacement → `modify_doc_text` with `position="replace"`
   - Global replacement → `find_and_replace_doc` (with preview first!)
   - Multiple operations → `batch_edit_doc`

3. **Am I using safe positioning?**
   - Prefer `search` over `start_index/end_index`
   - Prefer `location="end"` over calculating indices

4. **Have I previewed the operation?**
   - For `find_and_replace_doc`: use `preview=True`
   - For `batch_edit_doc`: use `preview=True`

5. **Is there a savepoint?**
   - For important documents, create one with `create_doc_savepoint`
   - `find_and_replace_doc` creates one automatically

---

## 🎨 Styling Conventions

When creating well-formatted documents, apply these patterns:

### Headings
- **H1**: Bold, 24pt, color #1a73e8 (Google Blue)
- **H2**: Bold, 18pt, color #1967d2
- **H3**: Bold, 14pt, default color

### Code/Technical Content
- Font: `Roboto Mono` or `Courier New`
- Background: `#f5f5f5` (light gray)
- Use `format_all_occurrences` for file paths, function names

### Tables
- Header row: Bold, background color
- Alternating row colors for readability (if supported)

---

## 📚 Quick Reference

```python
# Read document
get_doc_content(document_id="...")

# Add text at end
modify_doc_text(document_id="...", location="end", text="New content")

# Replace single occurrence
modify_doc_text(document_id="...", search="old", position="replace", text="new")

# Format text
modify_doc_text(document_id="...", search="important", bold=True, foreground_color="red")

# Global replace (ALWAYS preview first!)
find_and_replace_doc(document_id="...", find_text="old", replace_text="new", preview=True)

# Batch operations
batch_edit_doc(document_id="...", operations=[...], preview=True)

# Create savepoint
create_doc_savepoint(document_id="...", name="Before major changes")

# Fix table cell
modify_table(document_id="...", table_index=0, action="update_cell", row=1, column=2, text="fixed")
```

---

*This guide should be followed whenever interacting with Google Docs through the MCP tools. When in doubt, use preview mode and create savepoints.*

