"""
Unit tests for slides helper functions.

Tests the helper functions in gslides/slides_helpers.py including:
- create_text_style_requests: API request generation
- hex_to_slides_color: Hex to RGB conversion
- color_to_hex: RGB to hex conversion
- Unit conversions (inches to EMU)
- get_element_bounds: Extract position/size from element
"""

from gslides.slides_helpers import (
    create_text_style_requests,
    color_to_hex,
    hex_to_slides_color,
    inches_to_emu,
    emu_to_inches,
    get_element_bounds,
    calculate_position,
    get_element_type,
    extract_text_from_shape,
    SLIDE_WIDTH_EMU,
    SLIDE_HEIGHT_EMU,
)


class TestColorConversion:
    """Tests for color conversion functions."""

    def test_hex_to_slides_color_basic(self):
        """Test basic hex to RGB color conversion."""
        result = hex_to_slides_color("#FF0000")
        assert result == {"rgbColor": {"red": 1.0, "green": 0.0, "blue": 0.0}}

    def test_hex_to_slides_color_white(self):
        """Test white color conversion."""
        result = hex_to_slides_color("#FFFFFF")
        assert result == {"rgbColor": {"red": 1.0, "green": 1.0, "blue": 1.0}}

    def test_hex_to_slides_color_black(self):
        """Test black color conversion."""
        result = hex_to_slides_color("#000000")
        assert result == {"rgbColor": {"red": 0.0, "green": 0.0, "blue": 0.0}}

    def test_hex_to_slides_color_mixed(self):
        """Test mixed color conversion."""
        result = hex_to_slides_color("#80FF40")
        rgb = result["rgbColor"]
        assert abs(rgb["red"] - 0.502) < 0.01  # 128/255
        assert rgb["green"] == 1.0  # 255/255
        assert abs(rgb["blue"] - 0.251) < 0.01  # 64/255

    def test_hex_to_slides_color_without_hash(self):
        """Test hex without leading hash."""
        result = hex_to_slides_color("FF0000")
        assert result == {"rgbColor": {"red": 1.0, "green": 0.0, "blue": 0.0}}

    def test_color_to_hex_from_opaque_color(self):
        """Test RGB to hex conversion with full Slides API format."""
        # color_to_hex expects the Slides API format with opaqueColor wrapper
        color_dict = {
            "opaqueColor": {"rgbColor": {"red": 1.0, "green": 0.0, "blue": 0.0}}
        }
        result = color_to_hex(color_dict)
        assert result.lower() == "#ff0000"

    def test_color_to_hex_white(self):
        """Test white RGB to hex."""
        color_dict = {
            "opaqueColor": {"rgbColor": {"red": 1.0, "green": 1.0, "blue": 1.0}}
        }
        result = color_to_hex(color_dict)
        assert result.lower() == "#ffffff"

    def test_color_to_hex_none_for_empty(self):
        """Test that empty dict returns None."""
        result = color_to_hex({})
        assert result is None

    def test_color_to_hex_none_for_none_input(self):
        """Test that None input returns None."""
        result = color_to_hex(None)
        assert result is None


class TestUnitConversion:
    """Tests for unit conversion functions."""

    def test_inches_to_emu(self):
        """Test inches to EMU conversion."""
        # 1 inch = 914400 EMU
        assert inches_to_emu(1.0) == 914400
        assert inches_to_emu(0.5) == 457200
        assert inches_to_emu(2.0) == 1828800

    def test_emu_to_inches(self):
        """Test EMU to inches conversion."""
        assert emu_to_inches(914400) == 1.0
        assert emu_to_inches(457200) == 0.5
        assert emu_to_inches(1828800) == 2.0


class TestGetElementBounds:
    """Tests for get_element_bounds function."""

    def test_get_element_bounds_basic(self):
        """Test extracting bounds from element with transform."""
        element = {
            "transform": {
                "translateX": 914400,  # 1 inch
                "translateY": 1828800,  # 2 inches
            },
            "size": {
                "width": {"magnitude": 914400, "unit": "EMU"},
                "height": {"magnitude": 457200, "unit": "EMU"},
            },
        }
        bounds = get_element_bounds(element)
        assert bounds["x_inches"] == 1.0
        assert bounds["y_inches"] == 2.0
        assert bounds["width_inches"] == 1.0
        assert bounds["height_inches"] == 0.5

    def test_get_element_bounds_no_size(self):
        """Test element without size returns None."""
        element = {"transform": {"translateX": 914400, "translateY": 914400}}
        bounds = get_element_bounds(element)
        assert bounds is None

    def test_get_element_bounds_with_zero_transform(self):
        """Test element with zero/missing transform values."""
        element = {
            "transform": {
                "translateX": 0,
                "translateY": 0,
            },
            "size": {
                "width": {"magnitude": 914400, "unit": "EMU"},
                "height": {"magnitude": 457200, "unit": "EMU"},
            },
        }
        bounds = get_element_bounds(element)
        assert bounds["x_inches"] == 0.0
        assert bounds["y_inches"] == 0.0


class TestCreateTextStyleRequests:
    """Tests for create_text_style_requests function."""

    def test_create_requests_font_family(self):
        """Test creating requests with font family."""
        requests = create_text_style_requests(
            element_id="test_elem",
            font_family="Noto Sans",
        )
        assert len(requests) == 1
        req = requests[0]["updateTextStyle"]
        assert req["objectId"] == "test_elem"
        assert req["style"]["weightedFontFamily"]["fontFamily"] == "Noto Sans"
        assert "weightedFontFamily" in req["fields"]

    def test_create_requests_font_family_with_weight(self):
        """Test creating requests with font family and weight."""
        requests = create_text_style_requests(
            element_id="test_elem",
            font_family="Noto Sans",
            font_weight=300,
        )
        assert len(requests) == 1
        req = requests[0]["updateTextStyle"]
        wff = req["style"]["weightedFontFamily"]
        assert wff["fontFamily"] == "Noto Sans"
        assert wff["weight"] == 300

    def test_create_requests_font_size(self):
        """Test creating requests with font size."""
        requests = create_text_style_requests(
            element_id="test_elem",
            font_size_pt=24,
        )
        assert len(requests) == 1
        req = requests[0]["updateTextStyle"]
        assert req["style"]["fontSize"]["magnitude"] == 24
        assert req["style"]["fontSize"]["unit"] == "PT"
        assert "fontSize" in req["fields"]

    def test_create_requests_font_color_hex(self):
        """Test creating requests with hex font color."""
        requests = create_text_style_requests(
            element_id="test_elem",
            font_color="#FF0000",
        )
        assert len(requests) == 1
        req = requests[0]["updateTextStyle"]
        fg = req["style"]["foregroundColor"]
        assert "opaqueColor" in fg
        assert fg["opaqueColor"]["rgbColor"]["red"] == 1.0
        assert "foregroundColor" in req["fields"]

    def test_create_requests_bold(self):
        """Test creating requests with bold."""
        requests = create_text_style_requests(
            element_id="test_elem",
            bold=True,
        )
        assert len(requests) == 1
        req = requests[0]["updateTextStyle"]
        assert req["style"]["bold"] is True
        assert "bold" in req["fields"]

    def test_create_requests_italic(self):
        """Test creating requests with italic."""
        requests = create_text_style_requests(
            element_id="test_elem",
            italic=True,
        )
        assert len(requests) == 1
        req = requests[0]["updateTextStyle"]
        assert req["style"]["italic"] is True
        assert "italic" in req["fields"]

    def test_create_requests_underline(self):
        """Test creating requests with underline."""
        requests = create_text_style_requests(
            element_id="test_elem",
            underline=True,
        )
        assert len(requests) == 1
        req = requests[0]["updateTextStyle"]
        assert req["style"]["underline"] is True
        assert "underline" in req["fields"]

    def test_create_requests_combined(self):
        """Test creating requests with multiple style options."""
        requests = create_text_style_requests(
            element_id="test_elem",
            font_family="Arial",
            font_size_pt=16,
            bold=True,
            font_color="#0000FF",
        )
        assert len(requests) == 1
        req = requests[0]["updateTextStyle"]
        assert req["style"]["weightedFontFamily"]["fontFamily"] == "Arial"
        assert req["style"]["fontSize"]["magnitude"] == 16
        assert req["style"]["bold"] is True
        assert "opaqueColor" in req["style"]["foregroundColor"]

    def test_create_requests_empty_returns_empty(self):
        """Test that no parameters returns empty list."""
        requests = create_text_style_requests(element_id="test_elem")
        assert requests == []

    def test_create_requests_line_spacing(self):
        """Test creating requests with line spacing (paragraph style)."""
        requests = create_text_style_requests(
            element_id="test_elem",
            line_spacing=150,
        )
        # Line spacing creates a paragraph style request
        assert len(requests) == 1
        req = requests[0]["updateParagraphStyle"]
        assert req["style"]["lineSpacing"] == 150
        assert "lineSpacing" in req["fields"]

    def test_create_requests_text_range_all(self):
        """Test that requests use ALL text range."""
        requests = create_text_style_requests(
            element_id="test_elem",
            bold=True,
        )
        req = requests[0]["updateTextStyle"]
        assert req["textRange"]["type"] == "ALL"


class TestResolveEffectiveTextStyle:
    """Tests for resolve_effective_text_style helper function."""

    def test_resolve_explicit_style(self):
        """Test resolving style from explicit text run properties."""
        from gslides.slides_helpers import resolve_effective_text_style

        element = {
            "objectId": "text_elem",
            "shape": {
                "text": {
                    "textElements": [
                        {"paragraphMarker": {"style": {}}},
                        {
                            "textRun": {
                                "content": "Hello\n",
                                "style": {
                                    "weightedFontFamily": {
                                        "fontFamily": "Noto Sans",
                                        "weight": 400,
                                    },
                                    "fontSize": {"magnitude": 24, "unit": "PT"},
                                    "bold": True,
                                },
                            }
                        },
                    ]
                }
            },
        }

        presentation = {
            "slides": [{"objectId": "slide_1", "pageElements": [element]}],
            "layouts": [],
            "masters": [],
        }

        # Correct signature: resolve_effective_text_style(presentation, element)
        result = resolve_effective_text_style(presentation, element)

        assert result["font_family"] == "Noto Sans"
        assert result["font_size_pt"] == 24
        assert result["bold"] is True

    def test_resolve_returns_defaults_for_missing_style(self):
        """Test that missing style properties return defaults."""
        from gslides.slides_helpers import resolve_effective_text_style

        element = {
            "objectId": "text_elem",
            "shape": {
                "text": {
                    "textElements": [
                        {"paragraphMarker": {"style": {}}},
                        {
                            "textRun": {
                                "content": "Hello\n",
                                "style": {},  # Empty style
                            }
                        },
                    ]
                }
            },
        }

        presentation = {
            "slides": [{"objectId": "slide_1", "pageElements": [element]}],
            "layouts": [],
            "masters": [],
        }

        # Correct signature: resolve_effective_text_style(presentation, element)
        result = resolve_effective_text_style(presentation, element)

        # Function returns defaults when no explicit style is set
        assert "font_family" in result
        assert "font_size_pt" in result
        assert "font_color" in result

    def test_resolve_inherits_from_placeholder(self):
        """Test that style can be inherited from placeholder in layout."""
        from gslides.slides_helpers import resolve_effective_text_style

        # Element with placeholder reference
        element = {
            "objectId": "text_elem",
            "shape": {
                "placeholder": {"type": "TITLE", "parentObjectId": "layout_title"},
                "text": {
                    "textElements": [
                        {"paragraphMarker": {"style": {}}},
                        {
                            "textRun": {
                                "content": "Hello\n",
                                "style": {},  # No explicit style - should inherit
                            }
                        },
                    ]
                },
            },
        }

        # Layout with placeholder style
        layout_placeholder = {
            "objectId": "layout_title",
            "shape": {
                "text": {
                    "textElements": [
                        {"paragraphMarker": {"style": {}}},
                        {
                            "textRun": {
                                "content": "",
                                "style": {
                                    "weightedFontFamily": {
                                        "fontFamily": "Georgia",
                                        "weight": 400,
                                    },
                                    "fontSize": {"magnitude": 32, "unit": "PT"},
                                },
                            }
                        },
                    ]
                }
            },
        }

        presentation = {
            "slides": [{"objectId": "slide_1", "pageElements": [element]}],
            "layouts": [
                {
                    "objectId": "layout_1",
                    "pageElements": [layout_placeholder],
                    "layoutProperties": {"name": "TITLE"},
                }
            ],
            "masters": [],
        }

        result = resolve_effective_text_style(presentation, element)

        # Should return some style (either inherited or default)
        assert "font_family" in result
        assert result.get("font_family") is not None


class TestCalculatePosition:
    """Tests for calculate_position function."""

    def test_calculate_position_center(self):
        """Test center position calculation."""
        width = 1000
        height = 1000
        x, y = calculate_position("center", width, height)

        expected_x = (SLIDE_WIDTH_EMU - width) // 2
        expected_y = (SLIDE_HEIGHT_EMU - height) // 2
        assert x == expected_x
        assert y == expected_y

    def test_calculate_position_top_left(self):
        """Test top-left position calculation."""
        x, y = calculate_position("top-left", 1000, 1000, margin_emu=500)
        assert x == 500
        assert y == 500

    def test_calculate_position_bottom_right(self):
        """Test bottom-right position calculation."""
        width = 1000
        height = 1000
        margin = 500
        x, y = calculate_position("bottom-right", width, height, margin_emu=margin)

        expected_x = SLIDE_WIDTH_EMU - width - margin
        expected_y = SLIDE_HEIGHT_EMU - height - margin
        assert x == expected_x
        assert y == expected_y

    def test_calculate_position_case_insensitive(self):
        """Test case insensitivity and underscore handling."""
        x1, y1 = calculate_position("TOP_LEFT", 1000, 1000)
        x2, y2 = calculate_position("top-left", 1000, 1000)
        assert x1 == x2
        assert y1 == y2


class TestGetElementType:
    """Tests for get_element_type function."""

    def test_get_element_type_text_box(self):
        """Test identifying text box."""
        element = {"shape": {"shapeType": "TEXT_BOX"}}
        assert get_element_type(element) == "text_box"

    def test_get_element_type_shape(self):
        """Test identifying generic shape."""
        element = {"shape": {"shapeType": "RECTANGLE"}}
        assert get_element_type(element) == "shape:rectangle"

    def test_get_element_type_image(self):
        """Test identifying image."""
        element = {"image": {}}
        assert get_element_type(element) == "image"

    def test_get_element_type_table(self):
        """Test identifying table."""
        element = {"table": {}}
        assert get_element_type(element) == "table"

    def test_get_element_type_unknown(self):
        """Test identifying unknown type."""
        element = {}
        assert get_element_type(element) == "unknown"


class TestExtractTextFromShape:
    """Tests for extract_text_from_shape function."""

    def test_extract_text_simple(self):
        """Test extracting simple text."""
        shape = {
            "text": {
                "textElements": [
                    {"textRun": {"content": "Hello World\n", "startIndex": 0}}
                ]
            }
        }
        assert extract_text_from_shape(shape) == "Hello World"

    def test_extract_text_multiple_runs(self):
        """Test extracting text from multiple runs."""
        shape = {
            "text": {
                "textElements": [
                    {"textRun": {"content": "Hello ", "startIndex": 0}},
                    {"textRun": {"content": "World\n", "startIndex": 6}},
                ]
            }
        }
        assert extract_text_from_shape(shape) == "Hello World"

    def test_extract_text_empty(self):
        """Test extracting from empty shape."""
        assert extract_text_from_shape({}) == ""

    def test_extract_text_no_text_elements(self):
        """Test extracting from shape with no text elements."""
        shape = {"text": {"textElements": []}}
        assert extract_text_from_shape(shape) == ""
