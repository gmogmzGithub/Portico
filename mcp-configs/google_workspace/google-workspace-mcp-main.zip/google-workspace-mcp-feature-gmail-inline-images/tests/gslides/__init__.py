"""Tests for Google Slides tools."""
