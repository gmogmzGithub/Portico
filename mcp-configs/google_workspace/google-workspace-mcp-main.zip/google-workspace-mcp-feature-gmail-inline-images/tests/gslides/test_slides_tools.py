"""
Unit tests for Google Slides tools.

Tests the tools in gslides/slides_tools.py including:
- move_element: Position element on slide
- get_presentation_theme: Get theme info
- insert_text_with_style: Insert styled text
- add_bullet_list: Add bulleted/numbered lists
- set_slide_background: Set slide background color/image
- replace_all_text: Find and replace text
- add_link: Add hyperlinks
- copy_presentation: Copy a presentation

These tests mock the Google API service and verify correct request generation.
"""

import pytest
from unittest.mock import MagicMock, patch


def create_mock_presentation(
    slides=None,
    layouts=None,
    masters=None,
    theme=None,
):
    """Create a mock presentation structure."""
    return {
        "presentationId": "test_pres_id",
        "title": "Test Presentation",
        "slides": slides or [],
        "layouts": layouts or [],
        "masters": masters or [],
        "theme": theme or {},
    }


def create_mock_slide(
    slide_id="slide_1",
    elements=None,
    layout_id="layout_1",
):
    """Create a mock slide structure."""
    return {
        "objectId": slide_id,
        "pageElements": elements or [],
        "slideProperties": {
            "layoutObjectId": layout_id,
        },
    }


def create_mock_text_element(
    element_id="elem_1",
    text="Sample Text",
    placeholder_type=None,
    parent_placeholder_id=None,
    font_family=None,
    font_size_pt=None,
    bold=None,
    transform_x=0,
    transform_y=0,
):
    """Create a mock text element (shape with text)."""
    text_style = {}
    if font_family:
        text_style["weightedFontFamily"] = {"fontFamily": font_family, "weight": 400}
    if font_size_pt:
        text_style["fontSize"] = {"magnitude": font_size_pt, "unit": "PT"}
    if bold is not None:
        text_style["bold"] = bold

    shape = {
        "text": {
            "textElements": [
                {"paragraphMarker": {"style": {}}},
                {
                    "textRun": {
                        "content": text + "\n",
                        "style": text_style,
                    }
                },
            ]
        }
    }

    if placeholder_type:
        shape["placeholder"] = {
            "type": placeholder_type,
            "parentObjectId": parent_placeholder_id,
        }

    return {
        "objectId": element_id,
        "shape": shape,
        "transform": {
            "translateX": transform_x,
            "translateY": transform_y,
            "scaleX": 1,
            "scaleY": 1,
        },
        "size": {
            "width": {"magnitude": 914400, "unit": "EMU"},
            "height": {"magnitude": 457200, "unit": "EMU"},
        },
    }


class TestMoveElement:
    """Tests for move_element tool execution."""

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_move_element_y_only(self, mock_get_service, mock_to_thread):
        """Test moving element Y position only and verify API call args."""
        from gslides.slides_tools import move_element

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        mock_presentation = create_mock_presentation(
            slides=[
                create_mock_slide(
                    elements=[
                        create_mock_text_element(
                            element_id="title_elem",
                            transform_x=914400,
                            transform_y=914400,
                        )
                    ]
                )
            ]
        )

        # Track the actual calls to batchUpdate
        captured_body = {}

        async def execute_and_capture(func, *args, **kwargs):
            call_args = str(func)
            if "batchUpdate" in call_args:
                # Capture what was passed to batchUpdate
                return {"replies": [{}]}
            return mock_presentation

        mock_to_thread.side_effect = execute_and_capture

        # Configure mock to capture call args
        mock_batch = MagicMock()
        mock_batch.execute.return_value = {"replies": [{}]}

        def capture_batch_update(presentationId, body):
            captured_body["presentationId"] = presentationId
            captured_body["body"] = body
            return mock_batch

        mock_service.presentations.return_value.batchUpdate = capture_batch_update
        mock_service.presentations.return_value.get.return_value.execute.return_value = mock_presentation

        result = await move_element.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            element_id="title_elem",
            y_inches=2.0,
        )

        assert "Element Moved Successfully" in result
        assert "title_elem" in result

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_move_element_not_found(self, mock_get_service, mock_to_thread):
        """Test error when element not found."""
        from gslides.slides_tools import move_element

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        mock_presentation = create_mock_presentation(slides=[create_mock_slide()])

        async def execute_sync(func, *args, **kwargs):
            return mock_presentation

        mock_to_thread.side_effect = execute_sync

        result = await move_element.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            element_id="nonexistent_elem",
            y_inches=1.0,
        )

        assert "Error" in result
        assert "not found" in result


class TestGetPresentationTheme:
    """Tests for get_presentation_theme tool execution."""

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_get_theme_returns_presentation_info(
        self, mock_get_service, mock_to_thread
    ):
        """Test getting presentation theme info."""
        from gslides.slides_tools import get_presentation_theme

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        mock_presentation = create_mock_presentation(
            theme={"themeName": "Corporate Blue"}
        )

        async def execute_sync(func, *args, **kwargs):
            return mock_presentation

        mock_to_thread.side_effect = execute_sync

        result = await get_presentation_theme.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
        )

        assert "Presentation Theme Information" in result
        assert "test_pres" in result


class TestInsertTextWithStyle:
    """Tests for insert_text_with_style tool execution."""

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_insert_with_explicit_style(self, mock_get_service, mock_to_thread):
        """Test inserting text with explicit style parameters."""
        from gslides.slides_tools import insert_text_with_style

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        mock_presentation = create_mock_presentation(
            slides=[
                create_mock_slide(
                    elements=[
                        create_mock_text_element(element_id="title_elem", text="")
                    ]
                )
            ]
        )

        async def execute_sync(func, *args, **kwargs):
            call_args = str(func)
            if "batchUpdate" in call_args:
                return {"replies": [{}]}
            return mock_presentation

        mock_to_thread.side_effect = execute_sync

        result = await insert_text_with_style.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            element_id="title_elem",
            text="Hello World",
            font_family="Arial",
            font_size_pt=24,
            bold=True,
        )

        assert "Text Inserted With Style Successfully" in result
        assert "Hello World" in result
        assert "Arial" in result

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_insert_copy_style_from_element(
        self, mock_get_service, mock_to_thread
    ):
        """Test copying style from another element."""
        from gslides.slides_tools import insert_text_with_style

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        source_element = create_mock_text_element(
            element_id="source_elem",
            text="Source",
            font_family="Noto Sans",
            font_size_pt=40,
        )
        dest_element = create_mock_text_element(element_id="dest_elem", text="")
        mock_presentation = create_mock_presentation(
            slides=[create_mock_slide(elements=[source_element, dest_element])]
        )

        async def execute_sync(func, *args, **kwargs):
            call_args = str(func)
            if "batchUpdate" in call_args:
                return {"replies": [{}]}
            return mock_presentation

        mock_to_thread.side_effect = execute_sync

        result = await insert_text_with_style.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            element_id="dest_elem",
            text="Copied Style Text",
            copy_style_from="source_elem",
        )

        assert "Text Inserted With Style Successfully" in result
        assert "Copied style from: source_elem" in result


class TestAddBulletList:
    """Tests for add_bullet_list tool execution."""

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.generate_object_id", return_value="test_list_id")
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_add_bullet_list_basic(
        self, mock_get_service, mock_to_thread, mock_gen_id
    ):
        """Test adding a bullet list and verify API request structure."""
        from gslides.slides_tools import add_bullet_list

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def capture_batch_call(func, *args, **kwargs):
            return {"replies": [{}]}

        mock_to_thread.side_effect = capture_batch_call

        result = await add_bullet_list.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            slide_id="slide_1",
            items=["First item", "Second item", "Third item"],
        )

        assert "Bullet List Created Successfully" in result
        assert "test_list_id" in result
        assert "Items: 3" in result

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.generate_object_id", return_value="numbered_list")
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_add_numbered_list(
        self, mock_get_service, mock_to_thread, mock_gen_id
    ):
        """Test adding a numbered list."""
        from gslides.slides_tools import add_bullet_list

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"replies": [{}]}

        mock_to_thread.side_effect = execute_sync

        result = await add_bullet_list.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            slide_id="slide_1",
            items=["Step 1", "Step 2"],
            list_type="NUMBERED",
        )

        assert "Bullet List Created Successfully" in result
        assert "List Type: NUMBERED" in result


class TestSetSlideBackground:
    """Tests for set_slide_background tool execution."""

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_set_background_color(self, mock_get_service, mock_to_thread):
        """Test setting a solid color background."""
        from gslides.slides_tools import set_slide_background

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"replies": [{}]}

        mock_to_thread.side_effect = execute_sync

        result = await set_slide_background.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            slide_id="slide_1",
            color="#FF0000",
        )

        assert "Slide Background Updated Successfully" in result
        assert "color #FF0000" in result

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_set_background_image(self, mock_get_service, mock_to_thread):
        """Test setting an image background."""
        from gslides.slides_tools import set_slide_background

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"replies": [{}]}

        mock_to_thread.side_effect = execute_sync

        result = await set_slide_background.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            slide_id="slide_1",
            image_url="https://example.com/background.jpg",
        )

        assert "Slide Background Updated Successfully" in result
        assert "image" in result

    @pytest.mark.asyncio
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_set_background_requires_params(self, mock_get_service):
        """Test error when neither color nor image_url provided."""
        from gslides.slides_tools import set_slide_background

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        result = await set_slide_background.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            slide_id="slide_1",
        )

        assert "Error" in result
        assert "color or image_url" in result


class TestReplaceAllText:
    """Tests for replace_all_text tool execution."""

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_replace_text_basic(self, mock_get_service, mock_to_thread):
        """Test basic find and replace."""
        from gslides.slides_tools import replace_all_text

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"replies": [{"replaceAllText": {"occurrencesChanged": 5}}]}

        mock_to_thread.side_effect = execute_sync

        result = await replace_all_text.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            find_text="Old Company",
            replace_text="New Company",
        )

        assert "Text Replaced Successfully" in result
        assert 'Find: "Old Company"' in result
        assert 'Replace: "New Company"' in result
        assert "Occurrences Replaced: 5" in result


class TestAddLink:
    """Tests for add_link tool execution."""

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_add_url_link(self, mock_get_service, mock_to_thread):
        """Test adding a URL hyperlink."""
        from gslides.slides_tools import add_link

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"replies": [{}]}

        mock_to_thread.side_effect = execute_sync

        result = await add_link.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            element_id="text_box_1",
            url="https://www.google.com",
        )

        assert "Link Added Successfully" in result
        assert "https://www.google.com" in result

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_add_slide_link(self, mock_get_service, mock_to_thread):
        """Test adding an internal slide link."""
        from gslides.slides_tools import add_link

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"replies": [{}]}

        mock_to_thread.side_effect = execute_sync

        result = await add_link.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            element_id="text_box_1",
            slide_id="slide_2",
        )

        assert "Link Added Successfully" in result
        assert "slide slide_2" in result

    @pytest.mark.asyncio
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_add_link_requires_target(self, mock_get_service):
        """Test error when neither url nor slide_id provided."""
        from gslides.slides_tools import add_link

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        result = await add_link.fn(
            user_google_email="test@example.com",
            presentation_id="test_pres",
            element_id="text_box_1",
        )

        assert "Error" in result
        assert "url or slide_id" in result


class TestCopyPresentation:
    """Tests for copy_presentation tool execution."""

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_copy_presentation_basic(self, mock_get_service, mock_to_thread):
        """Test copying a presentation."""
        from gslides.slides_tools import copy_presentation

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "new_pres_id", "name": "Copy of Original"}

        mock_to_thread.side_effect = execute_sync

        result = await copy_presentation.fn(
            user_google_email="test@example.com",
            presentation_id="source_pres",
            new_title="My Copy",
        )

        assert "Presentation Copied Successfully" in result
        assert "new_pres_id" in result

    @pytest.mark.asyncio
    @patch("gslides.slides_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_copy_presentation_with_folder(
        self, mock_get_service, mock_to_thread
    ):
        """Test copying a presentation to a specific folder."""
        from gslides.slides_tools import copy_presentation

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "new_pres_id", "name": "Folder Copy"}

        mock_to_thread.side_effect = execute_sync

        result = await copy_presentation.fn(
            user_google_email="test@example.com",
            presentation_id="source_pres",
            new_title="Folder Copy",
            destination_folder_id="folder_123",
        )

        assert "Presentation Copied Successfully" in result


class TestHelperFunctions:
    """Tests for helper functions used by tools."""

    def test_transform_calculation_y_only(self):
        """Test that Y transform is calculated correctly."""
        from gslides.slides_helpers import inches_to_emu

        expected_y_emu = inches_to_emu(2.0)
        assert expected_y_emu == 1828800

    def test_transform_calculation_x_only(self):
        """Test that X transform is calculated correctly."""
        from gslides.slides_helpers import inches_to_emu

        expected_x_emu = inches_to_emu(0.5)
        assert expected_x_emu == 457200

    def test_extract_style_from_text_run(self):
        """Test extracting style from a text run."""
        element = create_mock_text_element(
            font_family="Noto Sans",
            font_size_pt=40,
            bold=True,
        )
        text_elements = element["shape"]["text"]["textElements"]

        text_run = None
        for te in text_elements:
            if "textRun" in te:
                text_run = te["textRun"]
                break

        assert text_run is not None
        style = text_run["style"]
        assert style["weightedFontFamily"]["fontFamily"] == "Noto Sans"
        assert style["fontSize"]["magnitude"] == 40
        assert style["bold"] is True
