"""
Tests for document savepoints and safety features.

Tests cover:
- _create_savepoint_internal shared helper
- _create_auto_savepoint internal helper
- create_doc_savepoint tool (via .fn accessor)
- list_doc_savepoints tool (via .fn accessor)
- find_and_replace_doc tool with max_replacements/create_savepoint (via .fn accessor)

Note: Decorated tools are accessed via .fn to bypass the @server.tool() wrapper.
"""

import pytest
import json
from unittest.mock import MagicMock, patch

import gdocs.docs_tools as docs_tools_module


class TestCreateSavepointInternal:
    """Tests for _create_savepoint_internal shared helper function.

    This function is used by both create_doc_savepoint and _create_auto_savepoint,
    so testing it effectively tests the core logic of both tools.
    """

    @pytest.mark.asyncio
    async def test_creates_savepoint_with_keepforever(self):
        """Test that savepoint marks revision with keepForever=True."""
        import gdocs.docs_tools as docs_tools

        mock_drive_service = MagicMock()

        # Setup mock responses
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [{"id": "rev123", "modifiedTime": "2024-01-01T12:00:00Z"}]
        }
        mock_drive_service.revisions.return_value.update.return_value.execute.return_value = {}
        mock_drive_service.files.return_value.get.return_value.execute.return_value = {
            "appProperties": {}
        }
        mock_drive_service.files.return_value.update.return_value.execute.return_value = {}

        async def mock_to_thread(func):
            return func()

        with patch.object(docs_tools.asyncio, "to_thread", mock_to_thread):
            result = await docs_tools._create_savepoint_internal(
                drive_service=mock_drive_service,
                document_id="doc123",
                name="Test Savepoint",
            )

        # Verify result structure
        assert result is not None
        assert result["revision_id"] == "rev123"
        assert result["name"] == "Test Savepoint"
        assert result["created_at"] == "2024-01-01T12:00:00Z"

        # Verify keepForever was set via revisions.update
        mock_drive_service.revisions.return_value.update.assert_called_with(
            fileId="doc123", revisionId="rev123", body={"keepForever": True}
        )

    @pytest.mark.asyncio
    async def test_stores_name_in_app_properties(self):
        """Test that savepoint name is stored in file appProperties."""
        import gdocs.docs_tools as docs_tools

        mock_drive_service = MagicMock()
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [{"id": "rev456", "modifiedTime": "2024-01-01"}]
        }
        mock_drive_service.revisions.return_value.update.return_value.execute.return_value = {}
        mock_drive_service.files.return_value.get.return_value.execute.return_value = {
            "appProperties": {"existing_key": "existing_value"}
        }
        mock_drive_service.files.return_value.update.return_value.execute.return_value = {}

        async def mock_to_thread(func):
            return func()

        with patch.object(docs_tools.asyncio, "to_thread", mock_to_thread):
            await docs_tools._create_savepoint_internal(
                drive_service=mock_drive_service,
                document_id="doc123",
                name="My Named Savepoint",
            )

        # Verify files.update was called with correct properties
        update_call = mock_drive_service.files.return_value.update.call_args
        body = update_call[1]["body"]
        assert "savepoint_rev456" in body["appProperties"]
        assert body["appProperties"]["savepoint_rev456"] == "My Named Savepoint"
        # Existing properties should be preserved
        assert body["appProperties"]["existing_key"] == "existing_value"

    @pytest.mark.asyncio
    async def test_resilient_to_property_storage_errors(self):
        """Verify savepoint creation succeeds even if property storage fails."""
        import gdocs.docs_tools as docs_tools
        from googleapiclient.errors import HttpError

        mock_drive_service = MagicMock()
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [{"id": "rev1", "modifiedTime": "2024-01-01"}]
        }
        # Revision update (keepForever) succeeds
        mock_drive_service.revisions.return_value.update.return_value.execute.return_value = {}
        # Property storage fails
        mock_drive_service.files.return_value.get.return_value.execute.side_effect = (
            HttpError(resp=MagicMock(status=403), content=b"Permission denied")
        )

        async def mock_to_thread(func):
            return func()

        with patch.object(docs_tools.asyncio, "to_thread", mock_to_thread):
            result = await docs_tools._create_savepoint_internal(
                drive_service=mock_drive_service,
                document_id="doc123",
                name="Test Savepoint",
            )

        # Should still return result - savepoint was created even if name storage failed
        assert result is not None
        assert result["revision_id"] == "rev1"
        assert result["name"] == "Test Savepoint"

    @pytest.mark.asyncio
    async def test_returns_none_on_no_revisions(self):
        """Test that savepoint returns None when document has no revisions."""
        import gdocs.docs_tools as docs_tools

        mock_drive_service = MagicMock()
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": []
        }

        async def mock_to_thread(func):
            return func()

        with patch.object(docs_tools.asyncio, "to_thread", mock_to_thread):
            result = await docs_tools._create_savepoint_internal(
                drive_service=mock_drive_service,
                document_id="doc123",
                name="Test",
            )

        assert result is None

    @pytest.mark.asyncio
    async def test_uses_latest_revision(self):
        """Test that savepoint uses the latest (last) revision."""
        import gdocs.docs_tools as docs_tools

        mock_drive_service = MagicMock()
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [
                {"id": "rev_old", "modifiedTime": "2024-01-01"},
                {"id": "rev_middle", "modifiedTime": "2024-01-15"},
                {"id": "rev_latest", "modifiedTime": "2024-01-30"},
            ]
        }
        mock_drive_service.revisions.return_value.update.return_value.execute.return_value = {}
        mock_drive_service.files.return_value.get.return_value.execute.return_value = {
            "appProperties": {}
        }
        mock_drive_service.files.return_value.update.return_value.execute.return_value = {}

        async def mock_to_thread(func):
            return func()

        with patch.object(docs_tools.asyncio, "to_thread", mock_to_thread):
            result = await docs_tools._create_savepoint_internal(
                drive_service=mock_drive_service,
                document_id="doc123",
                name="Test",
            )

        # Should use the latest revision
        assert result["revision_id"] == "rev_latest"
        mock_drive_service.revisions.return_value.update.assert_called_with(
            fileId="doc123", revisionId="rev_latest", body={"keepForever": True}
        )


class TestAutoSavepointHelper:
    """Tests for _create_auto_savepoint wrapper function."""

    @pytest.mark.asyncio
    async def test_auto_savepoint_uses_internal_helper(self):
        """Test that auto-savepoint delegates to _create_savepoint_internal."""
        import gdocs.docs_tools as docs_tools

        mock_drive_service = MagicMock()
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [{"id": "rev123", "modifiedTime": "2024-01-01T12:00:00Z"}]
        }
        mock_drive_service.revisions.return_value.update.return_value.execute.return_value = {}
        mock_drive_service.files.return_value.get.return_value.execute.return_value = {
            "appProperties": {}
        }
        mock_drive_service.files.return_value.update.return_value.execute.return_value = {}

        async def mock_to_thread(func):
            return func()

        with patch.object(docs_tools.asyncio, "to_thread", mock_to_thread):
            result = await docs_tools._create_auto_savepoint(
                drive_service=mock_drive_service,
                document_id="doc123",
                operation_name="find_replace",
            )

        # Verify result
        assert result is not None
        assert result["revision_id"] == "rev123"
        assert "find_replace" in result["name"]
        assert "Auto-save" in result["name"]

    @pytest.mark.asyncio
    async def test_auto_savepoint_handles_api_errors_gracefully(self):
        """Test that auto-savepoint returns None on API errors (doesn't raise)."""
        import gdocs.docs_tools as docs_tools

        mock_drive_service = MagicMock()
        mock_drive_service.revisions.return_value.list.return_value.execute.side_effect = Exception(
            "API Error"
        )

        async def mock_to_thread(func):
            return func()

        with patch.object(docs_tools.asyncio, "to_thread", mock_to_thread):
            # Should not raise, should return None
            result = await docs_tools._create_auto_savepoint(
                drive_service=mock_drive_service,
                document_id="doc123",
                operation_name="test_op",
            )

        assert result is None

    @pytest.mark.asyncio
    async def test_auto_savepoint_name_format(self):
        """Test that auto-savepoint name includes operation and timestamp."""
        import gdocs.docs_tools as docs_tools

        mock_drive_service = MagicMock()
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [{"id": "rev1", "modifiedTime": "2024-01-01"}]
        }
        mock_drive_service.revisions.return_value.update.return_value.execute.return_value = {}
        mock_drive_service.files.return_value.get.return_value.execute.return_value = {
            "appProperties": {}
        }
        mock_drive_service.files.return_value.update.return_value.execute.return_value = {}

        async def mock_to_thread(func):
            return func()

        with patch.object(docs_tools.asyncio, "to_thread", mock_to_thread):
            result = await docs_tools._create_auto_savepoint(
                drive_service=mock_drive_service,
                document_id="doc123",
                operation_name="batch_delete",
            )

        assert result is not None
        # Name should follow format: "Auto-save before {operation} (HH:MM:SS)"
        assert "Auto-save before batch_delete" in result["name"]
        # Should contain time in parentheses
        assert "(" in result["name"] and ")" in result["name"]


# =============================================================================
# TOOL FUNCTION TESTS
# =============================================================================
# The decorated tool functions are tested by patching the authentication layer
# to inject mock services. This allows testing the full tool logic including
# parameter handling and response formatting.


class TestCreateDocSavepointTool:
    """Direct tests for create_doc_savepoint tool."""

    @pytest.mark.asyncio
    async def test_create_savepoint_tool_success(self):
        """Test create_doc_savepoint tool creates savepoint correctly."""
        mock_drive_service = MagicMock()

        # Setup mocks
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [{"id": "rev_latest", "modifiedTime": "2024-01-01T12:00:00Z"}]
        }
        mock_drive_service.revisions.return_value.update.return_value.execute.return_value = {}
        mock_drive_service.files.return_value.get.return_value.execute.return_value = {
            "appProperties": {}
        }
        mock_drive_service.files.return_value.update.return_value.execute.return_value = {}

        async def mock_to_thread(func):
            return func()

        # Patch the authentication to return our mock service
        async def mock_authenticate(*args, **kwargs):
            return mock_drive_service, "test@example.com"

        with patch.object(docs_tools_module.asyncio, "to_thread", mock_to_thread):
            with patch(
                "auth.service_decorator._authenticate_service", mock_authenticate
            ):
                with patch(
                    "auth.service_decorator._get_auth_context",
                    return_value=("test@example.com", "mcp_auth", "session123"),
                ):
                    result_json = await docs_tools_module.create_doc_savepoint.fn(
                        user_google_email="test@example.com",
                        document_id="doc123",
                        name="My Test Savepoint",
                    )

        result = json.loads(result_json)

        # Verify response structure
        assert result["success"] is True
        assert result["savepoint"]["name"] == "My Test Savepoint"
        assert result["savepoint"]["revision_id"] == "rev_latest"
        assert "restore_instructions" in result

        # Verify API calls
        mock_drive_service.revisions.return_value.update.assert_called_with(
            fileId="doc123", revisionId="rev_latest", body={"keepForever": True}
        )


class TestListDocSavepointsTool:
    """Direct tests for list_doc_savepoints tool."""

    @pytest.mark.asyncio
    async def test_list_savepoints_tool_filters_correctly(self):
        """Test list_doc_savepoints tool filters to keepForever revisions only."""
        mock_drive_service = MagicMock()

        # Mix of keepForever=True and False
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [
                {"id": "rev1", "keepForever": True, "modifiedTime": "2024-01-01"},
                {"id": "rev2", "keepForever": False, "modifiedTime": "2024-01-02"},
                {"id": "rev3", "keepForever": True, "modifiedTime": "2024-01-03"},
            ]
        }

        mock_drive_service.files.return_value.get.return_value.execute.return_value = {
            "appProperties": {
                "savepoint_rev1": "First Savepoint",
                "savepoint_rev3": "Third Savepoint",
            }
        }

        async def mock_to_thread(func):
            return func()

        async def mock_authenticate(*args, **kwargs):
            return mock_drive_service, "test@example.com"

        with patch.object(docs_tools_module.asyncio, "to_thread", mock_to_thread):
            with patch(
                "auth.service_decorator._authenticate_service", mock_authenticate
            ):
                with patch(
                    "auth.service_decorator._get_auth_context",
                    return_value=("test@example.com", "mcp_auth", "session123"),
                ):
                    result_json = await docs_tools_module.list_doc_savepoints.fn(
                        user_google_email="test@example.com",
                        document_id="doc123",
                    )

        result = json.loads(result_json)

        # Should have 2 savepoints (only keepForever=True)
        assert result["total_savepoints"] == 2
        assert len(result["savepoints"]) == 2

        # Verify correct ones are included
        revision_ids = [sp["revision_id"] for sp in result["savepoints"]]
        assert "rev1" in revision_ids
        assert "rev3" in revision_ids
        assert "rev2" not in revision_ids


class TestFindAndReplaceDocTool:
    """Direct tests for find_and_replace_doc tool with safety features."""

    @pytest.mark.asyncio
    async def test_find_replace_tool_creates_savepoint_by_default(self):
        """Test that find_and_replace_doc creates savepoint by default (create_savepoint=True)."""
        mock_docs_service = MagicMock()
        mock_drive_service = MagicMock()

        # Mock document content
        mock_docs_service.documents.return_value.get.return_value.execute.return_value = {
            "body": {"content": []}
        }
        mock_docs_service.documents.return_value.batchUpdate.return_value.execute.return_value = {
            "replies": [{"replaceAllText": {"occurrencesChanged": 1}}]
        }

        # Mock drive service for savepoint
        mock_drive_service.revisions.return_value.list.return_value.execute.return_value = {
            "revisions": [{"id": "savepoint_rev", "modifiedTime": "2024-01-01"}]
        }
        mock_drive_service.revisions.return_value.update.return_value.execute.return_value = {}
        mock_drive_service.files.return_value.get.return_value.execute.return_value = {
            "appProperties": {}
        }
        mock_drive_service.files.return_value.update.return_value.execute.return_value = {}

        async def mock_to_thread(func):
            return func()

        async def mock_authenticate(use_oauth21, service_name, *args, **kwargs):
            if service_name == "docs":
                return mock_docs_service, "test@example.com"
            else:
                return mock_drive_service, "test@example.com"

        # Mock the dynamic drive service acquisition
        async def mock_get_auth_service(*args, **kwargs):
            return mock_drive_service

        with patch.object(docs_tools_module.asyncio, "to_thread", mock_to_thread):
            with patch(
                "auth.service_decorator._authenticate_service", mock_authenticate
            ):
                with patch(
                    "auth.service_decorator._get_auth_context",
                    return_value=("test@example.com", "mcp_auth", "session123"),
                ):
                    with patch(
                        "auth.google_auth.get_authenticated_google_service",
                        mock_get_auth_service,
                    ):
                        with patch(
                            "gdocs.docs_tools.find_all_occurrences_in_document",
                            return_value=[(0, 3)],
                        ):
                            result_json = (
                                await docs_tools_module.find_and_replace_doc.fn(
                                    user_google_email="test@example.com",
                                    document_id="doc123",
                                    find_text="foo",
                                    replace_text="bar",
                                    # create_savepoint=True is the default
                                )
                            )

        result = json.loads(result_json)

        # Should have savepoint info in response
        assert "savepoint" in result
        assert result["savepoint"]["revision_id"] == "savepoint_rev"
        assert "restore_instructions" in result["savepoint"]

        # Verify savepoint was created (keepForever was set)
        mock_drive_service.revisions.return_value.update.assert_called_with(
            fileId="doc123", revisionId="savepoint_rev", body={"keepForever": True}
        )

    @pytest.mark.asyncio
    async def test_find_replace_tool_with_max_replacements(self):
        """Test find_and_replace_doc tool respects max_replacements parameter."""
        mock_docs_service = MagicMock()
        mock_drive_service = MagicMock()

        # Mock document content
        mock_docs_service.documents.return_value.get.return_value.execute.return_value = {
            "body": {"content": []}
        }
        mock_docs_service.documents.return_value.batchUpdate.return_value.execute.return_value = {
            "replies": []
        }

        async def mock_to_thread(func):
            return func()

        # Mock authenticate to return different services based on service_name
        async def mock_authenticate(use_oauth21, service_name, *args, **kwargs):
            if service_name == "docs":
                return mock_docs_service, "test@example.com"
            else:
                return mock_drive_service, "test@example.com"

        with patch.object(docs_tools_module.asyncio, "to_thread", mock_to_thread):
            with patch(
                "auth.service_decorator._authenticate_service", mock_authenticate
            ):
                with patch(
                    "auth.service_decorator._get_auth_context",
                    return_value=("test@example.com", "mcp_auth", "session123"),
                ):
                    with patch(
                        "gdocs.docs_tools.find_all_occurrences_in_document",
                        return_value=[(0, 3), (10, 13), (20, 23), (30, 33), (40, 43)],
                    ):
                        result_json = await docs_tools_module.find_and_replace_doc.fn(
                            user_google_email="test@example.com",
                            document_id="doc123",
                            find_text="foo",
                            replace_text="bar",
                            max_replacements=2,
                            create_savepoint=False,
                        )

        result = json.loads(result_json)

        # Should only replace 2 occurrences
        assert result["occurrences_replaced"] == 2
        assert result["max_replacements"] == 2
        assert result["additional_occurrences_skipped"] == 3


# =============================================================================
# INTERNAL HELPER TESTS
# =============================================================================
# Tests for the shared internal functions that contain the core business logic.
