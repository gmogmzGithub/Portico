"""Tests for tab_id support in reading/extraction tools. @ai-generated"""
import os
from gdocs.docs_structure import (
    find_elements_by_type, find_tables, get_all_headings,
    get_body_for_tab, get_inline_objects_for_tab,
)

# -- Shared fixtures --

def _doc_with_table_in_tab1():
    """Two-tab doc: tab1 has a 2x2 table, tab2 has only text."""
    return {
        "body": {"content": [{"sectionBreak": {}}]},
        "tabs": [
            {"tabProperties": {"tabId": "tab1"}, "documentTab": {"body": {"content": [
                {"sectionBreak": {}},
                {"startIndex": 5, "endIndex": 50, "table": {"tableRows": [
                    {"tableCells": [
                        {"content": [{"paragraph": {"elements": []}}]},
                        {"content": [{"paragraph": {"elements": []}}]},
                    ]},
                    {"tableCells": [
                        {"content": [{"paragraph": {"elements": []}}]},
                        {"content": [{"paragraph": {"elements": []}}]},
                    ]},
                ]}},
            ]}}},
            {"tabProperties": {"tabId": "tab2"}, "documentTab": {"body": {"content": [
                {"sectionBreak": {}},
                {"startIndex": 1, "endIndex": 5, "paragraph": {"text": "Tab2"}},
            ]}}},
        ],
    }

def _doc_with_images_per_tab():
    """Two-tab doc: tab1 has img1, tab2 has img2."""
    def _tab(tab_id, img_id):
        return {"tabProperties": {"tabId": tab_id}, "documentTab": {
            "body": {"content": [{"sectionBreak": {}}]},
            "inlineObjects": {img_id: {"inlineObjectProperties": {
                "embeddedObject": {"imageProperties": {"contentUri": f"https://{tab_id}/{img_id}"}}
            }}},
        }}
    return {
        "body": {"content": [{"sectionBreak": {}}]},
        "inlineObjects": {},
        "tabs": [_tab("tab1", "kix.img1"), _tab("tab2", "kix.img2")],
    }

def _doc_with_headings_per_tab():
    """Two-tab doc: each tab has a distinct HEADING_1."""
    def _tab(tab_id, heading_text):
        return {"tabProperties": {"tabId": tab_id}, "documentTab": {"body": {"content": [
            {"sectionBreak": {}},
            {"paragraph": {
                "paragraphStyle": {"namedStyleType": "HEADING_1"},
                "elements": [{"textRun": {"content": heading_text}}],
            }},
        ]}}}
    return {
        "body": {"content": [{"sectionBreak": {}}]},
        "tabs": [_tab("tab1", "Tab1 Heading"), _tab("tab2", "Tab2 Heading")],
    }


class TestFindDocElements:
    def test_finds_table_in_specified_tab(self):
        elements = find_elements_by_type(_doc_with_table_in_tab1(), "table", tab_id="tab1")
        assert len(elements) > 0 and elements[0]["type"] == "table"

    def test_finds_no_table_in_tab_without_one(self):
        assert find_elements_by_type(_doc_with_table_in_tab1(), "table", tab_id="tab2") == []

    def test_backwards_compatible_without_tab_id(self):
        doc = {"body": {"content": [
            {"sectionBreak": {}},
            {"startIndex": 1, "endIndex": 10, "paragraph": {"elements": [{"textRun": {"content": "x"}}]}},
        ]}}
        elements = find_elements_by_type(doc, "paragraph")
        assert len(elements) > 0 and elements[0]["type"] == "paragraph"


class TestDebugTableStructure:
    def test_finds_tables_from_specified_tab(self):
        tables = find_tables(_doc_with_table_in_tab1(), tab_id="tab1")
        assert len(tables) > 0 and tables[0]["rows"] == 2 and tables[0]["columns"] == 2

    def test_no_tables_in_tab_without_them(self):
        assert find_tables(_doc_with_table_in_tab1(), tab_id="tab2") == []

    def test_backwards_compatible_without_tab_id(self):
        doc = {"body": {"content": [
            {"sectionBreak": {}},
            {"startIndex": 5, "endIndex": 50, "table": {"tableRows": [
                {"tableCells": [{"content": [{"paragraph": {"elements": []}}]}]},
            ]}},
        ]}}
        assert len(find_tables(doc)) > 0


class TestExtractImages:
    def test_inline_objects_scoped_to_tab(self):
        doc = _doc_with_images_per_tab()
        tab1 = get_inline_objects_for_tab(doc, "tab1")
        assert "kix.img1" in tab1 and "kix.img2" not in tab1

        tab2 = get_inline_objects_for_tab(doc, "tab2")
        assert "kix.img2" in tab2 and "kix.img1" not in tab2

    def test_body_scoped_to_tab(self):
        doc = _doc_with_headings_per_tab()
        body1 = get_body_for_tab(doc, "tab1")
        body2 = get_body_for_tab(doc, "tab2")
        assert "Tab1" in str(body1) and "Tab2" not in str(body1)
        assert "Tab2" in str(body2) and "Tab1" not in str(body2)

    def test_backwards_compatible_without_tab_id(self):
        doc = {
            "body": {"content": [{"sectionBreak": {}}, {"paragraph": {"text": "Root"}}]},
            "inlineObjects": {"kix.root": {}},
        }
        assert "kix.root" in get_inline_objects_for_tab(doc, None)

    def test_source_file_has_include_tabs_content(self):
        src = os.path.join(os.path.dirname(__file__), "../../gdocs/docs_tools.py")
        with open(src) as f:
            content = f.read()
        fn_start = content.find("async def extract_images(")
        assert "includeTabsContent=True" in content[fn_start:fn_start + 3000]

    def test_headings_scoped_to_tab(self):
        doc = _doc_with_headings_per_tab()
        h1 = get_all_headings(doc, "tab1")
        h2 = get_all_headings(doc, "tab2")
        assert any("Tab1" in h.get("text", "") for h in h1)
        assert any("Tab2" in h.get("text", "") for h in h2)
