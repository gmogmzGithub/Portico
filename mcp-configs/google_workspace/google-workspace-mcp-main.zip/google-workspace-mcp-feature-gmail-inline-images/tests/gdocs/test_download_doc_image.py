"""Unit tests for download_doc_image tool."""

import pytest
import sys
import os
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
import gdocs.docs_tools as docs_tools_module

VALID_PNG_BYTES = b"\x89PNG\r\n\x1a\n" + b"\x00" * 16
DOC_ID = "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms"
CDN = "https://lh3.googleusercontent.com/img"
_fn = docs_tools_module.download_doc_image.fn.__wrapped__.__wrapped__


def _inline_obj(content_uri):
    return {"inlineObjectProperties": {"embeddedObject": {"imageProperties": {"contentUri": content_uri}}}}


def _tabbed_doc(object_id, content_uri, tab_id="tab1"):
    return {"tabs": [{"tabProperties": {"tabId": tab_id}, "documentTab": {"inlineObjects": {object_id: _inline_obj(content_uri)}}}]}


def _legacy_doc(object_id, content_uri):
    return {"inlineObjects": {object_id: _inline_obj(content_uri)}}


def _two_tab_doc(obj_id, content_uri, img_in_tab="tab1"):
    tabs = []
    for tid in ["tab1", "tab2"]:
        objs = {obj_id: _inline_obj(content_uri)} if tid == img_in_tab else {}
        tabs.append({"tabProperties": {"tabId": tid}, "documentTab": {"inlineObjects": objs}})
    return {"tabs": tabs}


def _mock_httpx(content_type="image/png"):
    mock_resp = MagicMock(content=VALID_PNG_BYTES, headers={"content-type": content_type})
    mock_resp.raise_for_status = MagicMock()
    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=mock_resp)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    ctor = MagicMock(return_value=mock_client)
    return ctor, mock_client


def _patch_cache_miss():
    """Patch Path so cache dir appears empty (no cached file)."""
    return patch("gdocs.docs_tools.Path", wraps=Path)


async def _call(doc, object_id="kix.abc", tab_id=None, content_type="image/png"):
    """Call download_doc_image with mocked service, httpx, and file I/O."""
    svc = MagicMock()
    svc.documents().get().execute.return_value = doc
    ctor, client = _mock_httpx(content_type)
    mock_path = MagicMock()
    mock_cache_dir = MagicMock()
    mock_cache_dir.exists.return_value = False  # cache miss
    mock_cache_dir.__truediv__ = MagicMock(return_value=mock_path)
    mock_path.write_bytes = MagicMock()

    def path_factory(*args):
        p = Path(*args)
        if str(p) == "/tmp/google_workspace_mcp":
            result = MagicMock()
            result.__truediv__ = MagicMock(return_value=mock_cache_dir)
            return result
        return p

    with patch("gdocs.docs_tools.Path", side_effect=path_factory), \
         patch("httpx.AsyncClient", ctor):
        result = await _fn(service=svc, user_google_email="t@t.com", document_id=DOC_ID, object_id=object_id, tab_id=tab_id)
    return result, svc, client, mock_path


class TestDownloadDocImage:

    @pytest.mark.asyncio
    async def test_happy_path_tabbed_doc(self):
        result, _, _, mock_path = await _call(_tabbed_doc("kix.abc", CDN))
        assert result["format"] == "png"
        assert result["size_bytes"] == len(VALID_PNG_BYTES)
        assert result["cached"] is False
        assert "file_path" in result
        mock_path.write_bytes.assert_called_once_with(VALID_PNG_BYTES)

    @pytest.mark.asyncio
    async def test_happy_path_legacy_doc(self):
        result, _, _, mock_path = await _call(_legacy_doc("kix.abc", CDN))
        assert result["cached"] is False
        mock_path.write_bytes.assert_called_once_with(VALID_PNG_BYTES)

    @pytest.mark.asyncio
    async def test_tab_id_scopes_to_specified_tab(self):
        result, _, _, _ = await _call(_two_tab_doc("kix.img", CDN, img_in_tab="tab2"), object_id="kix.img", tab_id="tab2")
        assert result["cached"] is False

    @pytest.mark.asyncio
    async def test_default_tab_when_tab_id_omitted(self):
        result, _, _, _ = await _call(_two_tab_doc("kix.img", CDN, img_in_tab="tab1"), object_id="kix.img")
        assert result["cached"] is False

    @pytest.mark.asyncio
    async def test_error_when_object_not_found(self):
        doc = {"tabs": [{"tabProperties": {"tabId": "t"}, "documentTab": {"inlineObjects": {}}}]}
        result, _, _, _ = await _call(doc, object_id="kix.missing")
        assert isinstance(result, dict)
        assert "not found" in str(result).lower()

    @pytest.mark.asyncio
    async def test_ssrf_rejects_non_google_hostname(self):
        result, _, client, _ = await _call(_tabbed_doc("kix.x", "https://evil.com/img.png"), object_id="kix.x")
        assert isinstance(result, dict)
        client.get.assert_not_called()

    @pytest.mark.asyncio
    @pytest.mark.parametrize("hostname", [
        "lh3.googleusercontent.com", "lh4.googleusercontent.com",
        "lh5.googleusercontent.com", "lh6.googleusercontent.com",
        "docs.googleusercontent.com",
    ])
    async def test_ssrf_accepts_google_hostnames(self, hostname):
        result, _, _, _ = await _call(_tabbed_doc("kix.x", f"https://{hostname}/img"), object_id="kix.x")
        assert result["cached"] is False

    @pytest.mark.asyncio
    @pytest.mark.parametrize("content_type,expected", [
        ("image/png", "png"),
        ("image/jpeg", "jpeg"),
        ("image/webp", "webp"),
        ("image/gif", "gif"),
        ("image/svg+xml", "svg+xml"),
        ("image/png; charset=utf-8", "png"),
        ("application/octet-stream", "png"),
    ])
    async def test_mime_type_detection(self, content_type, expected):
        result, _, _, _ = await _call(_tabbed_doc("kix.x", CDN), object_id="kix.x", content_type=content_type)
        assert result["format"] == expected

    @pytest.mark.asyncio
    async def test_cache_hit_skips_download(self):
        """When file already exists in /tmp, return cached result without downloading."""
        svc = MagicMock()
        svc.documents().get().execute.return_value = _tabbed_doc("kix.abc", CDN)
        cached_file = MagicMock(spec=Path)
        cached_file.suffix = ".png"
        cached_file.stat.return_value = MagicMock(st_size=42)
        cached_file.__str__ = MagicMock(return_value="/tmp/google_workspace_mcp/doc123/kix.abc.png")
        mock_cache_dir = MagicMock()
        mock_cache_dir.exists.return_value = True
        mock_cache_dir.glob.return_value = [cached_file]

        def path_factory(*args):
            p = Path(*args)
            if str(p) == "/tmp/google_workspace_mcp":
                result = MagicMock()
                result.__truediv__ = MagicMock(return_value=mock_cache_dir)
                return result
            return p

        with patch("gdocs.docs_tools.Path", side_effect=path_factory), \
             patch("httpx.AsyncClient") as mock_httpx_cls:
            result = await _fn(service=svc, user_google_email="t@t.com", document_id=DOC_ID, object_id="kix.abc")
        assert result["cached"] is True
        assert result["size_bytes"] == 42
        mock_httpx_cls.assert_not_called()

    @pytest.mark.asyncio
    async def test_error_for_blank_object_id(self):
        svc = MagicMock()
        result = await _fn(service=svc, user_google_email="t@t.com", document_id=DOC_ID, object_id="")
        assert isinstance(result, dict)
        svc.documents().get.assert_not_called()

    @pytest.mark.asyncio
    async def test_error_for_invalid_document_id(self):
        svc = MagicMock()
        result = await _fn(service=svc, user_google_email="t@t.com", document_id="bad", object_id="kix.x")
        assert isinstance(result, str)
