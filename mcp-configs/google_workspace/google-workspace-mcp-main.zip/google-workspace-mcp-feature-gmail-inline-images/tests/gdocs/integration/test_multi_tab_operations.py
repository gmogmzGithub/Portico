"""
Integration tests for multi-tab document operations.

These tests verify that tab_id is correctly propagated to all Google Docs API
operations. While we can't programmatically create multi-tab documents (API
limitation), we can still verify that:
1. tab_id is correctly extracted from existing documents
2. tab_id is properly propagated to all API operations
3. Operations targeting a specific tab work correctly

Requires: GOOGLE_TEST_EMAIL environment variable set.
"""

import pytest
import json
import asyncio
import gdocs.docs_tools as docs_tools_module
import gdrive.drive_tools as drive_tools_module


@pytest.fixture
async def document_with_tab_id(user_google_email, docs_service, drive_service):
    """
    Create a test document and extract its tab_id.

    All Google Docs have at least one tab. This fixture creates a document
    and extracts the tab_id of the default tab, which can be used to test
    tab_id propagation in all operations.
    """
    # docs_service and drive_service are tuples (service, email)
    docs_svc = docs_service[0] if isinstance(docs_service, tuple) else docs_service

    # Create the document
    doc = await asyncio.to_thread(
        docs_svc.documents()
        .create(body={"title": "[TEST] Tab ID Propagation Test"})
        .execute
    )
    doc_id = doc["documentId"]

    # Get the document with tabs content to extract tab_id
    doc = await asyncio.to_thread(
        docs_svc.documents().get(documentId=doc_id, includeTabsContent=True).execute
    )

    tabs = doc.get("tabs", [])
    tab_id = tabs[0].get("tabProperties", {}).get("tabId") if tabs else None

    print(f"\n✓ Created test document (ID: {doc_id}, tab_id: {tab_id})")

    yield {
        "document_id": doc_id,
        "tab_id": tab_id,
    }

    # Cleanup: trash the document using tool function
    try:
        await drive_tools_module.update_drive_file.fn(
            user_google_email=user_google_email, file_id=doc_id, trashed=True
        )
        print(f"✓ Trashed test document: {doc_id}")
    except Exception as e:
        print(f"⚠ Warning: Failed to trash test document {doc_id}: {e}")


@pytest.mark.asyncio
@pytest.mark.integration
async def test_modify_doc_text_with_tab_id(user_google_email, document_with_tab_id):
    """Test modify_doc_text correctly propagates tab_id to API requests."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # Insert text with explicit tab_id
    result = await docs_tools_module.modify_doc_text.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        location="start",
        text="Content inserted with tab_id",
        tab_id=tab_id,
    )
    result_data = json.loads(result)
    assert result_data.get("success"), f"Insert failed: {result}"

    # Verify content is in the document
    content = await docs_tools_module.get_doc_content.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        tab_id=tab_id,
    )
    assert "Content inserted with tab_id" in content


@pytest.mark.asyncio
@pytest.mark.integration
async def test_insert_markdown_with_tab_id(user_google_email, document_with_tab_id):
    """Test insert_markdown correctly propagates tab_id to API requests."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # Insert markdown with explicit tab_id
    result = await docs_tools_module.insert_markdown.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        markdown="## Markdown Heading\n\n**Bold text** inserted via tab_id.",
        location="start",
        tab_id=tab_id,
    )
    result_data = json.loads(result)
    assert result_data.get("success"), f"Markdown insert failed: {result}"

    # Verify markdown was inserted
    content = await docs_tools_module.get_doc_content.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        tab_id=tab_id,
    )
    assert "Markdown Heading" in content
    assert "Bold text" in content


@pytest.mark.asyncio
@pytest.mark.integration
async def test_batch_edit_doc_with_tab_id(user_google_email, document_with_tab_id):
    """Test batch_edit_doc correctly propagates tab_id to API requests."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # First add some content
    await docs_tools_module.modify_doc_text.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        location="start",
        text="Initial content for batch test",
        tab_id=tab_id,
    )

    # Use batch_edit with explicit tab_id
    result = await docs_tools_module.batch_edit_doc.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        operations=[
            {"type": "insert_text", "location": "end", "text": "\nBatch inserted text"},
        ],
        tab_id=tab_id,
    )
    result_data = json.loads(result)
    assert result_data.get("success"), f"Batch edit failed: {result}"

    # Verify content
    content = await docs_tools_module.get_doc_content.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        tab_id=tab_id,
    )
    assert "Batch inserted text" in content


@pytest.mark.asyncio
@pytest.mark.integration
async def test_find_and_replace_with_tab_id(user_google_email, document_with_tab_id):
    """Test find_and_replace_doc correctly propagates tab_id to API requests."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # Add content with a word to replace
    await docs_tools_module.modify_doc_text.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        location="start",
        text="Replace this PLACEHOLDER word here",
        tab_id=tab_id,
    )

    # Replace with explicit tab_id
    result = await docs_tools_module.find_and_replace_doc.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        find_text="PLACEHOLDER",
        replace_text="REPLACED",
        tab_id=tab_id,
    )
    result_data = json.loads(result)
    assert result_data.get("success"), f"Find/replace failed: {result}"

    # Verify replacement
    content = await docs_tools_module.get_doc_content.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        tab_id=tab_id,
    )
    assert "REPLACED" in content
    assert "PLACEHOLDER" not in content


@pytest.mark.asyncio
@pytest.mark.integration
async def test_create_table_with_tab_id(user_google_email, document_with_tab_id):
    """Test create_table_with_data correctly propagates tab_id to API requests."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # Create table with explicit tab_id
    result = await docs_tools_module.create_table_with_data.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        table_data=[
            ["Header A", "Header B"],
            ["Data 1", "Data 2"],
        ],
        location="start",
        tab_id=tab_id,
    )
    # Result can be JSON string or plain message, check for success indicators
    if result:
        try:
            result_data = json.loads(result)
            assert result_data.get("success"), f"Table creation failed: {result}"
        except json.JSONDecodeError:
            # Result is a plain message, check for success indicators
            assert "error" not in result.lower(), f"Table creation failed: {result}"

    # Verify table content
    content = await docs_tools_module.get_doc_content.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        tab_id=tab_id,
    )
    assert "Header A" in content or "Data 1" in content


@pytest.mark.asyncio
@pytest.mark.integration
async def test_get_doc_info_with_tab_id(user_google_email, document_with_tab_id):
    """Test get_doc_info correctly returns info for specific tab."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # Add content first
    await docs_tools_module.modify_doc_text.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        location="start",
        text="Content for info test\n\nMore content here.",
        tab_id=tab_id,
    )

    # Get info with explicit tab_id
    result = await docs_tools_module.get_doc_info.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        detail="basic",  # Use "basic" detail level instead of "structure"
        tab_id=tab_id,
    )
    # Result can be JSON string or formatted output
    if result:
        try:
            result_data = json.loads(result)
            assert result_data.get("tab_id") == tab_id
        except json.JSONDecodeError:
            # For non-JSON results, just verify we got some content back
            assert len(result) > 0, "get_doc_info returned empty result"


@pytest.mark.asyncio
@pytest.mark.integration
async def test_format_all_occurrences_with_tab_id(
    user_google_email, document_with_tab_id
):
    """Test format_all_occurrences correctly propagates tab_id to API requests."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # Add content with repeated word (all lowercase to match case-sensitive search)
    await docs_tools_module.modify_doc_text.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        location="start",
        text="important word here and another important word there",
        tab_id=tab_id,
    )

    # Format all occurrences with explicit tab_id
    # Note: parameter is 'search' not 'search_text'
    result = await docs_tools_module.format_all_occurrences.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        search="important",
        bold=True,
        tab_id=tab_id,
    )
    result_data = json.loads(result)
    assert result_data.get("success"), f"Format all occurrences failed: {result}"
    assert result_data.get("occurrences_formatted", 0) >= 2


@pytest.mark.asyncio
@pytest.mark.integration
async def test_list_doc_tabs_returns_tab_info(user_google_email, document_with_tab_id):
    """Test list_doc_tabs correctly returns tab information."""
    doc_id = document_with_tab_id["document_id"]

    result = await docs_tools_module.list_doc_tabs.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
    )

    # Result should contain tab_id information
    assert "tab_id:" in result or "tabId" in result


@pytest.mark.asyncio
@pytest.mark.integration
async def test_get_doc_content_with_tab_id(user_google_email, document_with_tab_id):
    """Test get_doc_content correctly returns content for specific tab."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # Add unique content
    unique_text = "Unique content for tab verification test"
    await docs_tools_module.modify_doc_text.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        location="start",
        text=unique_text,
        tab_id=tab_id,
    )

    # Get content with explicit tab_id
    content = await docs_tools_module.get_doc_content.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        tab_id=tab_id,
    )

    assert unique_text in content


@pytest.mark.asyncio
@pytest.mark.integration
async def test_replace_doc_content_with_tab_id(
    user_google_email, document_with_tab_id
):
    """Test replace_doc_content correctly propagates tab_id."""
    doc_id = document_with_tab_id["document_id"]
    tab_id = document_with_tab_id["tab_id"]

    # Replace entire document content with tab_id
    result = await docs_tools_module.replace_doc_content.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        text="Completely new content for the tab",
        tab_id=tab_id,
    )
    result_data = json.loads(result)
    assert result_data.get("success"), f"Replace content failed: {result}"

    # Verify new content
    content = await docs_tools_module.get_doc_content.fn(
        user_google_email=user_google_email,
        document_id=doc_id,
        tab_id=tab_id,
    )
    assert "Completely new content" in content
