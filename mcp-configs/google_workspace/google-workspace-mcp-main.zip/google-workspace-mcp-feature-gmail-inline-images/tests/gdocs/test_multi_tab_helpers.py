"""Tests for multi-tab document helper functions. @ai-generated"""
import pytest
from gdocs.docs_structure import (
    find_tab_by_id, get_body_for_tab, get_lists_for_tab,
    get_inline_objects_for_tab, extract_structural_elements,
)

# -- Shared fixtures --

def _two_tab_doc(tab1_extra=None, tab2_extra=None):
    """Create a minimal two-tab document. Extra dicts merged into each documentTab."""
    tab1 = {"body": {"content": [{"paragraph": {"elements": [{"textRun": {"content": "Tab 1"}}]}}]}}
    tab2 = {"body": {"content": [{"paragraph": {"elements": [{"textRun": {"content": "Tab 2"}}]}}]}}
    if tab1_extra:
        tab1.update(tab1_extra)
    if tab2_extra:
        tab2.update(tab2_extra)
    return {
        "tabs": [
            {"tabProperties": {"tabId": "tab_1"}, "documentTab": tab1},
            {"tabProperties": {"tabId": "tab_2"}, "documentTab": tab2},
        ]
    }

LEGACY_DOC = {
    "body": {"content": [{"paragraph": {"elements": [{"textRun": {"content": "Legacy"}}]}}]},
    "lists": {"list_root": {"listProperties": {"nestingLevels": [{"glyphType": "DECIMAL"}]}}},
    "inlineObjects": {"img_legacy": {"inlineObjectProperties": {"size": {"width": {"magnitude": 150}}}}},
}

NESTED_TAB_DOC = {
    "tabs": [{
        "tabProperties": {"tabId": "parent"},
        "documentTab": {"body": {"content": []}},
        "childTabs": [{
            "tabProperties": {"tabId": "child"},
            "documentTab": {"body": {"content": [{"paragraph": {"elements": [{"textRun": {"content": "Child"}}]}}]}},
        }],
    }]
}


class TestFindTabById:
    @pytest.mark.parametrize("tab_id,expected_text", [
        ("tab_1", "Tab 1"),
        ("tab_2", "Tab 2"),
    ])
    def test_returns_correct_tab(self, tab_id, expected_text):
        result = find_tab_by_id(_two_tab_doc(), tab_id)
        assert result["body"]["content"][0]["paragraph"]["elements"][0]["textRun"]["content"] == expected_text

    def test_finds_nested_child_tab(self):
        result = find_tab_by_id(NESTED_TAB_DOC, "child")
        assert result["body"]["content"][0]["paragraph"]["elements"][0]["textRun"]["content"] == "Child"

    @pytest.mark.parametrize("tab_id,doc_data", [
        ("nonexistent", _two_tab_doc()),
        ("tab_1", {"body": {"content": []}}),  # legacy doc, no tabs key
        (None, _two_tab_doc()),
    ])
    def test_returns_none(self, tab_id, doc_data):
        assert find_tab_by_id(doc_data, tab_id) is None

    def test_returns_empty_dict_for_empty_document_tab(self):
        """Falsy-check bug: empty {} must not be treated as None."""
        doc = {"tabs": [{"tabProperties": {"tabId": "t1"}, "documentTab": {}}]}
        result = find_tab_by_id(doc, "t1")
        assert result == {}
        assert result is not None


class TestGetBodyForTab:
    def test_returns_body_for_specified_tab(self):
        body = get_body_for_tab(_two_tab_doc(), "tab_2")
        assert body["content"][0]["paragraph"]["elements"][0]["textRun"]["content"] == "Tab 2"

    def test_returns_first_tab_when_none(self):
        body = get_body_for_tab(_two_tab_doc(), None)
        assert body["content"][0]["paragraph"]["elements"][0]["textRun"]["content"] == "Tab 1"

    def test_returns_root_body_for_legacy_doc(self):
        body = get_body_for_tab(LEGACY_DOC, None)
        assert body["content"][0]["paragraph"]["elements"][0]["textRun"]["content"] == "Legacy"

    def test_logs_warning_and_falls_back_on_missing_tab(self, caplog):
        body = get_body_for_tab(_two_tab_doc(), "nonexistent")
        assert "not found in document" in caplog.text
        assert body["content"][0]["paragraph"]["elements"][0]["textRun"]["content"] == "Tab 1"

    def test_returns_empty_body_not_fallback(self):
        """Falsy-check bug: tab with empty body {} should not fall back."""
        doc = {
            "tabs": [
                {"tabProperties": {"tabId": "t1"}, "documentTab": {"body": {}}},
                {"tabProperties": {"tabId": "t2"}, "documentTab": {"body": {"content": [{"paragraph": {}}]}}},
            ]
        }
        assert get_body_for_tab(doc, "t1") == {}


class TestGetListsForTab:
    def test_returns_lists_for_specified_tab(self):
        doc = _two_tab_doc(
            tab1_extra={"lists": {"l1": {"nestingLevels": [{"glyphType": "BULLET"}]}}},
            tab2_extra={"lists": {"l2": {"nestingLevels": [{"glyphType": "DECIMAL"}]}}},
        )
        assert "l1" in get_lists_for_tab(doc, "tab_1")
        assert "l1" not in get_lists_for_tab(doc, "tab_2")

    def test_returns_empty_dict_for_tab_without_lists(self):
        assert get_lists_for_tab(_two_tab_doc(), "tab_1") == {}

    def test_returns_first_tab_lists_when_none(self):
        doc = _two_tab_doc(tab1_extra={"lists": {"l1": {}}})
        assert "l1" in get_lists_for_tab(doc, None)

    def test_returns_root_lists_for_legacy_doc(self):
        assert "list_root" in get_lists_for_tab(LEGACY_DOC, None)


class TestGetInlineObjectsForTab:
    def test_returns_objects_for_specified_tab(self):
        doc = _two_tab_doc(
            tab1_extra={"inlineObjects": {"img1": {}, "img2": {}}},
            tab2_extra={"inlineObjects": {"img3": {}}},
        )
        result = get_inline_objects_for_tab(doc, "tab_1")
        assert "img1" in result and "img2" in result and "img3" not in result

    def test_returns_empty_dict_for_tab_without_objects(self):
        assert get_inline_objects_for_tab(_two_tab_doc(), "tab_1") == {}

    def test_returns_first_tab_objects_when_none(self):
        doc = _two_tab_doc(tab1_extra={"inlineObjects": {"img1": {}}})
        result = get_inline_objects_for_tab(doc, None)
        assert "img1" in result

    def test_returns_root_objects_for_legacy_doc(self):
        assert "img_legacy" in get_inline_objects_for_tab(LEGACY_DOC, None)


class TestExtractStructuralElementsListsFix:
    """Verifies extract_structural_elements reads tab-scoped lists, not root."""

    def _list_doc(self, tab_glyph="DECIMAL", root_lists=None):
        return {
            "lists": root_lists or {},
            "tabs": [{
                "tabProperties": {"tabId": "tab1"},
                "documentTab": {
                    "body": {"content": [{
                        "startIndex": 0, "endIndex": 10,
                        "paragraph": {
                            "elements": [{"textRun": {"content": "Item 1"}}],
                            "bullet": {"listId": "list_1", "nestingLevel": 0},
                        },
                    }]},
                    "lists": {"list_1": {"listProperties": {"nestingLevels": [{"glyphType": tab_glyph}]}}},
                },
            }],
        }

    def test_uses_tab_scoped_lists(self):
        """Root lists empty, tab has DECIMAL → must detect numbered_list, not bullet_list."""
        result = extract_structural_elements(self._list_doc(), tab_id="tab1")
        lists = [e for e in result if e["type"] in ("bullet_list", "numbered_list")]
        assert lists[0]["type"] == "numbered_list"

    def test_falls_back_to_root_for_legacy_doc(self):
        doc = {
            "lists": {"lr": {"listProperties": {"nestingLevels": [{"glyphType": "DECIMAL"}]}}},
            "body": {"content": [{
                "startIndex": 0, "endIndex": 10,
                "paragraph": {
                    "elements": [{"textRun": {"content": "Item"}}],
                    "bullet": {"listId": "lr", "nestingLevel": 0},
                },
            }]},
        }
        result = extract_structural_elements(doc, tab_id=None)
        lists = [e for e in result if e["type"] in ("bullet_list", "numbered_list")]
        assert lists[0]["type"] == "numbered_list"

    def test_does_not_cross_contaminate_between_tabs(self):
        """Tab1 has DECIMAL, tab2 has BULLET for same list_id → tab1 must be numbered."""
        doc = {
            "lists": {},
            "tabs": [
                {"tabProperties": {"tabId": "tab1"}, "documentTab": {
                    "body": {"content": [{"startIndex": 0, "endIndex": 10, "paragraph": {
                        "elements": [{"textRun": {"content": "T1"}}],
                        "bullet": {"listId": "list_abc", "nestingLevel": 0},
                    }}]},
                    "lists": {"list_abc": {"listProperties": {"nestingLevels": [{"glyphType": "DECIMAL"}]}}},
                }},
                {"tabProperties": {"tabId": "tab2"}, "documentTab": {
                    "body": {"content": [{"startIndex": 0, "endIndex": 10, "paragraph": {
                        "elements": [{"textRun": {"content": "T2"}}],
                        "bullet": {"listId": "list_abc", "nestingLevel": 0},
                    }}]},
                    "lists": {"list_abc": {"listProperties": {"nestingLevels": [{"glyphType": "BULLET"}]}}},
                }},
            ],
        }
        result = extract_structural_elements(doc, tab_id="tab1")
        lists = [e for e in result if e["type"] in ("bullet_list", "numbered_list")]
        assert lists[0]["type"] == "numbered_list"
