"""
Unit tests for insert_markdown tab_id propagation.

These tests verify that insert_markdown correctly passes tab_id to all
its internal helper functions, ensuring tab_id flows through the entire
operation chain.
"""

from unittest.mock import AsyncMock, MagicMock, patch
import pytest


class TestInsertMarkdownHelperTabId:
    """
    Tests that insert_markdown helper functions correctly handle tab_id.

    Since insert_markdown is wrapped with service decorators, we test the
    internal helper functions directly to verify tab_id propagation.
    """

    @pytest.fixture
    def mock_docs_service(self):
        """Create a mock docs service."""
        service = MagicMock()
        # Mock document get response
        service.documents().get().execute.return_value = {
            "documentId": "test-doc-id",
            "title": "Test Document",
            "tabs": [
                {
                    "tabProperties": {"tabId": "tab1"},
                    "documentTab": {
                        "body": {
                            "content": [
                                {"endIndex": 1, "sectionBreak": {}},
                                {
                                    "startIndex": 1,
                                    "endIndex": 2,
                                    "paragraph": {
                                        "elements": [
                                            {
                                                "startIndex": 1,
                                                "endIndex": 2,
                                                "textRun": {"content": "\n"},
                                            }
                                        ]
                                    },
                                },
                            ]
                        }
                    },
                }
            ],
        }
        # Mock batchUpdate response
        service.documents().batchUpdate().execute.return_value = {"replies": []}
        return service

    @pytest.mark.asyncio
    async def test_insert_section_text_includes_tab_id_in_request(
        self, mock_docs_service
    ):
        """Test _insert_section_text_and_formatting includes tabId in insertText request."""
        from gdocs.docs_tools import _insert_section_text_and_formatting, MarkdownSection

        tab_id = "test-tab-123"
        # Create section with correct field names
        section = MarkdownSection(
            text="Hello world\n",
            formatting_requests=[],
            list_ranges=[],
            table=None,
            hr_positions=[],
        )

        # Capture the batchUpdate calls
        batch_update_calls = []

        def capture_batch_update(*args, **kwargs):
            batch_update_calls.append(kwargs.get("body", {}))
            execute_mock = MagicMock()
            execute_mock.execute.return_value = {"replies": []}
            return execute_mock

        mock_docs_service.documents().batchUpdate.side_effect = capture_batch_update

        with patch("asyncio.to_thread", new_callable=AsyncMock) as mock_to_thread:
            # Setup mock to call the actual function passed to to_thread
            async def execute_in_thread(func):
                return func()

            mock_to_thread.side_effect = execute_in_thread

            await _insert_section_text_and_formatting(
                mock_docs_service,
                "test-doc-id",
                section,
                1,  # insert_index
                tab_id,
            )

            # Verify batchUpdate was called and the first call has insertText with tabId
            assert len(batch_update_calls) > 0
            first_call = batch_update_calls[0]
            requests = first_call.get("requests", [])
            # Find the insertText request
            for req in requests:
                if "insertText" in req:
                    assert req["insertText"]["location"].get("tabId") == tab_id, (
                        f"tabId not in insertText: {req}"
                    )
                    break

    @pytest.mark.asyncio
    async def test_get_document_end_index_with_tab_id(self, mock_docs_service):
        """Test _get_document_end_index correctly handles tab_id."""
        from gdocs.docs_tools import _get_document_end_index

        tab_id = "test-tab-456"

        # Setup mock to return document with specific tab
        mock_docs_service.documents().get().execute.return_value = {
            "documentId": "test-doc-id",
            "tabs": [
                {
                    "tabProperties": {"tabId": tab_id},
                    "documentTab": {
                        "body": {
                            "content": [
                                {"endIndex": 1},
                                {"startIndex": 1, "endIndex": 50, "paragraph": {}},
                            ]
                        }
                    },
                }
            ],
        }

        with patch("asyncio.to_thread", new_callable=AsyncMock) as mock_to_thread:
            mock_to_thread.return_value = mock_docs_service.documents().get().execute()

            result = await _get_document_end_index(
                mock_docs_service, "test-doc-id", tab_id
            )

            # Should return the end index from the correct tab
            assert result == 50


class TestInsertMarkdownRequestBuilding:
    """
    Tests that verify the request building includes tab_id.

    These tests check the helper functions that build API requests.
    """

    def test_insert_text_request_builder_includes_tab_id(self):
        """Test that create_insert_text_request includes tabId when provided."""
        from gdocs.docs_helpers import create_insert_text_request

        tab_id = "my-tab-id"
        request = create_insert_text_request(10, "Hello", tab_id=tab_id)

        assert request["insertText"]["location"]["tabId"] == tab_id

    def test_paragraph_style_request_includes_tab_id(self):
        """Test that create_paragraph_style_request includes tabId when provided."""
        from gdocs.docs_helpers import create_paragraph_style_request

        tab_id = "style-tab-id"
        request = create_paragraph_style_request(
            start_index=1,
            end_index=50,
            heading_style="HEADING_1",
            tab_id=tab_id,
        )

        assert request["updateParagraphStyle"]["range"]["tabId"] == tab_id

    def test_delete_range_request_includes_tab_id(self):
        """Test that create_delete_range_request includes tabId when provided."""
        from gdocs.docs_helpers import create_delete_range_request

        tab_id = "delete-tab-id"
        request = create_delete_range_request(1, 50, tab_id=tab_id)

        assert request["deleteContentRange"]["range"]["tabId"] == tab_id

    def test_clear_formatting_request_includes_tab_id(self):
        """Test that create_clear_formatting_request includes tabId when provided."""
        from gdocs.docs_helpers import create_clear_formatting_request

        tab_id = "clear-tab-id"
        request = create_clear_formatting_request(1, 50, tab_id=tab_id)

        assert request["updateTextStyle"]["range"]["tabId"] == tab_id

    def test_bullet_list_request_includes_tab_id(self):
        """Test that create_bullet_list_request includes tabId when provided."""
        from gdocs.docs_helpers import create_bullet_list_request

        tab_id = "bullet-tab-id"
        request = create_bullet_list_request(1, 50, "BULLET", tab_id=tab_id)

        assert request["createParagraphBullets"]["range"]["tabId"] == tab_id

    def test_format_text_request_includes_tab_id(self):
        """Test that create_format_text_request includes tabId when provided."""
        from gdocs.docs_helpers import create_format_text_request

        tab_id = "textstyle-tab-id"
        request = create_format_text_request(
            start_index=1,
            end_index=50,
            bold=True,
            tab_id=tab_id,
        )

        assert request["updateTextStyle"]["range"]["tabId"] == tab_id

    def test_insert_table_request_includes_tab_id(self):
        """Test that create_insert_table_request includes tabId when provided."""
        from gdocs.docs_helpers import create_insert_table_request

        tab_id = "table-tab-id"
        request = create_insert_table_request(10, 3, 2, tab_id=tab_id)

        assert request["insertTable"]["location"]["tabId"] == tab_id


class TestInsertMarkdownEndToEndTabId:
    """
    Integration-style tests that verify insert_markdown correctly orchestrates
    tab_id through the entire operation.

    These tests mock at the asyncio.to_thread level to capture the actual
    API calls being made.
    """

    @pytest.mark.asyncio
    async def test_full_insert_markdown_operation_with_tab_id(self):
        """
        Test that a full insert_markdown operation passes tab_id through
        all stages of the operation.
        """
        from gdocs.docs_tools import (
            _insert_section_text_and_formatting,
            MarkdownSection,
        )

        tab_id = "full-test-tab-id"

        # Create a mock docs service
        mock_service = MagicMock()

        # Capture all batchUpdate calls
        batch_update_calls = []

        def capture_batch_update(*args, **kwargs):
            batch_update_calls.append(kwargs.get("body", args[0] if args else {}))
            execute_mock = MagicMock()
            execute_mock.execute.return_value = {"replies": []}
            return execute_mock

        mock_service.documents().batchUpdate.side_effect = capture_batch_update

        # Setup document get response
        mock_service.documents().get().execute.return_value = {
            "documentId": "test-doc",
            "tabs": [
                {
                    "tabProperties": {"tabId": tab_id},
                    "documentTab": {
                        "body": {
                            "content": [
                                {"endIndex": 1},
                                {
                                    "startIndex": 1,
                                    "endIndex": 20,
                                    "paragraph": {
                                        "elements": [
                                            {
                                                "startIndex": 1,
                                                "endIndex": 20,
                                                "textRun": {"content": "Test content here\n"},
                                            }
                                        ]
                                    },
                                },
                            ]
                        }
                    },
                }
            ],
        }

        # Create section with formatting request in expected format
        section = MarkdownSection(
            text="New content\n",
            formatting_requests=[
                {
                    "type": "paragraph_style",
                    "start": 0,
                    "end": 11,
                    "style": "HEADING_1",
                }
            ],
            list_ranges=[],
            table=None,
            hr_positions=[],
        )

        with patch("asyncio.to_thread", new_callable=AsyncMock) as mock_to_thread:
            # Setup mock to pass through to the actual service mock
            async def execute_in_thread(func):
                return func()

            mock_to_thread.side_effect = execute_in_thread

            # Run the helper function
            await _insert_section_text_and_formatting(
                mock_service, "test-doc", section, 1, tab_id
            )

            # Verify that batchUpdate was called with requests containing tabId
            assert len(batch_update_calls) > 0
            for call_body in batch_update_calls:
                requests = call_body.get("requests", [])
                for req in requests:
                    # Check insertText requests
                    if "insertText" in req:
                        location = req["insertText"]["location"]
                        assert location.get("tabId") == tab_id, (
                            f"tabId missing or wrong in insertText: {req}"
                        )
                    # Check updateParagraphStyle requests
                    if "updateParagraphStyle" in req:
                        range_obj = req["updateParagraphStyle"]["range"]
                        assert range_obj.get("tabId") == tab_id, (
                            f"tabId missing or wrong in updateParagraphStyle: {req}"
                        )
                    # Check updateTextStyle requests
                    if "updateTextStyle" in req:
                        range_obj = req["updateTextStyle"]["range"]
                        assert range_obj.get("tabId") == tab_id, (
                            f"tabId missing or wrong in updateTextStyle: {req}"
                        )
