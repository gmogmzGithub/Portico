"""
Unit tests for multi-tab support in operation managers, list style fixes,
and insert_markdown tab_id propagation.
"""
from unittest.mock import MagicMock, patch
import pytest
from gdocs.managers.table_operation_manager import TableOperationManager
from gdocs.managers.batch_operation_manager import BatchOperationManager
from gdocs.docs_helpers import create_paragraph_style_request, create_insert_text_request, create_delete_range_request


class TestTableOperationManagerTabSupport:
    @pytest.mark.asyncio
    async def test_create_table_with_tab_id(self):
        """Test creating table with specific tab_id propagates to all requests."""
        mock_service = MagicMock()
        manager = TableOperationManager(mock_service, tab_id="tab1")

        # Mock document get response
        mock_doc = {
            "body": {"content": []},
            "tabs": [
                {
                    "tabProperties": {"tabId": "tab1"},
                    "documentTab": {"body": {"content": []}},
                }
            ],
        }

        # Setup mocks
        mock_service.documents().get().execute.return_value = mock_doc

        # We need to mock find_tables to return our table structure
        with patch(
            "gdocs.managers.table_operation_manager.find_tables"
        ) as mock_find_tables:
            # Simulate one table found
            mock_find_tables.return_value = [
                {
                    "start_index": 10,
                    "end_index": 50,
                    "rows": 1,
                    "columns": 1,
                    "cells": [
                        [{"insertion_index": 15, "end_index": 20, "content": ""}]
                    ],
                }
            ]

            # Execute create table
            await manager.create_and_populate_table("doc_id", [["data"]], 1)

            # Verify batchUpdate calls
            # Expecting at least 2 calls: one for create, one for populate
            calls = mock_service.documents().batchUpdate.call_args_list
            assert len(calls) >= 2

            # Verify create table has tab_id
            create_call = calls[0]
            create_body = (
                create_call.kwargs["body"]
                if "body" in create_call.kwargs
                else create_call[0][1]["body"]
            )
            reqs = create_body["requests"]
            assert reqs[0]["insertTable"]["location"]["tabId"] == "tab1"

            # Verify populate cell has tab_id
            populate_call = calls[1]
            populate_body = (
                populate_call.kwargs["body"]
                if "body" in populate_call.kwargs
                else populate_call[0][1]["body"]
            )
            reqs = populate_body["requests"]

            # Check insertText
            assert (
                "tabId" in reqs[0]["insertText"]["location"]
            ), "tabId missing in insertText location"
            assert reqs[0]["insertText"]["location"]["tabId"] == "tab1"

    @pytest.mark.asyncio
    async def test_populate_existing_table_with_tab_id(self):
        """Test populating existing table with tab_id."""
        mock_service = MagicMock()
        manager = TableOperationManager(mock_service, tab_id="tab1")

        # Mock finding tables
        with patch(
            "gdocs.managers.table_operation_manager.find_tables"
        ) as mock_find_tables:
            mock_find_tables.return_value = [
                {
                    "start_index": 10,
                    "end_index": 50,
                    "rows": 1,
                    "columns": 1,
                    "cells": [
                        [{"insertion_index": 15, "end_index": 20, "content": ""}]
                    ],
                }
            ]

            # Execute
            await manager.populate_existing_table("doc_id", 0, [["data"]])

            # Verify call
            mock_service.documents().batchUpdate.assert_called()
            call_args = mock_service.documents().batchUpdate.call_args
            body = (
                call_args.kwargs["body"]
                if "body" in call_args.kwargs
                else call_args[0][1]["body"]
            )
            reqs = body["requests"]

            assert (
                "tabId" in reqs[0]["insertText"]["location"]
            ), "tabId missing in insertText location"
            assert reqs[0]["insertText"]["location"]["tabId"] == "tab1"

    @pytest.mark.asyncio
    async def test_apply_bold_formatting_with_tab_id(self):
        """Test apply_bold_formatting uses tab_id."""
        mock_service = MagicMock()
        manager = TableOperationManager(mock_service, tab_id="tab1")

        await manager._apply_bold_formatting("doc_id", 10, 20)

        call_args = mock_service.documents().batchUpdate.call_args
        body = (
            call_args.kwargs["body"]
            if "body" in call_args.kwargs
            else call_args[0][1]["body"]
        )
        reqs = body["requests"]

        assert (
            "tabId" in reqs[0]["updateTextStyle"]["range"]
        ), "tabId missing in updateTextStyle range"
        assert reqs[0]["updateTextStyle"]["range"]["tabId"] == "tab1"


class TestBatchOperationManagerTabSupport:
    def test_batch_manager_stores_tab_id(self):
        """Test BatchOperationManager stores tab_id correctly."""
        mock_service = MagicMock()
        manager = BatchOperationManager(mock_service, tab_id="tab1")

        assert manager.tab_id == "tab1"

    def test_batch_manager_default_tab_id_is_none(self):
        """Test BatchOperationManager defaults to None tab_id."""
        mock_service = MagicMock()
        manager = BatchOperationManager(mock_service)

        assert manager.tab_id is None

    @pytest.mark.asyncio
    async def test_batch_manager_propagates_tab_id_to_requests(self):
        """Test BatchOperationManager propagates tab_id to API requests."""
        mock_service = MagicMock()
        manager = BatchOperationManager(mock_service, tab_id="tab1")

        operations = [{"type": "insert_text", "index": 1, "text": "hello"}]

        # Mock document structure for validation
        mock_doc = {
            "body": {"content": [{"sectionBreak": {}}, {"paragraph": {}}]},
            "tabs": [
                {
                    "tabProperties": {"tabId": "tab1"},
                    "documentTab": {
                        "body": {
                            "content": [{"sectionBreak": {}}, {"paragraph": {}}]
                        }
                    },
                }
            ],
        }
        mock_service.documents().get().execute.return_value = mock_doc

        # Mock resolve_range for validation
        with patch(
            "gdocs.managers.batch_operation_manager.resolve_range"
        ) as mock_resolve:
            mock_result = MagicMock()
            mock_result.success = True
            mock_result.start_index = 1
            mock_result.end_index = 6
            mock_resolve.return_value = mock_result

            await manager.execute_batch_operations("doc_id", operations)

            # Check that batchUpdate was called
            mock_service.documents().batchUpdate.assert_called()
            call_args = mock_service.documents().batchUpdate.call_args
            body = (
                call_args.kwargs["body"]
                if "body" in call_args.kwargs
                else call_args[0][1]["body"]
            )
            reqs = body["requests"]

            # Check insert text has tabId
            assert (
                "tabId" in reqs[0]["insertText"]["location"]
            ), "tabId missing in insertText location"
            assert reqs[0]["insertText"]["location"]["tabId"] == "tab1"

            # Check clear formatting request also has tabId
            if len(reqs) > 1 and "updateTextStyle" in reqs[1]:
                assert (
                    "tabId" in reqs[1]["updateTextStyle"]["range"]
                ), "tabId missing in updateTextStyle range"
                assert reqs[1]["updateTextStyle"]["range"]["tabId"] == "tab1"


class TestListStyleReset:
    """Tests for list style reset to NORMAL_TEXT after insertion.

    When inserting a list after a heading, the list items should NOT inherit
    the heading's paragraph style. The fix adds a paragraph style reset to
    NORMAL_TEXT when creating lists via insert_doc_elements.
    """

    def test_paragraph_style_request_sets_normal_text(self):
        """Test create_paragraph_style_request generates NORMAL_TEXT style."""
        request = create_paragraph_style_request(
            start_index=10,
            end_index=50,
            heading_style="NORMAL_TEXT",
        )

        assert request is not None
        assert "updateParagraphStyle" in request
        style = request["updateParagraphStyle"]
        assert style["paragraphStyle"]["namedStyleType"] == "NORMAL_TEXT"
        assert style["range"]["startIndex"] == 10
        assert style["range"]["endIndex"] == 50

    def test_paragraph_style_request_with_tab_id(self):
        """Test create_paragraph_style_request includes tab_id when provided."""
        request = create_paragraph_style_request(
            start_index=10,
            end_index=50,
            heading_style="NORMAL_TEXT",
            tab_id="tab1",
        )

        assert request is not None
        assert "updateParagraphStyle" in request
        style = request["updateParagraphStyle"]
        assert style["range"]["tabId"] == "tab1"

    def test_paragraph_style_request_without_tab_id(self):
        """Test create_paragraph_style_request works without tab_id."""
        request = create_paragraph_style_request(
            start_index=10,
            end_index=50,
            heading_style="NORMAL_TEXT",
        )

        assert request is not None
        assert "tabId" not in request["updateParagraphStyle"]["range"]


class TestInsertMarkdownTabIdPropagation:
    """Tests for insert_markdown tab_id propagation to API requests.

    The insert_markdown function should propagate tab_id to:
    - find_text_in_document (for search-based positioning)
    - find_heading_range (for heading-based positioning)
    - deleteContentRange requests (for replace_content mode)
    - insertText requests (via _insert_section_text_and_formatting)
    - All formatting requests (paragraph styles, text styles, bullets)
    """

    def test_insert_text_request_with_tab_id(self):
        """Test create_insert_text_request includes tab_id when provided."""
        request = create_insert_text_request(10, "Hello", tab_id="tab1")

        assert "insertText" in request
        assert request["insertText"]["location"]["index"] == 10
        assert request["insertText"]["location"]["tabId"] == "tab1"
        assert request["insertText"]["text"] == "Hello"

    def test_insert_text_request_without_tab_id(self):
        """Test create_insert_text_request works without tab_id."""
        request = create_insert_text_request(10, "Hello")

        assert "insertText" in request
        assert request["insertText"]["location"]["index"] == 10
        assert "tabId" not in request["insertText"]["location"]

    def test_insert_text_request_with_none_tab_id(self):
        """Test create_insert_text_request handles None tab_id correctly."""
        request = create_insert_text_request(10, "Hello", tab_id=None)

        assert "insertText" in request
        assert "tabId" not in request["insertText"]["location"]

    def test_paragraph_style_request_for_markdown_with_tab_id(self):
        """Test paragraph style requests include tab_id for markdown formatting."""
        # This simulates the formatting applied after markdown insertion
        request = create_paragraph_style_request(
            start_index=1,
            end_index=50,
            heading_style="HEADING_1",
            tab_id="tab1",
        )

        assert request is not None
        assert "updateParagraphStyle" in request
        assert request["updateParagraphStyle"]["range"]["tabId"] == "tab1"
        assert request["updateParagraphStyle"]["paragraphStyle"]["namedStyleType"] == "HEADING_1"


class TestCreateDeleteRangeRequestWithTabId:
    """Tests for create_delete_range_request with tab_id parameter."""

    @pytest.mark.parametrize("tab_id,should_have_tab_id", [
        (None, False),
        ("tab1", True),
        ("tab2", True),
    ])
    def test_create_delete_range_request_includes_tab_id(self, tab_id, should_have_tab_id):
        """Verify create_delete_range_request includes tabId when tab_id is provided."""
        result = create_delete_range_request(10, 20, tab_id=tab_id)

        assert "deleteContentRange" in result
        range_spec = result["deleteContentRange"]["range"]

        if should_have_tab_id:
            assert "tabId" in range_spec
            assert range_spec["tabId"] == tab_id
        else:
            assert "tabId" not in range_spec

