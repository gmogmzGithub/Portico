"""
Async tool tests for calendar tools using mocked Google service.

These tests verify the actual async tool functions (create_out_of_office,
create_focus_time, respond_to_event, get_free_busy, find_available_slots)
by mocking the Google Calendar API service via the auth layer.
"""

import pytest
from unittest.mock import MagicMock, patch
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


def create_mock_credentials():
    """Create a mock credentials object with required attributes."""
    mock_creds = MagicMock()
    mock_creds.valid = True
    mock_creds.expired = False
    mock_creds.refresh_token = "mock_refresh_token"
    return mock_creds


class TestCreateOutOfOfficeAsync:
    """Tests for create_out_of_office async tool."""

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_ooo_success(self, mock_get_service, mock_to_thread):
        """Test create_out_of_office creates event successfully."""
        from gcalendar.calendar_tools import create_out_of_office

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_insert(func, *args, **kwargs):
            return {
                "id": "ooo123",
                "htmlLink": "http://calendar/ooo123",
                "summary": "Out of office"
            }
        
        mock_to_thread.side_effect = execute_insert

        result = await create_out_of_office.fn(
            user_google_email="test@example.com",
            start_time="2025-01-20T09:00:00Z",
            end_time="2025-01-20T17:00:00Z",
            auto_decline_mode="declineAllConflictingInvitations",
            decline_message="I am away",
            calendar_id="primary",
            send_updates="all"
        )

        assert "Successfully created Out of Office" in result
        assert "ooo123" in result
        assert "I am away" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_ooo_default_decline_message(self, mock_get_service, mock_to_thread):
        """Test OOO uses default decline message when not specified."""
        from gcalendar.calendar_tools import create_out_of_office

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_insert(func, *args, **kwargs):
            return {"id": "ooo456", "htmlLink": "http://calendar/ooo456"}
        
        mock_to_thread.side_effect = execute_insert

        result = await create_out_of_office.fn(
            user_google_email="test@example.com",
            start_time="2025-01-20T09:00:00Z",
            end_time="2025-01-20T17:00:00Z"
        )

        assert "Successfully created Out of Office" in result
        assert "ooo456" in result


class TestCreateFocusTimeAsync:
    """Tests for create_focus_time async tool."""

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_focus_time_success(self, mock_get_service, mock_to_thread):
        """Test create_focus_time creates event successfully."""
        from gcalendar.calendar_tools import create_focus_time

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_insert(func, *args, **kwargs):
            return {
                "id": "focus123",
                "htmlLink": "http://calendar/focus123",
                "summary": "Focus Time"
            }
        
        mock_to_thread.side_effect = execute_insert

        result = await create_focus_time.fn(
            user_google_email="test@example.com",
            start_time="2025-01-20T09:00:00Z",
            end_time="2025-01-20T11:00:00Z",
            chat_status="doNotDisturb",
            summary="Deep work"
        )

        assert "Successfully created Focus Time" in result
        assert "focus123" in result
        assert "Deep work" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_focus_time_default_summary(self, mock_get_service, mock_to_thread):
        """Test focus time with default summary."""
        from gcalendar.calendar_tools import create_focus_time

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_insert(func, *args, **kwargs):
            return {"id": "focus789", "htmlLink": "http://calendar/focus789"}
        
        mock_to_thread.side_effect = execute_insert

        result = await create_focus_time.fn(
            user_google_email="test@example.com",
            start_time="2025-01-20T09:00:00Z",
            end_time="2025-01-20T11:00:00Z"
        )

        assert "Successfully created Focus Time" in result


class TestRespondToEventAsync:
    """Tests for respond_to_event async tool."""

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_respond_accept(self, mock_get_service, mock_to_thread):
        """Test accepting an event invitation."""
        from gcalendar.calendar_tools import respond_to_event

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        call_count = [0]
        
        async def handle_calls(func, *args, **kwargs):
            call_count[0] += 1
            if call_count[0] == 1:  # First call is get
                return {
                    "id": "event123",
                    "summary": "Team Meeting",
                    "attendees": [
                        {"email": "test@example.com", "responseStatus": "needsAction"},
                        {"email": "other@example.com", "responseStatus": "accepted"}
                    ]
                }
            else:  # Second call is patch
                return {"id": "event123", "status": "confirmed"}
        
        mock_to_thread.side_effect = handle_calls

        result = await respond_to_event.fn(
            user_google_email="test@example.com",
            calendar_id="primary",
            event_id="event123",
            response="accept",
            send_updates="none"
        )

        assert "Successfully responded" in result
        assert "accept" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_respond_decline(self, mock_get_service, mock_to_thread):
        """Test declining an event invitation."""
        from gcalendar.calendar_tools import respond_to_event

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        call_count = [0]
        
        async def handle_calls(func, *args, **kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                return {
                    "id": "event456",
                    "attendees": [{"email": "test@example.com", "responseStatus": "needsAction"}]
                }
            else:
                return {"id": "event456"}
        
        mock_to_thread.side_effect = handle_calls

        result = await respond_to_event.fn(
            user_google_email="test@example.com",
            calendar_id="primary",
            event_id="event456",
            response="decline"
        )

        assert "decline" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_respond_with_comment(self, mock_get_service, mock_to_thread):
        """Test responding with a comment."""
        from gcalendar.calendar_tools import respond_to_event

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        call_count = [0]
        
        async def handle_calls(func, *args, **kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                return {
                    "id": "event789",
                    "attendees": [{"email": "test@example.com", "responseStatus": "needsAction"}]
                }
            else:
                return {"id": "event789"}
        
        mock_to_thread.side_effect = handle_calls

        result = await respond_to_event.fn(
            user_google_email="test@example.com",
            calendar_id="primary",
            event_id="event789",
            response="tentative",
            comment="Might be late"
        )

        assert "tentative" in result


class TestGetFreeBusyAsync:
    """Tests for get_free_busy async tool."""

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_get_free_busy_with_busy_periods(self, mock_get_service, mock_to_thread):
        """Test getting free/busy showing busy periods."""
        from gcalendar.calendar_tools import get_free_busy

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_query(func, *args, **kwargs):
            return {
                "calendars": {
                    "test@example.com": {
                        "busy": [
                            {"start": "2025-01-20T10:00:00Z", "end": "2025-01-20T11:00:00Z"},
                            {"start": "2025-01-20T14:00:00Z", "end": "2025-01-20T15:00:00Z"}
                        ]
                    }
                }
            }
        
        mock_to_thread.side_effect = execute_query

        result = await get_free_busy.fn(
            user_google_email="test@example.com",
            time_min="2025-01-20T09:00:00Z",
            time_max="2025-01-20T17:00:00Z",
            emails=["test@example.com"]
        )

        assert "test@example.com" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_get_free_busy_multiple_users(self, mock_get_service, mock_to_thread):
        """Test getting free/busy for multiple users."""
        from gcalendar.calendar_tools import get_free_busy

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_query(func, *args, **kwargs):
            return {
                "calendars": {
                    "user1@example.com": {
                        "busy": [{"start": "2025-01-20T10:00:00Z", "end": "2025-01-20T11:00:00Z"}]
                    },
                    "user2@example.com": {
                        "busy": []
                    }
                }
            }
        
        mock_to_thread.side_effect = execute_query

        result = await get_free_busy.fn(
            user_google_email="test@example.com",
            time_min="2025-01-20T09:00:00Z",
            time_max="2025-01-20T17:00:00Z",
            emails=["user1@example.com", "user2@example.com"]
        )

        assert "user1@example.com" in result
        assert "user2@example.com" in result


class TestFindAvailableSlotsAsync:
    """Tests for find_available_slots async tool."""

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_find_slots_all_free(self, mock_get_service, mock_to_thread):
        """Test finding slots when everyone is free."""
        from gcalendar.calendar_tools import find_available_slots

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_query(func, *args, **kwargs):
            return {
                "calendars": {
                    "user1@example.com": {"busy": []},
                    "user2@example.com": {"busy": []}
                }
            }
        
        mock_to_thread.side_effect = execute_query

        # Use a Monday (Jan 20, 2025 is a Monday)
        result = await find_available_slots.fn(
            user_google_email="test@example.com",
            emails=["user1@example.com", "user2@example.com"],
            duration_minutes=30,
            time_min="2025-01-20T00:00:00Z",
            time_max="2025-01-21T00:00:00Z",
            working_hours_only=True,
            timezone="UTC"
        )

        assert "Available" in result
        assert "30-minute" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_find_slots_with_conflicts(self, mock_get_service, mock_to_thread):
        """Test finding slots with some busy periods."""
        from gcalendar.calendar_tools import find_available_slots

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_query(func, *args, **kwargs):
            return {
                "calendars": {
                    "user1@example.com": {
                        "busy": [
                            {"start": "2025-01-20T09:00:00Z", "end": "2025-01-20T12:00:00Z"}
                        ]
                    },
                    "user2@example.com": {
                        "busy": [
                            {"start": "2025-01-20T14:00:00Z", "end": "2025-01-20T15:00:00Z"}
                        ]
                    }
                }
            }
        
        mock_to_thread.side_effect = execute_query

        result = await find_available_slots.fn(
            user_google_email="test@example.com",
            emails=["user1@example.com", "user2@example.com"],
            duration_minutes=60,
            time_min="2025-01-20T00:00:00Z",
            time_max="2025-01-21T00:00:00Z",
            working_hours_only=True,
            timezone="UTC"
        )

        # Should find slots avoiding the busy periods
        assert "Available" in result or "No available" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_find_slots_no_availability(self, mock_get_service, mock_to_thread):
        """Test when no slots are available."""
        from gcalendar.calendar_tools import find_available_slots

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_query(func, *args, **kwargs):
            return {
                "calendars": {
                    "user1@example.com": {
                        "busy": [
                            {"start": "2025-01-20T09:00:00Z", "end": "2025-01-20T17:00:00Z"}
                        ]
                    }
                }
            }
        
        mock_to_thread.side_effect = execute_query

        result = await find_available_slots.fn(
            user_google_email="test@example.com",
            emails=["user1@example.com"],
            duration_minutes=60,
            time_min="2025-01-20T00:00:00Z",
            time_max="2025-01-21T00:00:00Z",
            working_hours_only=True,
            timezone="UTC"
        )

        assert "No available" in result


class TestCreateEventAsync:
    """Tests for create_event async tool."""

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_event_success(self, mock_get_service, mock_to_thread):
        """Test creating a basic event."""
        from gcalendar.calendar_tools import create_event

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_insert(func, *args, **kwargs):
            return {
                "id": "evt123",
                "htmlLink": "http://calendar/evt123",
                "summary": "Team Meeting"
            }
        
        mock_to_thread.side_effect = execute_insert

        result = await create_event.fn(
            user_google_email="test@example.com",
            summary="Team Meeting",
            start_time="2025-01-20T10:00:00Z",
            end_time="2025-01-20T11:00:00Z"
        )

        assert "Successfully created" in result
        assert "evt123" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_event_with_attendees(self, mock_get_service, mock_to_thread):
        """Test creating event with attendees."""
        from gcalendar.calendar_tools import create_event

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_insert(func, *args, **kwargs):
            return {"id": "evt456", "htmlLink": "http://calendar/evt456"}
        
        mock_to_thread.side_effect = execute_insert

        result = await create_event.fn(
            user_google_email="test@example.com",
            summary="Project Sync",
            start_time="2025-01-20T10:00:00Z",
            end_time="2025-01-20T11:00:00Z",
            attendees=["colleague@example.com", "manager@example.com"]
        )

        assert "Successfully created" in result

    @pytest.mark.asyncio
    @patch("gcalendar.calendar_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_event_with_zoom(self, mock_get_service, mock_to_thread):
        """Test creating event with Zoom link."""
        from gcalendar.calendar_tools import create_event

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, create_mock_credentials())
        
        async def execute_insert(func, *args, **kwargs):
            return {"id": "evt789", "htmlLink": "http://calendar/evt789"}
        
        mock_to_thread.side_effect = execute_insert

        result = await create_event.fn(
            user_google_email="test@example.com",
            summary="Zoom Meeting",
            start_time="2025-01-20T10:00:00Z",
            end_time="2025-01-20T11:00:00Z",
            zoom_link="https://zoom.us/j/1234567890"
        )

        assert "Successfully created" in result
