"""
Unit tests for the visibility parameter in create_event and modify_event.

Tests:
- visibility parameter validation (using actual production function)
- Valid values are accepted
- Invalid values trigger warnings
- Event body construction with visibility
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gcalendar.calendar_tools import _apply_visibility_if_valid


# Valid visibility values (should match production code)
VALID_VISIBILITY_VALUES = ["default", "public", "private", "confidential"]


class TestVisibilityValidation:
    """Tests for visibility parameter validation logic."""

    def test_valid_visibility_values(self):
        """Test that valid visibility values are accepted."""
        for value in VALID_VISIBILITY_VALUES:
            event_body = {}
            _apply_visibility_if_valid(event_body, value, "test")
            assert event_body.get("visibility") == value

    def test_invalid_visibility_value(self):
        """Test that invalid visibility value is not applied."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "hidden", "test")
        assert "visibility" not in event_body

    def test_visibility_private(self):
        """Test the 'private' value is applied."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "private", "test")
        assert event_body["visibility"] == "private"

    def test_visibility_public(self):
        """Test the 'public' value is applied."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "public", "test")
        assert event_body["visibility"] == "public"

    def test_visibility_default(self):
        """Test the 'default' value is applied."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "default", "test")
        assert event_body["visibility"] == "default"

    def test_visibility_confidential(self):
        """Test the 'confidential' value is applied."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "confidential", "test")
        assert event_body["visibility"] == "confidential"


class TestVisibilityApplyValidation:
    """Tests for visibility validation helper logic using actual production function."""

    def test_validate_private_returns_true(self):
        """Test validation applies 'private' correctly."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "private", "test")
        assert event_body.get("visibility") == "private"

    def test_validate_public_returns_true(self):
        """Test validation applies 'public' correctly."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "public", "test")
        assert event_body.get("visibility") == "public"

    def test_validate_default_returns_true(self):
        """Test validation applies 'default' correctly."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "default", "test")
        assert event_body.get("visibility") == "default"

    def test_validate_confidential_returns_true(self):
        """Test validation applies 'confidential' correctly."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "confidential", "test")
        assert event_body.get("visibility") == "confidential"

    def test_validate_invalid_returns_false(self):
        """Test validation does not apply invalid values."""
        event_body = {}
        _apply_visibility_if_valid(event_body, "invalid", "test")
        assert "visibility" not in event_body
        
        event_body = {}
        _apply_visibility_if_valid(event_body, "PRIVATE", "test")  # Case sensitive
        assert "visibility" not in event_body
        
        event_body = {}
        _apply_visibility_if_valid(event_body, "", "test")
        assert "visibility" not in event_body


class TestVisibilityEventBodyConstruction:
    """Tests for visibility in event body construction."""

    def test_visibility_in_event_body(self):
        """Test that visibility is correctly set in event body."""
        visibility = "private"
        
        event_body = {
            "summary": "Test Event",
            "start": {"dateTime": "2025-01-15T10:00:00Z"},
            "end": {"dateTime": "2025-01-15T11:00:00Z"},
        }
        
        # Apply visibility
        event_body["visibility"] = visibility
        
        assert event_body["visibility"] == "private"

    def test_visibility_none_not_set(self):
        """Test that visibility=None does not set the field."""
        visibility = None
        
        event_body = {
            "summary": "Test Event",
            "start": {"dateTime": "2025-01-15T10:00:00Z"},
            "end": {"dateTime": "2025-01-15T11:00:00Z"},
        }
        
        # Only set if not None
        if visibility is not None:
            event_body["visibility"] = visibility
        
        assert "visibility" not in event_body

    def test_visibility_public_in_event_body(self):
        """Test that visibility='public' is correctly set."""
        event_body = {"summary": "Test Event"}
        event_body["visibility"] = "public"
        
        assert event_body["visibility"] == "public"


class TestVisibilityApplyIfValid:
    """Tests for _apply_visibility_if_valid helper logic using actual production function."""

    def test_apply_valid_visibility_private(self):
        """Test that valid 'private' value is applied."""
        event_body = {"summary": "Test"}
        _apply_visibility_if_valid(event_body, "private", "test")
        
        assert event_body["visibility"] == "private"

    def test_apply_valid_visibility_public(self):
        """Test that valid 'public' value is applied."""
        event_body = {"summary": "Test"}
        _apply_visibility_if_valid(event_body, "public", "test")
        
        assert event_body["visibility"] == "public"

    def test_apply_none_visibility(self):
        """Test that None visibility is not applied."""
        event_body = {"summary": "Test"}
        _apply_visibility_if_valid(event_body, None, "test")
        
        assert "visibility" not in event_body

    def test_apply_invalid_visibility_logs_warning(self):
        """Test that invalid visibility is not applied (logs warning internally)."""
        event_body = {"summary": "Test"}
        _apply_visibility_if_valid(event_body, "invalid_value", "test")
        
        assert "visibility" not in event_body


class TestVisibilityPreservation:
    """Tests for preserving existing visibility during modify_event."""

    def test_preserve_existing_visibility_when_none(self):
        """Test that existing visibility is preserved when new is None."""
        existing_event = {
            "id": "test_id",
            "summary": "Existing Event",
            "visibility": "private",
        }
        new_visibility = None
        
        # Logic: if new visibility is None, preserve existing
        preserved_visibility = (
            new_visibility if new_visibility is not None else existing_event.get("visibility")
        )
        
        assert preserved_visibility == "private"

    def test_override_visibility_when_provided(self):
        """Test that visibility is overridden when new value is provided."""
        existing_event = {
            "id": "test_id",
            "summary": "Existing Event",
            "visibility": "private",
        }
        new_visibility = "public"
        
        # Logic: if new visibility is provided, use it
        final_visibility = (
            new_visibility if new_visibility is not None else existing_event.get("visibility")
        )
        
        assert final_visibility == "public"

    def test_preserve_no_visibility_when_none(self):
        """Test that no visibility is set when existing has none and new is None."""
        existing_event = {
            "id": "test_id",
            "summary": "Existing Event",
            # No visibility field
        }
        new_visibility = None
        
        preserved_visibility = (
            new_visibility if new_visibility is not None else existing_event.get("visibility")
        )
        
        assert preserved_visibility is None
