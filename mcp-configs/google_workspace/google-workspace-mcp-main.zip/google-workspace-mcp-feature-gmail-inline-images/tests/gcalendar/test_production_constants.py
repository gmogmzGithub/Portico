"""
Unit tests for production constants and mappings in calendar tools.

These tests verify that production constants have expected values,
ensuring API compatibility. The actual async tool functions are
tested in test_calendar_tools_async.py.
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gcalendar.calendar_tools import VALID_AUTO_DECLINE_MODES, RESPONSE_STATUS_MAP


class TestValidAutoDeclineModes:
    """Tests for VALID_AUTO_DECLINE_MODES production constant.
    
    Used by create_out_of_office and create_focus_time tools.
    """

    def test_decline_none_mode_exists(self):
        """Test declineNone mode is valid."""
        assert "declineNone" in VALID_AUTO_DECLINE_MODES

    def test_decline_all_mode_exists(self):
        """Test declineAllConflictingInvitations mode is valid."""
        assert "declineAllConflictingInvitations" in VALID_AUTO_DECLINE_MODES

    def test_decline_new_only_mode_exists(self):
        """Test declineOnlyNewConflictingInvitations mode is valid."""
        assert "declineOnlyNewConflictingInvitations" in VALID_AUTO_DECLINE_MODES

    def test_has_exactly_three_modes(self):
        """Test there are exactly 3 valid modes."""
        assert len(VALID_AUTO_DECLINE_MODES) == 3

    def test_invalid_mode_not_accepted(self):
        """Test that invalid modes are not in the list."""
        assert "declineAll" not in VALID_AUTO_DECLINE_MODES
        assert "decline" not in VALID_AUTO_DECLINE_MODES


class TestResponseStatusMap:
    """Tests for RESPONSE_STATUS_MAP production constant.
    
    Used by respond_to_event tool to map user-friendly responses
    to Google Calendar API status values.
    """

    def test_accept_maps_to_accepted(self):
        """Test 'accept' maps to 'accepted'."""
        assert RESPONSE_STATUS_MAP["accept"] == "accepted"

    def test_decline_maps_to_declined(self):
        """Test 'decline' maps to 'declined'."""
        assert RESPONSE_STATUS_MAP["decline"] == "declined"

    def test_tentative_maps_to_tentative(self):
        """Test 'tentative' maps to 'tentative'."""
        assert RESPONSE_STATUS_MAP["tentative"] == "tentative"

    def test_has_exactly_three_mappings(self):
        """Test there are exactly 3 response mappings."""
        assert len(RESPONSE_STATUS_MAP) == 3

    def test_invalid_response_not_mapped(self):
        """Test invalid responses are not in the mapping."""
        assert "maybe" not in RESPONSE_STATUS_MAP
        assert "yes" not in RESPONSE_STATUS_MAP
        assert "no" not in RESPONSE_STATUS_MAP

