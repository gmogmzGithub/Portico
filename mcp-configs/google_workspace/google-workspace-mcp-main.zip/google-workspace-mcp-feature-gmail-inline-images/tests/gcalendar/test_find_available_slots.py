"""
Unit tests for the find_available_slots tool.

Tests:
- Interval merging algorithm (using actual production function)
- Working hours filtering
- Duration requirements
- Output formatting
- Timezone-aware working hours
"""

import datetime
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gcalendar.calendar_tools import _merge_busy_intervals, _find_free_slots_in_day


class TestIntervalMerging:
    """Tests for busy interval merging algorithm using actual production function."""

    def _to_datetime_tuples(self, intervals: list) -> list:
        """Convert string time tuples to datetime tuples for testing."""
        base_date = datetime.datetime(2025, 1, 15, tzinfo=datetime.timezone.utc)
        result = []
        for start, end in intervals:
            start_h, start_m = map(int, start.split(":"))
            end_h, end_m = map(int, end.split(":"))
            start_dt = base_date.replace(hour=start_h, minute=start_m)
            end_dt = base_date.replace(hour=end_h, minute=end_m)
            result.append((start_dt, end_dt))
        return result

    def _from_datetime_tuples(self, intervals: list) -> list:
        """Convert datetime tuples back to string time tuples for assertions."""
        return [(dt[0].strftime("%H:%M"), dt[1].strftime("%H:%M")) for dt in intervals]

    def test_merge_non_overlapping(self):
        """Test merging non-overlapping intervals."""
        intervals = self._to_datetime_tuples([
            ("09:00", "10:00"),
            ("14:00", "15:00"),
        ])
        
        result = _merge_busy_intervals(intervals)
        result_str = self._from_datetime_tuples(result)
        
        assert len(result) == 2
        assert result_str[0] == ("09:00", "10:00")
        assert result_str[1] == ("14:00", "15:00")

    def test_merge_overlapping(self):
        """Test merging overlapping intervals."""
        intervals = self._to_datetime_tuples([
            ("09:00", "10:30"),
            ("10:00", "11:00"),
        ])
        
        result = _merge_busy_intervals(intervals)
        result_str = self._from_datetime_tuples(result)
        
        assert len(result) == 1
        assert result_str[0] == ("09:00", "11:00")

    def test_merge_adjacent(self):
        """Test merging adjacent intervals."""
        intervals = self._to_datetime_tuples([
            ("09:00", "10:00"),
            ("10:00", "11:00"),
        ])
        
        result = _merge_busy_intervals(intervals)
        result_str = self._from_datetime_tuples(result)
        
        assert len(result) == 1
        assert result_str[0] == ("09:00", "11:00")

    def test_merge_empty(self):
        """Test merging empty list."""
        result = _merge_busy_intervals([])
        assert result == []

    def test_merge_contained(self):
        """Test interval contained within another."""
        intervals = self._to_datetime_tuples([
            ("09:00", "12:00"),
            ("10:00", "11:00"),
        ])
        
        result = _merge_busy_intervals(intervals)
        result_str = self._from_datetime_tuples(result)
        
        assert len(result) == 1
        assert result_str[0] == ("09:00", "12:00")


class TestWorkingHoursFiltering:
    """Tests for working hours filtering."""

    def _is_within_working_hours(
        self, time: str, working_start: str = "09:00", working_end: str = "17:00"
    ) -> bool:
        """Check if a time is within working hours."""
        return working_start <= time <= working_end

    def test_time_within_working_hours(self):
        """Test time within working hours."""
        assert self._is_within_working_hours("10:00") is True
        assert self._is_within_working_hours("16:30") is True

    def test_time_before_working_hours(self):
        """Test time before working hours."""
        assert self._is_within_working_hours("08:00") is False
        assert self._is_within_working_hours("07:30") is False

    def test_time_after_working_hours(self):
        """Test time after working hours."""
        assert self._is_within_working_hours("18:00") is False
        assert self._is_within_working_hours("20:00") is False

    def test_boundary_times(self):
        """Test boundary times (start and end of working hours)."""
        assert self._is_within_working_hours("09:00") is True
        assert self._is_within_working_hours("17:00") is True


class TestDurationFiltering:
    """Tests for filtering by minimum duration."""

    def _slot_meets_duration(
        self, start_minutes: int, end_minutes: int, required_minutes: int
    ) -> bool:
        """Check if slot meets minimum duration requirement."""
        return (end_minutes - start_minutes) >= required_minutes

    def test_slot_meets_duration(self):
        """Test slot that meets duration requirement."""
        # 9:00 to 10:00 = 60 minutes, need 30
        assert self._slot_meets_duration(540, 600, 30) is True

    def test_slot_exact_duration(self):
        """Test slot with exact duration."""
        # 60 minutes slot, need 60
        assert self._slot_meets_duration(540, 600, 60) is True

    def test_slot_too_short(self):
        """Test slot that's too short."""
        # 15 minutes slot, need 30
        assert self._slot_meets_duration(540, 555, 30) is False


class TestFreeSlotCalculation:
    """Tests for calculating free slots from busy intervals."""

    def _find_free_slots(
        self, 
        busy_intervals: list, 
        day_start: int, 
        day_end: int,
        min_duration: int = 30
    ) -> list:
        """Find free slots by inverting busy intervals."""
        if not busy_intervals:
            return [(day_start, day_end)]
        
        free_slots = []
        current_time = day_start
        
        for busy_start, busy_end in sorted(busy_intervals):
            if current_time < busy_start:
                slot_duration = busy_start - current_time
                if slot_duration >= min_duration:
                    free_slots.append((current_time, busy_start))
            current_time = max(current_time, busy_end)
        
        # Check for free time after last busy period
        if current_time < day_end:
            slot_duration = day_end - current_time
            if slot_duration >= min_duration:
                free_slots.append((current_time, day_end))
        
        return free_slots

    def test_find_free_slots_with_busy(self):
        """Test finding free slots with busy periods."""
        # Day: 9am (540) to 5pm (1020)
        # Busy: 10am-11am (600-660)
        busy = [(600, 660)]
        
        free = self._find_free_slots(busy, 540, 1020, 30)
        
        assert len(free) == 2
        assert free[0] == (540, 600)  # 9-10
        assert free[1] == (660, 1020)  # 11-5pm

    def test_find_free_slots_no_busy(self):
        """Test finding free slots with no busy periods."""
        free = self._find_free_slots([], 540, 1020, 30)
        
        assert len(free) == 1
        assert free[0] == (540, 1020)

    def test_find_free_slots_all_busy(self):
        """Test when entire day is busy."""
        busy = [(540, 1020)]
        
        free = self._find_free_slots(busy, 540, 1020, 30)
        
        assert len(free) == 0


class TestMaxResultsLimit:
    """Tests for max_results limiting."""

    def test_limit_results(self):
        """Test limiting results to max_results."""
        slots = [
            ("09:00", "09:30"),
            ("10:00", "10:30"),
            ("11:00", "11:30"),
            ("14:00", "14:30"),
            ("15:00", "15:30"),
        ]
        max_results = 3
        
        limited = slots[:max_results]
        
        assert len(limited) == 3
        assert limited[0] == ("09:00", "09:30")

    def test_limit_with_fewer_results(self):
        """Test limiting when fewer results than max."""
        slots = [("09:00", "09:30"), ("10:00", "10:30")]
        max_results = 5
        
        limited = slots[:max_results]
        
        assert len(limited) == 2


class TestOutputFormatting:
    """Tests for output formatting."""

    def test_format_single_slot(self):
        """Test formatting a single available slot."""
        slot = {
            "date": "Wed Dec 18",
            "start": "11:00 AM",
            "end": "11:30 AM",
        }
        
        formatted = f"1. {slot['date']}, {slot['start']} - {slot['end']}"
        
        assert "Wed Dec 18" in formatted
        assert "11:00 AM" in formatted
        assert "11:30 AM" in formatted

    def test_format_no_slots(self):
        """Test message when no slots available."""
        slots = []
        
        if not slots:
            message = "No available slots found that meet the requirements."
        else:
            message = "Found slots"
        
        assert "No available slots" in message


class TestFindFreeSlotsInDayProduction:
    """Tests for _find_free_slots_in_day using actual production function with datetimes."""

    def test_find_free_slots_basic(self):
        """Test finding free slots with simple busy interval."""
        # Setup: 9am-5pm day, Busy 12pm-1pm
        day_start = datetime.datetime(2025, 1, 15, 9, 0, 0)
        day_end = datetime.datetime(2025, 1, 15, 17, 0, 0)
        
        busy = [
            (
                datetime.datetime(2025, 1, 15, 12, 0, 0),
                datetime.datetime(2025, 1, 15, 13, 0, 0)
            )
        ]

        slots = _find_free_slots_in_day(
            busy_intervals=busy,
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=False,  # Disable to test core logic first
            working_start="09:00",
            working_end="17:00"
        )

        assert len(slots) == 2
        # Slot 1: 9am - 12pm
        assert slots[0][0] == day_start
        assert slots[0][1] == busy[0][0]
        # Slot 2: 1pm - 5pm
        assert slots[1][0] == busy[0][1]
        assert slots[1][1] == day_end

    def test_find_free_slots_working_hours(self):
        """Test working hours filtering."""
        # Setup: Day is 00:00 - 23:59
        day_start = datetime.datetime(2025, 1, 15, 0, 0, 0)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59)
        
        # No busy intervals
        busy = []

        # Working hours 9-5
        slots = _find_free_slots_in_day(
            busy_intervals=busy,
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=60,
            working_hours_only=True,
            working_start="09:00",
            working_end="17:00"
        )

        assert len(slots) == 1
        # Should be exactly 9am to 5pm
        assert slots[0][0].hour == 9
        assert slots[0][0].minute == 0
        assert slots[0][1].hour == 17
        assert slots[0][1].minute == 0

    def test_find_free_slots_no_busy(self):
        """Test with no busy intervals - should return full day as free."""
        day_start = datetime.datetime(2025, 1, 15, 9, 0, 0)
        day_end = datetime.datetime(2025, 1, 15, 17, 0, 0)
        
        slots = _find_free_slots_in_day(
            busy_intervals=[],
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=False,
            working_start="09:00",
            working_end="17:00"
        )

        assert len(slots) == 1
        assert slots[0] == (day_start, day_end)

    def test_find_free_slots_all_busy(self):
        """Test when entire day is busy."""
        day_start = datetime.datetime(2025, 1, 15, 9, 0, 0)
        day_end = datetime.datetime(2025, 1, 15, 17, 0, 0)
        
        busy = [(day_start, day_end)]
        
        slots = _find_free_slots_in_day(
            busy_intervals=busy,
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=False,
            working_start="09:00",
            working_end="17:00"
        )

        assert len(slots) == 0

    def test_find_free_slots_min_duration_filter(self):
        """Test that slots shorter than min_duration are filtered out."""
        day_start = datetime.datetime(2025, 1, 15, 9, 0, 0)
        day_end = datetime.datetime(2025, 1, 15, 17, 0, 0)
        
        # Create busy intervals that leave only 15-minute gaps
        busy = [
            (datetime.datetime(2025, 1, 15, 9, 15, 0), datetime.datetime(2025, 1, 15, 10, 0, 0)),
            (datetime.datetime(2025, 1, 15, 10, 15, 0), datetime.datetime(2025, 1, 15, 17, 0, 0)),
        ]
        
        # Require 30 minutes - should filter out the 15-minute gaps
        slots = _find_free_slots_in_day(
            busy_intervals=busy,
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=False,
            working_start="09:00",
            working_end="17:00"
        )

        # Both gaps are 15 minutes, so no slots should match
        assert len(slots) == 0


class TestFindFreeSlotsTimezoneAware:
    """Tests for timezone-aware working hours in _find_free_slots_in_day."""

    def test_chicago_timezone_converts_working_hours_to_utc(self):
        """Test that working hours in America/Chicago are correctly converted to UTC.
        
        Chicago is UTC-6 in winter, so:
        - 9:00 AM Chicago = 15:00 UTC
        - 5:00 PM Chicago = 23:00 UTC
        """
        # Day boundaries in UTC (midnight to midnight)
        day_start = datetime.datetime(2025, 1, 15, 0, 0, 0, tzinfo=datetime.timezone.utc)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59, tzinfo=datetime.timezone.utc)
        
        slots = _find_free_slots_in_day(
            busy_intervals=[],
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=True,
            working_start="09:00",
            working_end="17:00",
            timezone="America/Chicago"
        )
        
        assert len(slots) == 1
        # Working hours should be 15:00-23:00 UTC (9am-5pm Chicago)
        assert slots[0][0].hour == 15  # 9 AM Chicago = 3 PM UTC
        assert slots[0][1].hour == 23  # 5 PM Chicago = 11 PM UTC

    def test_new_york_timezone_different_offset(self):
        """Test that America/New_York (UTC-5) works correctly.
        
        New York is UTC-5 in winter, so:
        - 9:00 AM New York = 14:00 UTC
        - 5:00 PM New York = 22:00 UTC
        """
        day_start = datetime.datetime(2025, 1, 15, 0, 0, 0, tzinfo=datetime.timezone.utc)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59, tzinfo=datetime.timezone.utc)
        
        slots = _find_free_slots_in_day(
            busy_intervals=[],
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=True,
            working_start="09:00",
            working_end="17:00",
            timezone="America/New_York"
        )
        
        assert len(slots) == 1
        # Working hours should be 14:00-22:00 UTC
        assert slots[0][0].hour == 14  # 9 AM NYC = 2 PM UTC
        assert slots[0][1].hour == 22  # 5 PM NYC = 10 PM UTC

    def test_utc_timezone_no_conversion(self):
        """Test that UTC timezone applies working hours directly."""
        day_start = datetime.datetime(2025, 1, 15, 0, 0, 0, tzinfo=datetime.timezone.utc)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59, tzinfo=datetime.timezone.utc)
        
        slots = _find_free_slots_in_day(
            busy_intervals=[],
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=True,
            working_start="09:00",
            working_end="17:00",
            timezone="UTC"
        )
        
        assert len(slots) == 1
        # Working hours should be 09:00-17:00 UTC
        assert slots[0][0].hour == 9
        assert slots[0][1].hour == 17

    def test_busy_intervals_respect_timezone_working_hours(self):
        """Test that busy intervals are correctly compared against timezone-aware working hours.
        
        Scenario: Chicago working hours 9am-5pm (15:00-23:00 UTC)
        Busy period: 16:00-17:00 UTC (10am-11am Chicago)
        Expected free slots: 15:00-16:00 UTC and 17:00-23:00 UTC
        
        Note: We use 12:00 UTC as day_start so that the Chicago date is the same
        (12:00 UTC = 6:00 AM Chicago on the same day).
        """
        # Use noon UTC to ensure we're on the same date in Chicago
        # 12:00 UTC = 6:00 AM Chicago on Jan 15
        day_start = datetime.datetime(2025, 1, 15, 12, 0, 0, tzinfo=datetime.timezone.utc)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59, tzinfo=datetime.timezone.utc)
        
        # Busy from 10-11 AM Chicago (16:00-17:00 UTC)
        busy = [
            (
                datetime.datetime(2025, 1, 15, 16, 0, 0, tzinfo=datetime.timezone.utc),
                datetime.datetime(2025, 1, 15, 17, 0, 0, tzinfo=datetime.timezone.utc)
            )
        ]
        
        slots = _find_free_slots_in_day(
            busy_intervals=busy,
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=True,
            working_start="09:00",
            working_end="17:00",
            timezone="America/Chicago"
        )
        
        assert len(slots) == 2
        # First slot: 15:00-16:00 UTC (9am-10am Chicago)
        assert slots[0][0].hour == 15
        assert slots[0][1].hour == 16
        # Second slot: 17:00-23:00 UTC (11am-5pm Chicago)
        assert slots[1][0].hour == 17
        assert slots[1][1].hour == 23

    def test_no_timezone_uses_legacy_behavior(self):
        """Test that omitting timezone parameter uses legacy UTC behavior."""
        day_start = datetime.datetime(2025, 1, 15, 0, 0, 0)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59)
        
        slots = _find_free_slots_in_day(
            busy_intervals=[],
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=True,
            working_start="09:00",
            working_end="17:00",
            timezone=None  # No timezone
        )
        
        assert len(slots) == 1
        # Working hours applied directly (legacy behavior)
        assert slots[0][0].hour == 9
        assert slots[0][1].hour == 17

    def test_london_timezone_during_winter(self):
        """Test Europe/London (UTC+0 in winter, same as UTC)."""
        day_start = datetime.datetime(2025, 1, 15, 0, 0, 0, tzinfo=datetime.timezone.utc)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59, tzinfo=datetime.timezone.utc)
        
        slots = _find_free_slots_in_day(
            busy_intervals=[],
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=True,
            working_start="09:00",
            working_end="17:00",
            timezone="Europe/London"
        )
        
        assert len(slots) == 1
        # London in winter is UTC+0, so hours should match
        assert slots[0][0].hour == 9
        assert slots[0][1].hour == 17

    def test_tokyo_timezone_positive_offset(self):
        """Test Asia/Tokyo (UTC+9) - working hours go to previous UTC day.
        
        Tokyo is UTC+9, so:
        - 9:00 AM Tokyo = 00:00 UTC (midnight)
        - 5:00 PM Tokyo = 08:00 UTC
        """
        day_start = datetime.datetime(2025, 1, 15, 0, 0, 0, tzinfo=datetime.timezone.utc)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59, tzinfo=datetime.timezone.utc)
        
        slots = _find_free_slots_in_day(
            busy_intervals=[],
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=True,
            working_start="09:00",
            working_end="17:00",
            timezone="Asia/Tokyo"
        )
        
        assert len(slots) == 1
        # Tokyo 9am-5pm = UTC 00:00-08:00
        assert slots[0][0].hour == 0
        assert slots[0][1].hour == 8

    def test_custom_working_hours_with_timezone(self):
        """Test custom working hours (e.g., 8am-4pm) with timezone."""
        day_start = datetime.datetime(2025, 1, 15, 0, 0, 0, tzinfo=datetime.timezone.utc)
        day_end = datetime.datetime(2025, 1, 15, 23, 59, 59, tzinfo=datetime.timezone.utc)
        
        slots = _find_free_slots_in_day(
            busy_intervals=[],
            day_start=day_start,
            day_end=day_end,
            min_duration_minutes=30,
            working_hours_only=True,
            working_start="08:00",  # 8 AM
            working_end="16:00",    # 4 PM
            timezone="America/Chicago"
        )
        
        assert len(slots) == 1
        # Chicago 8am-4pm = UTC 14:00-22:00 (UTC-6)
        assert slots[0][0].hour == 14
        assert slots[0][1].hour == 22

