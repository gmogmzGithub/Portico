"""
Unit tests for the send_updates parameter in create_event and modify_event.

Tests:
- send_updates parameter validation (using actual production function)
- Valid values are accepted
- Invalid values trigger warnings and return default
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gcalendar.calendar_tools import _validate_send_updates


# Valid send_updates values (should match production code)
VALID_SEND_UPDATES_VALUES = ["all", "externalOnly", "none"]


class TestSendUpdatesValidation:
    """Tests for send_updates parameter validation logic using actual production function."""

    def test_valid_send_updates_values(self):
        """Test that valid send_updates values are returned unchanged."""
        for value in VALID_SEND_UPDATES_VALUES:
            result = _validate_send_updates(value, "test")
            assert result == value

    def test_invalid_send_updates_value(self):
        """Test that invalid send_updates value returns default 'all'."""
        result = _validate_send_updates("invalid", "test")
        assert result == "all"

    def test_send_updates_none_value(self):
        """Test the 'none' value is validated correctly."""
        result = _validate_send_updates("none", "test")
        assert result == "none"

    def test_send_updates_external_only(self):
        """Test the 'externalOnly' value is validated correctly."""
        result = _validate_send_updates("externalOnly", "test")
        assert result == "externalOnly"

    def test_send_updates_all(self):
        """Test the 'all' value is validated correctly."""
        result = _validate_send_updates("all", "test")
        assert result == "all"


class TestSendUpdatesApplyValidation:
    """Tests for send_updates validation helper logic using actual production function."""

    def test_validate_all_returns_true(self):
        """Test validation returns 'all' for 'all' input."""
        result = _validate_send_updates("all", "test")
        assert result == "all"

    def test_validate_none_returns_true(self):
        """Test validation returns 'none' for 'none' input."""
        result = _validate_send_updates("none", "test")
        assert result == "none"

    def test_validate_external_only_returns_true(self):
        """Test validation returns 'externalOnly' for 'externalOnly' input."""
        result = _validate_send_updates("externalOnly", "test")
        assert result == "externalOnly"

    def test_validate_invalid_returns_false(self):
        """Test validation returns default 'all' for invalid values."""
        # Invalid value returns default "all"
        result = _validate_send_updates("invalid", "test")
        assert result == "all"
        
        # Case sensitive - "ALL" is invalid
        result = _validate_send_updates("ALL", "test")
        assert result == "all"
        
        # Empty string is invalid
        result = _validate_send_updates("", "test")
        assert result == "all"


class TestSendUpdatesApiRequestFormat:
    """Tests for send_updates API request format."""

    def test_send_updates_in_insert_params(self):
        """Test that send_updates is correctly formatted for insert API call."""
        send_updates = "none"
        
        # Build the params dict as the create_event function would
        params = {
            "calendarId": "primary",
            "body": {"summary": "Test Event"},
            "sendUpdates": send_updates,
        }
        
        assert params["sendUpdates"] == "none"

    def test_send_updates_in_update_params(self):
        """Test that send_updates is correctly formatted for update API call."""
        send_updates = "externalOnly"
        
        params = {
            "calendarId": "primary",
            "eventId": "test_event_id",
            "body": {"summary": "Updated Event"},
            "sendUpdates": send_updates,
        }
        
        assert params["sendUpdates"] == "externalOnly"

    def test_send_updates_default_value(self):
        """Test that default send_updates value is 'all'."""
        # The default should be "all" per Google's recommendation
        default_value = "all"
        
        assert default_value == "all"


class TestSendUpdatesConditionalLogic:
    """Tests for send_updates conditional application logic."""

    def _apply_send_updates(self, params: dict, send_updates: str) -> dict:
        """Helper to apply send_updates to params dict."""
        valid_values = ["all", "externalOnly", "none"]
        if send_updates in valid_values:
            params["sendUpdates"] = send_updates
        return params

    def test_apply_valid_value(self):
        """Test that valid values are applied to params."""
        params = {"calendarId": "primary"}
        result = self._apply_send_updates(params, "none")
        assert result["sendUpdates"] == "none"

    def test_apply_invalid_value_not_added(self):
        """Test that invalid values are not added to params."""
        params = {"calendarId": "primary"}
        result = self._apply_send_updates(params, "invalid")
        assert "sendUpdates" not in result
