"""Tests for OAuth configuration and dynamic port detection."""

import os
from unittest.mock import patch, MagicMock

from auth.oauth_config import (
    _detect_port_from_request,
    get_oauth_redirect_uri
)


class TestPortDetection:
    """Test dynamic port detection from Host header."""

    def test_detect_port_from_valid_host_header(self):
        """Should extract port from Host header with port."""
        with patch("fastmcp.server.dependencies.get_http_headers") as mock_get_headers:
            mock_get_headers.return_value = {"host": "localhost:64186"}

            port = _detect_port_from_request()
            assert port == 64186
            mock_get_headers.assert_called_with(include_all=True)

    def test_detect_port_from_ipv6_host_header(self):
        """Should extract port from IPv6 Host header."""
        with patch("fastmcp.server.dependencies.get_http_headers") as mock_get_headers:
            mock_get_headers.return_value = {"host": "[::1]:8080"}

            port = _detect_port_from_request()
            assert port == 8080

    def test_detect_port_from_ipv6_host_header_no_port(self):
        """Should return None for IPv6 Host header without port."""
        with patch("fastmcp.server.dependencies.get_http_headers") as mock_get_headers:
            mock_get_headers.return_value = {"host": "[::1]"}

            port = _detect_port_from_request()
            assert port is None

    def test_detect_port_from_host_header_no_port(self):
        """Should return None if Host header has no port."""
        with patch("fastmcp.server.dependencies.get_http_headers") as mock_get_headers:
            mock_get_headers.return_value = {"host": "localhost"}

            port = _detect_port_from_request()
            assert port is None

    def test_detect_port_empty_headers(self):
        """Should return None if headers dict is empty."""
        with patch("fastmcp.server.dependencies.get_http_headers") as mock_get_headers:
            mock_get_headers.return_value = {}

            port = _detect_port_from_request()
            assert port is None

    def test_detect_port_no_headers(self):
        """Should return None if no headers available (None returned)."""
        with patch("fastmcp.server.dependencies.get_http_headers") as mock_get_headers:
            mock_get_headers.return_value = None

            port = _detect_port_from_request()
            assert port is None

    def test_detect_port_exception(self):
        """Should return None if exception occurs (e.g. not in request context)."""
        with patch("fastmcp.server.dependencies.get_http_headers", side_effect=RuntimeError("Not in request")):

            port = _detect_port_from_request()
            assert port is None


class TestRedirectUri:
    """Test OAuth redirect URI generation."""

    def setup_method(self):
        """Reset environment variables."""
        self.original_redirect_uri = os.environ.get("GOOGLE_OAUTH_REDIRECT_URI")
        if "GOOGLE_OAUTH_REDIRECT_URI" in os.environ:
            del os.environ["GOOGLE_OAUTH_REDIRECT_URI"]

    def teardown_method(self):
        """Restore environment variables."""
        if self.original_redirect_uri:
            os.environ["GOOGLE_OAUTH_REDIRECT_URI"] = self.original_redirect_uri
        elif "GOOGLE_OAUTH_REDIRECT_URI" in os.environ:
            del os.environ["GOOGLE_OAUTH_REDIRECT_URI"]

    def test_explicit_env_var_takes_precedence(self):
        """Environment variable should override dynamic detection."""
        os.environ["GOOGLE_OAUTH_REDIRECT_URI"] = "https://custom.com/callback"

        with patch("auth.oauth_config._detect_port_from_request", return_value=9999), \
             patch("auth.oauth_config.get_oauth_config") as mock_config_getter:

            mock_config = MagicMock()
            mock_config.redirect_uri = "https://custom.com/callback"
            mock_config_getter.return_value = mock_config

            uri = get_oauth_redirect_uri()
            assert uri == "https://custom.com/callback"

    def test_dynamic_port_used_when_detected(self):
        """Detected port should be used if no env var set."""
        with patch("auth.oauth_config._detect_port_from_request", return_value=64186), \
             patch("auth.oauth_config.get_oauth_config") as mock_config_getter:

            mock_config = MagicMock()
            mock_config.base_uri = "http://localhost"
            mock_config_getter.return_value = mock_config

            uri = get_oauth_redirect_uri()
            assert uri == "http://localhost:64186/oauth2callback"

    def test_fallback_when_no_port_detected(self):
        """Should fall back to configured URI if no port detected."""
        with patch("auth.oauth_config._detect_port_from_request", return_value=None), \
             patch("auth.oauth_config.get_oauth_config") as mock_config_getter:

            mock_config = MagicMock()
            mock_config.redirect_uri = "http://localhost:18922/oauth2callback"
            mock_config_getter.return_value = mock_config

            uri = get_oauth_redirect_uri()
            assert uri == "http://localhost:18922/oauth2callback"
