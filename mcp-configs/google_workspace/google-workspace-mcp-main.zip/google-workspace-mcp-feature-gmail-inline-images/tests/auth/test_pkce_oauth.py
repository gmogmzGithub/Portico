"""Tests for PKCE OAuth code_verifier round-trip."""

from unittest.mock import MagicMock, patch

from auth.oauth21_session_store import OAuth21SessionStore
from auth.google_auth import create_oauth_flow


class TestPkceSessionStore:
    """The session store must persist and return the code_verifier."""

    def setup_method(self):
        self.store = OAuth21SessionStore()

    def test_store_and_retrieve_code_verifier(self):
        """code_verifier stored with state should be returned on validate."""
        self.store.store_oauth_state("mystate123", code_verifier="verifier_abc")
        state_info = self.store.validate_and_consume_oauth_state("mystate123")
        assert state_info["code_verifier"] == "verifier_abc"

    def test_state_without_code_verifier_has_no_key(self):
        """State stored without a verifier should not have the key at all."""
        self.store.store_oauth_state("mystate456")
        state_info = self.store.validate_and_consume_oauth_state("mystate456")
        assert "code_verifier" not in state_info

    def test_none_code_verifier_not_stored(self):
        """Explicitly passing None should behave the same as omitting it."""
        self.store.store_oauth_state("mystate789", code_verifier=None)
        state_info = self.store.validate_and_consume_oauth_state("mystate789")
        assert "code_verifier" not in state_info

    def test_code_verifier_consumed_with_state(self):
        """After validate_and_consume the state is gone; verifier can't be replayed."""
        self.store.store_oauth_state("onetime", code_verifier="once")
        self.store.validate_and_consume_oauth_state("onetime")
        import pytest
        with pytest.raises(ValueError):
            self.store.validate_and_consume_oauth_state("onetime")


class TestCreateOAuthFlowPkce:
    """create_oauth_flow must wire the code_verifier through to the Flow correctly."""

    def _make_env_config(self):
        return {
            "web": {
                "client_id": "test-client-id",
                "client_secret": "test-client-secret",
                "redirect_uris": ["http://localhost/callback"],
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
            }
        }

    def test_no_verifier_auto_generates(self):
        """Without a code_verifier, the Flow should auto-generate one (PKCE on by default)."""
        mock_flow = MagicMock()
        mock_flow.code_verifier = "auto_generated"

        with patch("auth.google_auth.load_client_secrets_from_env", return_value=self._make_env_config()), \
             patch("auth.google_auth.Flow.from_client_config", return_value=mock_flow) as mock_from_config:
            result = create_oauth_flow(
                scopes=["openid"],
                redirect_uri="http://localhost/callback",
            )

        _, kwargs = mock_from_config.call_args
        # autogenerate_code_verifier should NOT be False (let library decide)
        assert kwargs.get("autogenerate_code_verifier") is not False
        assert result is mock_flow

    def test_with_verifier_disables_autogenerate(self):
        """Providing a code_verifier must disable auto-generation and pass the exact value."""
        mock_flow = MagicMock()

        with patch("auth.google_auth.load_client_secrets_from_env", return_value=self._make_env_config()), \
             patch("auth.google_auth.Flow.from_client_config", return_value=mock_flow) as mock_from_config:
            create_oauth_flow(
                scopes=["openid"],
                redirect_uri="http://localhost/callback",
                code_verifier="exact_verifier_xyz",
            )

        _, kwargs = mock_from_config.call_args
        assert kwargs["code_verifier"] == "exact_verifier_xyz"
        assert kwargs["autogenerate_code_verifier"] is False

    def test_verifier_passed_through_on_callback_flow(self):
        """Simulates the callback path: verifier from store must reach the Flow."""
        mock_flow = MagicMock()
        stored_verifier = "stored_verifier_from_start_auth"

        with patch("auth.google_auth.load_client_secrets_from_env", return_value=self._make_env_config()), \
             patch("auth.google_auth.Flow.from_client_config", return_value=mock_flow) as mock_from_config:
            create_oauth_flow(
                scopes=["openid"],
                redirect_uri="http://localhost/callback",
                state="some_oauth_state",
                code_verifier=stored_verifier,
            )

        _, kwargs = mock_from_config.call_args
        assert kwargs["code_verifier"] == stored_verifier
        assert kwargs["autogenerate_code_verifier"] is False
