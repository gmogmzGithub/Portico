"""Tests for main.py port resolution logic.

Tests verify that the port resolution in main() follows the precedence:
FASTMCP_PORT > PORT > WORKSPACE_MCP_PORT > 8000
"""

import os
import socket
import unittest
from unittest.mock import MagicMock, patch


class TestMainPortResolution(unittest.TestCase):
    """Test port resolution in main.py."""

    def _run_main_with_env(self, env_vars, expected_port):
        """Run main() with specific env vars and verify port."""
        # Create a mock socket that doesn't actually bind
        mock_socket = MagicMock()
        mock_socket.__enter__ = MagicMock(return_value=mock_socket)
        mock_socket.__exit__ = MagicMock(return_value=False)

        with patch.dict(os.environ, env_vars, clear=True):
            with patch("logging.basicConfig"):
                with patch("core.log_formatter.configure_file_logging"):
                    with patch("auth.oauth_config.reload_oauth_config"):
                        with patch("main.load_dotenv"):
                            with patch("main.metadata.version", return_value="1.0.0"):
                                with patch(
                                    "main.check_credentials_directory_permissions"
                                ):
                                    with patch("main.configure_safe_logging"):
                                        with patch(
                                            "main.argparse.ArgumentParser.parse_args",
                                            return_value=MagicMock(
                                                single_user=False,
                                                tools=None,
                                                tool_tier=None,
                                                transport="streamable-http",
                                                optimizer=False,
                                            ),
                                        ):
                                            # Mock socket to prevent port-in-use errors
                                            with patch.object(
                                                socket,
                                                "socket",
                                                return_value=mock_socket,
                                            ):
                                                with patch(
                                                    "main.server.run"
                                                ) as mock_run:
                                                    from main import main

                                                    try:
                                                        main()
                                                    except SystemExit:
                                                        pass

                                                    mock_run.assert_called_with(
                                                        transport="streamable-http",
                                                        host="0.0.0.0",
                                                        port=expected_port,
                                                    )

    def test_fastmcp_port_takes_precedence(self):
        """FASTMCP_PORT (set by ToolHive) takes precedence over all others."""
        self._run_main_with_env(
            {"FASTMCP_PORT": "9001", "PORT": "8001", "WORKSPACE_MCP_PORT": "7001"},
            9001,
        )

    def test_port_takes_precedence_over_workspace(self):
        """PORT takes precedence over WORKSPACE_MCP_PORT."""
        self._run_main_with_env(
            {"PORT": "8002", "WORKSPACE_MCP_PORT": "7002"},
            8002,
        )

    def test_workspace_mcp_port_used_when_others_unset(self):
        """WORKSPACE_MCP_PORT is used if FASTMCP_PORT and PORT are unset."""
        self._run_main_with_env(
            {"WORKSPACE_MCP_PORT": "7003"},
            7003,
        )

    def test_default_port_8000(self):
        """Default port 8000 is used when no port env vars are set."""
        self._run_main_with_env({}, 8000)


if __name__ == "__main__":
    unittest.main()
