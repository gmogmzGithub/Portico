"""
Unit tests for copy_drive_file tool.

Tests the copy_drive_file function in gdrive/drive_tools.py.
"""

import pytest
from unittest.mock import MagicMock, patch


class TestCopyDriveFile:
    """Tests for copy_drive_file tool execution."""

    @pytest.mark.asyncio
    @patch("gdrive.drive_tools.asyncio.to_thread")
    @patch("gdrive.drive_tools.resolve_drive_item")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_copy_file_basic(
        self, mock_get_service, mock_resolve_item, mock_to_thread
    ):
        """Test basic file copy with default name."""
        from gdrive.drive_tools import copy_drive_file

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        # Mock resolve_drive_item helper
        mock_resolve_item.return_value = (
            "original_file_id",
            {
                "id": "original_file_id",
                "name": "Original Document",
                "mimeType": "application/vnd.google-apps.presentation",
            },
        )

        # The copy result dict
        copy_result = {
            "id": "new_file_id",
            "name": "Copy of Original Document",
            "webViewLink": "https://docs.google.com/presentation/d/new_file_id/edit",
            "mimeType": "application/vnd.google-apps.presentation",
        }

        async def execute_sync(func, *args, **kwargs):
            # The function passed to to_thread is the execute method
            return copy_result

        mock_to_thread.side_effect = execute_sync

        result = await copy_drive_file.fn(
            user_google_email="test@example.com",
            file_id="original_file_id",
        )

        # Check for success message (actual format uses emoji)
        assert "Successfully copied file" in result
        assert "new_file_id" in result

    @pytest.mark.asyncio
    @patch("gdrive.drive_tools.asyncio.to_thread")
    @patch("gdrive.drive_tools.resolve_drive_item")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_copy_file_with_custom_name(
        self, mock_get_service, mock_resolve_item, mock_to_thread
    ):
        """Test file copy with custom name."""
        from gdrive.drive_tools import copy_drive_file

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        mock_resolve_item.return_value = (
            "template_id",
            {
                "id": "template_id",
                "name": "Template Presentation",
                "mimeType": "application/vnd.google-apps.presentation",
            },
        )

        copy_result = {
            "id": "new_pres_id",
            "name": "Q1 2025 Report",
            "webViewLink": "https://docs.google.com/presentation/d/new_pres_id/edit",
            "mimeType": "application/vnd.google-apps.presentation",
        }

        async def execute_sync(func, *args, **kwargs):
            return copy_result

        mock_to_thread.side_effect = execute_sync

        result = await copy_drive_file.fn(
            user_google_email="test@example.com",
            file_id="template_id",
            name="Q1 2025 Report",
        )

        assert "Successfully copied file" in result
        assert "Q1 2025 Report" in result

    @pytest.mark.asyncio
    @patch("gdrive.drive_tools.asyncio.to_thread")
    @patch("gdrive.drive_tools.resolve_folder_id")
    @patch("gdrive.drive_tools.resolve_drive_item")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_copy_file_to_folder(
        self, mock_get_service, mock_resolve_item, mock_resolve_folder, mock_to_thread
    ):
        """Test file copy to specific folder."""
        from gdrive.drive_tools import copy_drive_file

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        mock_resolve_item.return_value = (
            "doc_id",
            {
                "id": "doc_id",
                "name": "Document",
                "mimeType": "application/vnd.google-apps.document",
            },
        )
        mock_resolve_folder.return_value = "resolved_folder_id"

        copy_result = {
            "id": "copied_doc_id",
            "name": "Document Copy",
            "webViewLink": "https://docs.google.com/document/d/copied_doc_id/edit",
            "mimeType": "application/vnd.google-apps.document",
        }

        async def execute_sync(func, *args, **kwargs):
            return copy_result

        mock_to_thread.side_effect = execute_sync

        result = await copy_drive_file.fn(
            user_google_email="test@example.com",
            file_id="doc_id",
            name="Document Copy",
            folder_id="target_folder_id",
        )

        assert "Successfully copied file" in result
        assert "copied_doc_id" in result


class TestCopyDriveFileLinkGeneration:
    """Tests for generating correct links after copy."""

    def test_slides_link_format(self):
        """Test Slides link format."""
        file_id = "new_slides_id"
        link = f"https://docs.google.com/presentation/d/{file_id}/edit"
        assert "presentation" in link
        assert file_id in link

    def test_docs_link_format(self):
        """Test Docs link format."""
        file_id = "new_doc_id"
        link = f"https://docs.google.com/document/d/{file_id}/edit"
        assert "document" in link
        assert file_id in link

    def test_sheets_link_format(self):
        """Test Sheets link format."""
        file_id = "new_sheet_id"
        link = f"https://docs.google.com/spreadsheets/d/{file_id}/edit"
        assert "spreadsheets" in link
        assert file_id in link
