# Complex Markdown Formatting Test Document

This document exercises **various markdown features** to test the `insert_markdown` tool's handling of *complex formatting scenarios*.

---

## 1. Nested Lists & Mixed Types

### Unordered with Nested Ordered

- First top-level item
  1. Numbered sub-item one
  2. Numbered sub-item two
     - Deeply nested bullet
     - Another nested bullet
  3. Back to numbered
- Second top-level item
  - Simple nested bullet
  - Another bullet
    1. Now numbered again
    2. With continuation

### Ordered with Nested Unordered

1. **Step One**: Initialize the system
   - Verify prerequisites
   - Check configuration files
   - Validate credentials
2. **Step Two**: Execute the migration
   - Run backup first
   - Apply schema changes
     1. Create new tables
     2. Migrate data
     3. Verify integrity
3. **Step Three**: Validate results

---

## 2. Code Blocks in Multiple Languages

### Python Example

```python
from dataclasses import dataclass
from typing import Optional, List

@dataclass
class Document:
    """Represents a Google Doc with metadata."""
    id: str
    title: str
    content: Optional[str] = None
    tabs: List[str] = None
    
    def __post_init__(self):
        if self.tabs is None:
            self.tabs = []
    
    async def fetch_content(self, service) -> str:
        """Fetch document content from Google API."""
        result = await service.documents().get(
            documentId=self.id,
            fields="body/content"
        ).execute()
        self.content = result.get("body", {}).get("content", "")
        return self.content
```

### TypeScript Example

```typescript
interface TableCell {
  content: string;
  rowSpan?: number;
  colSpan?: number;
  formatting?: {
    bold?: boolean;
    italic?: boolean;
    backgroundColor?: string;
  };
}

async function insertTable(
  docId: string,
  rows: TableCell[][],
  position: 'start' | 'end' | number
): Promise<void> {
  const requests = rows.map((row, rowIndex) => ({
    insertTableRow: {
      tableCellLocation: { rowIndex },
      insertBelow: false,
    },
  }));
  
  await docsApi.documents.batchUpdate({
    documentId: docId,
    requestBody: { requests },
  });
}
```

### Shell Commands

```bash
#!/bin/bash

# Deploy script for production
set -euo pipefail

echo "Starting deployment..."
uv sync --frozen
uv run python -m pytest tests/ -v
uv run python main.py --env production

# Verify health
curl -f http://localhost:8080/health || exit 1
echo "Deployment complete!"
```

---

## 3. Complex Tables

### Table with Links and Formatting

| Feature | Status | Documentation | Owner |
|---------|:------:|---------------|-------|
| OAuth2 Flow | ✅ Complete | [Auth Guide](https://docs.example.com/auth) | @auth-team |
| Multi-tab Docs | ⚠️ Beta | [Tab Support](https://docs.example.com/tabs) | @docs-team |
| Batch Operations | ✅ Complete | [Batch API](https://docs.example.com/batch) | @core-team |
| Undo/Redo | 🔄 In Progress | *Coming Soon* | @ux-team |
| Real-time Collab | ❌ Not Started | — | TBD |

### Performance Metrics Table

| Metric | Baseline | Current | Δ Change | Target |
|--------|----------|---------|----------|--------|
| Avg Response Time | 450ms | 120ms | **-73%** | <150ms |
| P99 Latency | 2.3s | 890ms | **-61%** | <1s |
| Error Rate | 2.1% | 0.3% | **-86%** | <0.5% |
| Throughput | 100 req/s | 500 req/s | **+400%** | >400 req/s |

---

## 4. Blockquotes & Callouts

> **Note**: This is an important notice that spans multiple lines.
> It contains *italic text* and `inline code` to test
> how nested formatting within blockquotes is handled.

> **Warning**: Be careful when using batch operations!
>
> - Always use `preview=True` first
> - Verify the document structure
> - Consider using transactions

### Nested Blockquotes

> Level one blockquote
>
> > Level two blockquote with **bold** text
> >
> > > Level three - this is getting deep!
> >
> > Back to level two
>
> Back to level one

---

## 5. Inline Formatting Combinations

This paragraph tests **bold text**, *italic text*, and ***bold italic*** together. We also have `inline code`, ~~strikethrough text~~, and combinations like **`bold code`** or *`italic code`*.

Here's a sentence with a [link to Google](https://www.google.com), followed by more text and another [link with **bold text** inside](https://example.com).

Special characters: `<html>`, `{json: "value"}`, `$variable`, `@annotation`, `#hashtag`.

---

## 6. Definition-Style Content

**API Endpoint**
:   `POST /api/v1/documents/{id}/batch`

**Rate Limit**
:   1000 requests per minute per user

**Authentication**
:   OAuth2 Bearer token required (scopes: `docs.read`, `docs.write`)

---

## 7. Task Lists

### Sprint Checklist

- [x] Complete OAuth integration
- [x] Add multi-tab support
- [ ] Implement batch undo
- [ ] Add collaborative editing
- [x] Write unit tests
  - [x] Test happy path
  - [ ] Test error scenarios
  - [ ] Test edge cases
- [ ] Update documentation

---

## 8. Mathematical Expressions (as text)

The quadratic formula is: x = (-b ± √(b² - 4ac)) / 2a

For complexity analysis: O(n log n) is better than O(n²) for large inputs.

Memory usage formula: `total_memory = base_size + (n × element_size) + overhead`

---

## 9. Horizontal Rules & Separators

Above this line.

---

Between sections.

***

Using asterisks.

___

Using underscores.

Below the last rule.

---

## 10. Complex Mixed Content

### API Response Example

When calling the `get_document` endpoint, you'll receive:

| Field | Type | Description |
|-------|------|-------------|
| `documentId` | string | Unique identifier |
| `title` | string | Document title |
| `tabs` | array | List of tab objects |

**Sample Response:**

```json
{
  "documentId": "1abc2def3ghi",
  "title": "My Document",
  "tabs": [
    {
      "tabId": "t.0",
      "title": "Main",
      "content": {
        "elements": [...]
      }
    }
  ],
  "revisionId": "ALm37BX...",
  "suggestionsViewMode": "PREVIEW_WITHOUT_SUGGESTIONS"
}
```

> **Tip**: Use the `fields` parameter to limit the response:
> ```
> GET /documents/{id}?fields=documentId,title,tabs(tabId,title)
> ```

### Error Handling

1. **400 Bad Request**
   - Invalid document ID format
   - Malformed request body
   ```json
   {"error": {"code": 400, "message": "Invalid documentId"}}
   ```

2. **403 Forbidden**
   - Missing required scopes
   - User lacks document access
   
3. **404 Not Found**
   - Document deleted or never existed
   - Check your `documentId` parameter

---

## Appendix: Special Characters & Edge Cases

| Character | Escaped | Context |
|-----------|---------|---------|
| `|` | `\|` | Inside tables |
| `*` | `\*` | When not formatting |
| `_` | `\_` | Preventing italics |
| `` ` `` | ``` `` ` `` ``` | Nested backticks |
| `#` | `\#` | Start of line |
| `[` `]` | `\[` `\]` | Not a link |

End of document.




