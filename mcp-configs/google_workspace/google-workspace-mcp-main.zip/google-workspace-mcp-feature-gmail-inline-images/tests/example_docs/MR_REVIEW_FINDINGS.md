# MR Rework Analysis: Coding Guidelines from Code Review Feedback

## Executive Summary

We analyzed ~27,000 code review comments from GitLab merge requests over a 30-day period (November-December 2024) and distilled them into **281 actionable coding guidelines**. These guidelines capture recurring patterns of feedback that can be automated, documented, or addressed through training.

**Key Statistics:**
- **281** guidelines extracted from **27,634** review comments
- **5,473** unique MRs analyzed
- **5,122** MRs with JIRA tickets (93.6%)
- **400+** unique JIRA projects represented
- **~180** unique repositories contributing source data
- **8,909** intermediate rules before deduplication (96.8% reduction)
- **~$60** total LLM API cost (across 7-day pilot + two 30-day runs)

**By Priority (computed from occurrence frequency, breadth, and domain impact):**
| Tier | Guidelines | Coverage | Avg Score |
|------|------------|----------|-----------|
| Critical | 36 | 12.8% | 88.5 |
| High | 97 | 34.5% | 62.0 |
| Medium | 126 | 44.8% | 48.1 |
| Low | 22 | 7.8% | 25.5 |

**By Domain (Top 10):**
| Domain | Guidelines | Avg Priority |
|--------|------------|--------------|
| Testing | 30 | 89.1 (Critical) |
| Security | 10 | 74.0 (High) |
| Error Handling | 21 | 66.9 (High) |
| Configuration | 30 | 62.1 (High) |
| Architecture | 30 | 51.3 (Medium) |
| API Usage | 30 | 51.0 (Medium) |
| Documentation | 28 | 49.8 (Medium) |
| Component Usage | 28 | 48.7 (Medium) |
| Performance | 18 | 52.9 (Medium) |
| Naming Convention | 17 | 48.6 (Medium) |

**By SDLC Phase (guidelines tagged for multiple phases):**
| Phase | Guidelines | Coverage |
|-------|------------|----------|
| Implementation | 237 | 84.3% |
| Review | 167 | 59.4% |
| Design | 98 | 34.9% |
| Deployment | 76 | 27.0% |
| Testing | 61 | 21.7% |
| Planning | 29 | 10.3% |

**By Ecosystem:**
| Ecosystem | Guidelines | Coverage |
|-----------|------------|----------|
| General | 202 | 71.9% |
| Testing | 30 | 10.7% |
| DevOps | 20 | 7.1% |
| Frontend | 20 | 7.1% |
| Backend | 6 | 2.1% |
| Database | 3 | 1.1% |

**By JIRA Project (Top 25 of 400+):**
| Project | MRs | | Project | MRs |
|---------|-----|---|---------|-----|
| EMPSCOUT | 131 | | WAGYU | 47 |
| PTE | 83 | | STAIR | 45 |
| NEX | 82 | | RNHP | 44 |
| ELPB | 78 | | POW | 43 |
| JOBPOSTING | 67 | | PROFEXP | 43 |
| TPSET | 65 | | FMBL | 43 |
| DROID | 64 | | EVO | 38 |
| AIAGENTOPS | 63 | | SPONMODS | 38 |
| OFFCAP | 63 | | FE | 37 |
| IAFE | 60 | | JOBOPT | 36 |
| IOS | 58 | | JPMATCHCAP | 34 |
| JPFE | 57 | | IASUB | 34 |
| EMPOFF | 51 | | | |

---

## The Guidelines

### Backend (11 guidelines)

- **[architecture]** Implement atomic operations and proper synchronization when handling concurrent processing or shared state to prevent race conditions.
- **[api_usage]** Design APIs for backward compatibility by making new parameters optional, maintaining existing contracts, and coordinating breaking changes with consumers.
- **[api_usage]** Implement comprehensive input validation at API boundaries with clear error messages, failing fast when preconditions are not met.
- **[api_usage]** Choose appropriate HTTP methods and status codes that clearly communicate the operation's intent and distinguish between different error conditions.
- **[api_usage]** Design batch operations for collections of data rather than requiring multiple individual API calls for related items.
- **[api_usage]** Include only necessary data in requests and responses, querying specific fields rather than entire objects when only subsets are needed.
- **[api_usage]** Design APIs to return complete, structured data with necessary metadata rather than minimal identifiers that require additional context or calls.
- **[error_handling]** Implement defensive programming for external dependencies with timeouts, retry limits, circuit breakers, and fallback mechanisms to prevent cascading failures.
- **[performance]** Design for scalability by implementing pagination, rate limiting, and capacity management to handle growing datasets and traffic volumes gracefully.
- **[performance]** Design with resource limits and rate limiting in mind, implementing backoff strategies and preventing resource exhaustion.
- **[performance]** Choose appropriate protocols and request methods based on the operation requirements to minimize unnecessary data transfer.

### Database (5 guidelines)

- **[architecture]** Design database schemas and data models to reflect business reality using appropriate constraints, relationships, and hierarchical structures.
- **[performance]** Optimize data access patterns by minimizing network requests, using efficient query structures, and avoiding N+1 problems through batching or eager loading strategies.
- **[performance]** Optimize database queries by using appropriate indexes, avoiding unnecessary joins, and structuring queries to match actual data patterns and access requirements.
- **[performance]** Optimize database queries by applying filters early, using appropriate indexes, and minimizing data retrieval through projection and joins.
- **[other]** When joining or querying data, use explicit join conditions, include necessary columns in SELECT statements, and handle null values appropriately with defaults.

### DevOps (27 guidelines)

- **[architecture]** Implement comprehensive monitoring, logging, and health checks for business-critical operations to enable proper observability and debugging.
- **[architecture]** Implement staged rollouts and parallel execution for significant changes, validating correctness before fully transitioning from old to new systems.
- **[architecture]** Coordinate breaking changes and major upgrades across dependent systems, considering downstream impact and timing constraints to minimize disruption.
- **[configuration]** Define configuration values once in centralized, authoritative sources and reference them consistently throughout the system to eliminate duplication and ensure consistency.
- **[configuration]** Externalize configuration from code using environment variables, configuration files, or dependency injection rather than embedding values in source code.
- **[configuration]** Validate configuration dependencies, resource existence, and compatibility at startup rather than discovering issues at runtime.
- **[configuration]** Establish sensible, conservative defaults that require explicit override for more permissive or aggressive behavior.
- **[configuration]** Maintain clear separation between environments, concerns, and sensitivity levels to prevent cross-contamination and security issues.
- **[configuration]** Size and scope configuration appropriately for the target environment and use case, avoiding over-provisioning in non-production and under-provisioning in production.
- **[configuration]** Design configuration for resilience with appropriate timeouts, retry policies, fallback mechanisms, and graceful degradation when dependencies are unavailable.
- **[configuration]** Implement feature flags and toggles defensively with opt-in behavior, consistent evaluation logic, and gradual rollout capabilities.
- **[configuration]** Maintain backward compatibility during configuration migrations by supporting both old and new formats temporarily before removing deprecated options.
- **[configuration]** Remove unused configuration, deprecated settings, and obsolete resources rather than leaving them dormant to reduce complexity and prevent confusion.
- **[configuration]** Ensure all related components and downstream systems are updated consistently when making configuration changes.
- **[configuration]** Pin dependencies to specific versions and document external resource requirements to prevent unexpected changes and ensure reproducible deployments.
- **[configuration]** Configure monitoring, alerting, and observability with appropriate thresholds and coverage aligned to service criticality and business impact.
- **[configuration]** Use team-based and role-based identifiers instead of individual-specific ones to ensure continuity and proper access management.
- **[configuration]** Design configuration changes to minimize disruption by preferring in-place updates over destructive operations and implementing gradual deployment strategies.
- **[configuration]** Test configuration changes in lower environments first and validate them thoroughly before applying to production systems.
- **[configuration]** Align configuration structure with system architecture to reflect actual relationships, data flows, and operational requirements.
- **[configuration]** Use dynamic, context-aware configuration that adapts to different environments and conditions rather than static hardcoded values.
- **[configuration]** Validate configuration format, syntax, and structural requirements before deployment to prevent runtime errors and ensure compliance.
- **[configuration]** Document configuration sources, purposes, change procedures, and relationships to support maintenance, troubleshooting, and knowledge transfer.
- **[configuration]** Exclude generated files and environment-specific configurations from version control while including templates and examples for reference.
- **[error_handling]** Ensure comprehensive error visibility through structured logging, monitoring, and alerting that supports debugging and system health assessment without exposing sensitive implementation details.
- **[performance]** Implement monitoring and metrics efficiently by avoiding duplicate measurements and focusing on meaningful performance indicators.
- **[logging]** Choose between logs and metrics based on purpose - use logs for debugging context and detailed information, metrics for monitoring and alerting on quantitative data.

### Frontend (17 guidelines)

- **[documentation]** Document accessibility considerations, compliance requirements, and user impact assessments for features affecting specific user groups or regulatory requirements.
- **[component_usage]** Leverage existing libraries, frameworks, and design system components before creating custom implementations. When custom solutions are needed, follow established patterns and architectural conventions.
- **[component_usage]** Use semantic markup, proper component types, and meaningful naming that conveys purpose and structure to both humans and automated systems.
- **[component_usage]** Design components to be accessible by default, including proper focus management, keyboard navigation, screen reader support, and adherence to accessibility standards.
- **[component_usage]** Maintain single sources of truth and ensure state consistency across components, avoiding redundant state variables and keeping UI state synchronized with actual data.
- **[component_usage]** Handle edge cases, error states, and loading conditions gracefully with appropriate fallbacks, user feedback, and recovery mechanisms.
- **[component_usage]** Implement proper lifecycle management with appropriate resource cleanup, dependency tracking, and prevention of memory leaks or race conditions.
- **[component_usage]** Preserve user input and selections during interactions, only resetting or overriding values when explicitly intended or when context fundamentally changes.
- **[component_usage]** Design component APIs to be self-sufficient with sensible defaults and automatic fallbacks, reducing the burden on consumers while maintaining flexibility.
- **[component_usage]** Use configurable, theme-aware design tokens and responsive patterns instead of hardcoded values, ensuring consistency across different contexts and screen sizes.
- **[component_usage]** Implement proper localization and cultural awareness from the start, including appropriate language display, regional formatting, and timezone handling.
- **[component_usage]** Maintain behavioral consistency and feature parity across similar components and interactions, ensuring users have predictable experiences throughout the application.
- **[performance]** Reduce bundle sizes and exclude unnecessary code from production builds using conditional imports and environment-specific configurations.
- **[other]** Implement proper internationalization by using translation functions for all user-facing text, considering locale-specific formatting, and reusing existing translations when semantically equivalent.
- **[other]** Ensure accessibility compliance by adding proper keyboard navigation, ARIA labels, and semantic markup for interactive elements that aren't native buttons or links.
- **[other]** Handle internationalization by using parameterized message templates and avoiding string concatenation or hardcoded text assumptions.
- **[other]** Use semantic units and values that match the design intent and accessibility requirements rather than arbitrary or legacy values.

### Testing (18 guidelines)

- **[testing]** Test the complete user journey and all meaningful scenarios, including edge cases, error conditions, and boundary values, not just happy path functionality.
- **[testing]** Use realistic, deterministic test data from fixtures or constants rather than dynamic, synthetic, or hardcoded values that may cause flakiness or inconsistency.
- **[testing]** Assert on specific expected outcomes and final states rather than implementation details, method calls, or overly broad patterns.
- **[testing]** Each test should verify one distinct scenario or behavior with a clear, descriptive name that matches what is actually being tested.
- **[testing]** Use appropriate testing tools and selectors for the context - semantic selectors for UI tests, built-in framework methods over custom implementations, and realistic user interactions.
- **[testing]** Maintain test independence by using proper setup, cleanup, and avoiding dependencies on external state or other tests.
- **[testing]** Remove obsolete test code, unused fixtures, and redundant test cases to keep the test suite maintainable and focused.
- **[testing]** Test data transformations and integrations by verifying complete data structures and field mappings, not just the presence of data.
- **[testing]** Handle timing and asynchronous behavior explicitly with appropriate waits, delays, or state verification rather than assuming immediate completion.
- **[testing]** Protect sensitive information in test artifacts by masking or removing personal data, credentials, and confidential content from snapshots and test outputs.
- **[testing]** Validate test changes locally before submission by running the full test suite and manually verifying fixes address the specific issues they claim to resolve.
- **[testing]** Structure test files with reusable constants, clear organization, and appropriate abstraction to reduce duplication and improve readability.
- **[testing]** When testing components with multiple states or configurations, ensure test coverage includes all relevant combinations and state transitions.
- **[testing]** Add corresponding tests when implementing new features or fixing bugs to prevent regression and ensure the changes work as intended.
- **[testing]** Design tests to be resilient to implementation changes by focusing on behavior and outcomes rather than internal structure or temporary states.
- **[testing]** Design tests to be resilient by using deterministic configurations, avoiding brittle exact matches on variable content, and implementing proper mocking strategies that align with existing infrastructure.
- **[testing]** Maintain comprehensive test coverage by ensuring new code paths are tested, coordinating test updates with code changes, and evaluating coverage gaps when migrating between system layers.
- **[testing]** Apply proportional effort in testing by focusing on meaningful scenarios that occur in production, testing custom logic rather than framework defaults, and distinguishing between temporary issues and permanent failures in retry logic.

### General (174 guidelines)

#### Architecture (25 guidelines)

- Design components with single, well-defined responsibilities and avoid mixing unrelated operations within the same unit.
- Eliminate code duplication by extracting shared logic into reusable abstractions and consolidating identical implementations.
- Use dependency injection and composition over direct instantiation to improve testability, flexibility, and maintainability.
- Place functionality at the appropriate architectural layer and maintain clear boundaries between different system concerns.
- Design for current requirements rather than hypothetical future needs, implementing only the minimum functionality necessary to solve the immediate problem.
- Maintain consistent patterns, interfaces, and naming conventions across similar components and related functionality.
- Remove unused, obsolete, and duplicate code promptly to maintain a clean and maintainable codebase.
- Use strongly-typed constants, enums, or union types instead of string literals or magic values to improve maintainability and catch errors at compile time.
- Design data structures and interfaces for backward compatibility using versioning strategies, optional fields, and migration paths.
- Establish a single source of truth for data and business logic, computing derived values from source data rather than maintaining duplicate information.
- Handle errors and edge cases at the appropriate system layer, implementing proper error propagation and graceful degradation patterns.
- Design for extensibility by using configurable approaches, parameterized workflows, and abstractions that can accommodate future requirements without structural changes.
- Validate data consistency across all storage and processing layers, performing validation at appropriate boundaries rather than relying on incomplete checks.
- Pass specific required parameters to functions rather than entire objects, and use member fields directly when available instead of requiring redundant parameters.
- Use appropriate data structures and storage solutions based on actual usage patterns and access requirements rather than default choices.
- Implement proper state management patterns using appropriate mechanisms for different types of state while avoiding unnecessary complexity.
- Check for existing implementations and established patterns before creating new solutions, reusing proven approaches when they meet current needs.
- Design clear control flow using positive logic, early returns, and guard clauses while avoiding multiple exit points and complex nested conditions.
- Organize code by functional responsibility rather than feature domains, grouping related operations and maintaining consistent architectural patterns.
- Design hierarchical systems with clear precedence rules and avoid conflicting logic that could lead to inconsistent states.
- Preserve audit trails and maintain immutable records of important user actions and system state changes throughout operations.
- Apply transformations and enhancements at the earliest appropriate point in the processing pipeline so all downstream consumers benefit automatically.
- Match automation complexity to actual workflow needs, avoiding over-engineering simple processes while ensuring proper validation and control mechanisms exist.
- Use deterministic, event-driven solutions over time-based or probabilistic approaches to ensure reliable and predictable system behavior.
- Verify actual usage and business requirements before implementing technical solutions to ensure features serve genuine needs and data will be consumed.

#### API Usage (15 guidelines)

- Use strongly-typed parameters, return values, and data structures with explicit contracts rather than generic types that require runtime validation or casting.
- Leverage built-in language features, standard library methods, and framework utilities instead of implementing custom logic for common operations.
- Handle null, empty, and optional values consistently using language-appropriate patterns like Optional types, safe navigation, or well-defined defaults.
- Use precise data operations and comparison methods that preserve important characteristics like order, type precision, and semantic meaning.
- Handle asynchronous operations and timing dependencies explicitly using appropriate coordination mechanisms rather than assumptions about execution order.
- Choose data structures and collection types based on their specific capabilities and intended usage patterns rather than defaulting to generic types.
- Maintain consistency across related API methods, data structures, and naming patterns to reduce cognitive load and enable code reuse.
- Preserve user context and application state appropriately, avoiding automatic resets unless explicitly managing that state transition.
- Use the most specific appropriate method or operation for the intended scope rather than general-purpose alternatives that require additional logic.
- Implement proper error handling patterns appropriate to your technology stack, ensuring errors propagate correctly through supported channels.
- Design for the actual use case requirements rather than theoretical flexibility, using singular parameters for single-actor workflows.
- Separate business logic from presentation concerns using computed properties, service layers, and appropriate architectural boundaries.
- Handle edge cases and error states explicitly with clear documentation of behavior rather than relying on default framework behavior.
- Validate assumptions about data flow and system dependencies before implementation, ensuring edge cases can actually occur in the runtime environment.

#### Configuration (1 guideline)

- Use explicit, named constants and descriptive identifiers instead of magic values, hardcoded strings, or implicit behaviors that obscure intent.

#### Documentation (17 guidelines)

- Maintain strict synchronization between documentation and implementation, updating both simultaneously when making changes to prevent divergence.
- Document the reasoning and business context behind decisions, not just the implementation mechanics, focusing on why choices were made.
- Clearly identify and track temporary code, workarounds, and incomplete implementations with explicit timelines and removal conditions.
- Provide essential external context including references, dependencies, compliance requirements, and integration details necessary for understanding and maintenance.
- Document configuration values, constraints, behavioral assumptions, and non-obvious system requirements explicitly with their rationale.
- Eliminate redundant, obvious, or outdated information while keeping documentation concise and focused on value-adding content.
- Maintain consistent formatting, grammar, terminology, and structural patterns across all documentation and code comments.
- Thoroughly document complex logic, edge cases, conditional behaviors, and non-standard implementations with clear explanations of necessity and impact.
- Provide complete setup instructions, operational procedures, and troubleshooting information to enable reproducible environments and effective maintenance.
- Define technical terms, acronyms, and domain-specific concepts on first use, maintaining consistent terminology throughout the codebase.
- Document complete API contracts, data structures, and interface specifications including all parameters, return formats, and behavioral characteristics.
- Explain system interactions, component relationships, workflow transitions, and process boundaries to clarify how parts work together.
- Establish and maintain single sources of truth for documentation, consolidating related information and referencing canonical sources rather than duplicating content.
- Structure documentation logically with overview information accessible first, followed by progressively detailed implementation specifics organized by audience needs.
- Ensure all examples, code snippets, and demonstrations are syntactically correct, complete, and accurately represent proper usage patterns.
- Write documentation appropriate for the intended audience, balancing accessibility with technical accuracy and avoiding unnecessary complexity while maintaining precision.

#### Component Usage (4 guidelines)

- Use strongly-typed data structures, named constants, and appropriate validation rather than inline literals or loosely-typed primitives.
- Ensure data type consistency and semantic correctness throughout the application flow, converting types at appropriate boundaries rather than passing mismatched data between functions.
- Choose tools, components, and methods based on their semantic appropriateness and intended purpose for the specific context, rather than convenience or visual similarity alone.
- Remove unused code, redundant elements, and unnecessary abstraction layers that don't serve a functional purpose or provide clear value.

#### Naming Convention (10 guidelines)

- Use descriptive names that clearly communicate purpose, behavior, and semantic meaning rather than implementation details or generic terms.
- Maintain consistent naming conventions and patterns throughout the codebase, following established standards for the language, framework, and domain.
- Include necessary context, qualifiers, and scope information in names to prevent ambiguity and distinguish between similar concepts.
- Ensure names accurately reflect the actual data type, state range, and operational behavior rather than just a subset or specific implementation.
- Define named constants, enums, or type aliases for literal values and complex types to improve maintainability and prevent errors.
- Use positive, clear boolean semantics with appropriate prefixes that make conditional logic read naturally and avoid confusion.
- Choose future-proof names that avoid temporal references, technology-specific terms, and context that may become obsolete over time.
- Include units, measurements, and data characteristics in names when they are essential for correct usage and understanding.
- Align names with domain terminology and business concepts rather than UI elements or secondary implementation concerns.
- Balance conciseness with clarity by removing unnecessary verbosity while preserving all essential meaning and avoiding ambiguity.

#### Error Handling (8 guidelines)

- Fail fast and explicitly when preconditions are not met, invalid inputs are detected, or critical dependencies are unavailable, rather than masking problems with default values or silent handling.
- Provide meaningful error context that includes relevant identifiers, operation details, and root cause information while maintaining consistent error formats across similar operations.
- Use specific error types and structured responses that enable consumers to distinguish between different failure categories and apply appropriate handling strategies.
- Handle partial failures gracefully by processing successful items individually and clearly reporting failures, rather than terminating entire batch operations on first error.
- Handle errors at the appropriate architectural level, avoiding duplicate logging while ensuring proper separation between monitoring, user notification, and recovery actions.
- Distinguish between recoverable and non-recoverable errors, applying different strategies such as automatic retry for transient failures versus immediate escalation for permanent failures.
- Validate all forms of empty or invalid data explicitly, including null values, empty collections, boundary conditions, and malformed inputs before processing.
- Handle asynchronous operations and state management safely by ensuring proper cleanup, avoiding race conditions in error handlers, and maintaining system integrity during concurrent failures.

#### Performance (22 guidelines)

- Avoid redundant or duplicate operations by checking for existing state, cached results, or previously completed work before performing expensive computations or API calls.
- Reuse expensive resources like compiled objects, client connections, and utility instances across multiple operations rather than recreating them repeatedly.
- Implement caching strategically for expensive computations and frequently accessed data, but avoid caching when recalculation costs are minimal or data changes frequently.
- Use concurrent processing for independent operations while ensuring proper resource management and avoiding unnecessary parallelization overhead for lightweight tasks.
- Structure conditional logic to exit early from expensive operations when conditions make further processing unnecessary or impossible.
- Scope expensive operations like monitoring, logging, and validation to only run when necessary rather than applying them globally to all execution paths.
- Optimize memory usage by avoiding unnecessary data structures, removing unused fields from result sets, and preventing memory leaks through proper resource cleanup.
- Choose appropriate data structures and algorithms based on access patterns, avoiding collection transformations when direct operations can achieve the same result more efficiently.
- Minimize object creation overhead by reusing existing objects, avoiding unnecessary string formatting, and preferring primitive operations when object creation isn't required.
- Implement proper timing and ordering in asynchronous operations to avoid race conditions and ensure dependent operations complete before triggering related side effects.
- Balance optimization complexity against actual performance needs, avoiding over-engineering solutions when simpler approaches adequately meet current requirements.
- Monitor and measure performance impact of changes, especially for high-volume operations, and configure appropriate thresholds based on operation complexity rather than using universal limits.
- Batch operations to reduce network calls and database round trips. Process multiple items together instead of making individual calls in loops.
- Cache frequently accessed data and reuse computed results. Implement appropriate cache invalidation strategies for dynamic data.
- Load and process data incrementally using pagination, streaming, or chunking to prevent memory issues with large datasets.
- Minimize unnecessary object creation, type conversions, and redundant operations. Reuse existing instances and avoid duplicate work.
- Perform expensive operations only when necessary by adding early validation, conditional checks, and avoiding work for unused results.
- Implement proper dependency management in reactive systems to prevent unnecessary re-computation and updates.
- Use efficient data structures and algorithms appropriate for the problem size and access patterns.
- Implement concurrency controls and thread safety mechanisms when sharing resources across multiple execution contexts.
- Structure code to minimize the computational cost of frequently executed paths by pre-computing values and avoiding repeated calculations.

#### Logging (27 guidelines)

- Choose log levels based on production value and frequency - use DEBUG for verbose/frequent operations, INFO for important operational events, WARN for recoverable issues, and ERROR only for failures that prevent normal operation.
- Log actual state and meaningful changes rather than deltas, placeholders, or redundant information to ensure logs accurately represent system reality.
- Include sufficient context in logs to enable effective debugging, including relevant identifiers, operation outcomes, and environmental factors without exposing sensitive information.
- Implement consistent logging patterns across similar operations and components to enable reliable monitoring and troubleshooting workflows.
- Log exceptional conditions, state changes, and user actions while avoiding duplicate logging of the same event from multiple code paths.
- Use structured logging and avoid high-cardinality values in log tags to ensure logs remain searchable and don't exceed system limits or budgets.
- Perform data normalization and formatting within logging methods rather than relying on callers to prepare data correctly.
- Log batch operation results comprehensively, including success counts, skip counts, and failure details to provide visibility into processing efficiency and status.
- Include error handling and logging in exception scenarios to capture debugging information without exposing stack traces in application logs.
- Log system integration events, configuration changes, and external service interactions to support troubleshooting and operational monitoring.
- Use appropriate logging frameworks and centralize logging functionality rather than mixing different approaches or using console output in production code.
- Validate that debug logs appear in production monitoring systems before downgrading log levels, and ensure log messages are concise yet informative.
- Track user interactions and feature usage through logging when needed for analytics, but only log when meaningful actions occur and conditions are fully met.
- Plan for log cleanup and avoid technical debt by using temporary logging methods for debugging, documenting rationale for removed logs, and creating cleanup tickets.
- Use appropriate log levels based on the operational impact and frequency of events. Reserve error levels for actual failures, warn for concerning but non-critical conditions, info for important operational events, and debug for detailed troubleshooting information.
- Include relevant contextual identifiers and operational metadata in log messages to enable effective debugging and tracing. Always provide enough context to understand what operation failed and why.
- Use structured logging mechanisms and consistent formatting patterns throughout the codebase. Prefer parameterized logging over string concatenation and ensure log schemas are consistent for indexing.
- Log at key decision points, conditional branches, and state transitions to enable debugging of business logic flows. Focus on points where the system behavior changes based on data or conditions.
- Implement selective logging for high-volume events and avoid logging non-critical operations that could overwhelm monitoring systems. Consider sampling rates and log retention policies.
- Protect sensitive information by avoiding logging of personally identifiable information, credentials, or other confidential data. Log only the minimum necessary information for debugging.
- Use established logging patterns and frameworks consistently across the codebase. Prefer team-standard loggers over ad-hoc logging solutions and follow existing conventions.
- Log user interactions and system events that provide business value for analytics and monitoring. Ensure tracking events capture meaningful user behavior and system performance metrics.
- Handle edge cases and error conditions with appropriate logging that aids in diagnosis without creating noise. Log unexpected conditions but avoid excessive logging for known, handled exceptions.
- Time-sensitive operations should log with current timestamps and avoid pre-calculated or cached time values. Ensure timing data accurately reflects when events actually occurred.
- Remove temporary debug logs and clean up development logging before production deployment. Maintain production log quality by removing noise and unnecessary debug statements.
- Distinguish between different types of failures and system states in logging to enable accurate monitoring and alerting. Avoid conflating different conditions under generic log messages.
- Coordinate logging with monitoring and alerting systems to avoid duplicate alerts and ensure appropriate follow-up actions. Consider how logs will be consumed by downstream systems.

#### Security (18 guidelines)

- Apply the principle of least privilege by granting only the minimum access rights necessary for a function to operate correctly.
- Never expose sensitive data such as credentials, API keys, tokens, or personally identifiable information in logs, configuration files, or client-side code.
- Validate and sanitize all user inputs and parameters to prevent injection attacks and ensure data integrity before processing or storage.
- Implement proper authentication and authorization checks for all protected resources, ensuring tokens are validated and permissions match the required privilege level.
- Use secure communication protocols and ensure all external communications are encrypted and properly configured.
- Implement comprehensive error handling that provides useful information for debugging while avoiding exposure of internal system details to unauthorized users.
- Establish and enforce proper separation between environments, ensuring production security measures are not weakened by development or testing requirements.
- Implement rate limiting and abuse prevention mechanisms to protect against malicious actors and resource exhaustion attacks.
- Follow secure configuration practices by hardcoding security-critical values when appropriate and avoiding exposure of internal system details.
- Implement proper session and token management including expiration, rotation, and secure cleanup mechanisms.
- Design systems with defense in depth by implementing multiple layers of security controls and fallback mechanisms.
- Maintain security context awareness by considering data sensitivity, user privileges, and operational context when implementing security measures.
- Preserve existing security controls when refactoring or modifying code, ensuring no security regressions are introduced.
- Implement proper data lifecycle management including secure deletion, retention policies, and compliance with privacy regulations.
- Apply security controls consistently across similar operations and maintain clear documentation of security decisions and requirements.
- Never embed sensitive data directly in source code, configuration files, or version control systems. Always use secure external storage mechanisms designed for secrets management.
- Apply the principle of least privilege by granting only the minimum permissions, access rights, or capabilities necessary for the specific operation or user role.
- Validate and sanitize all user-controlled input to prevent injection attacks and security bypasses, especially when the input affects system behavior like redirects, queries, or commands.

#### Imports (3 guidelines)

- Import explicitly and specifically - use direct imports for individual symbols rather than wildcard imports, namespace imports, or importing entire libraries when only specific functionality is needed.
- Maintain import hygiene by placing imports at file top, removing unused imports, avoiding duplicates, and ensuring all dependencies are properly declared in dependency management files.
- Use consistent import conventions and current standards - establish project-wide patterns for import paths, prefer named exports over default exports, use current non-deprecated import sources, and import from designated canonical sources rather than implementation files.

#### Other (24 guidelines)

- Define and use named constants for literal values, magic numbers, and repeated strings to improve maintainability and prevent errors from typos or inconsistent values.
- Ensure type consistency between definitions and usage throughout the codebase, avoiding unnecessary type casting and investigating root causes of type mismatches.
- Use explicit boolean expressions and proper comparison operators, avoiding complex nested conditions when simple direct expressions achieve the same result.
- Remove unused code, debug statements, and unreachable branches before committing to maintain clean, production-ready code.
- Prefer explicit, readable code structure over clever shortcuts, using early returns to reduce nesting and choosing clear variable names over abbreviated ones.
- Follow consistent formatting conventions including proper indentation, statement terminators, file endings, and spacing to maintain uniform code style across the project.
- Validate data inputs by checking for null/undefined values, trimming whitespace, and ensuring data exists before processing rather than assuming default values.
- When modifying collections during iteration or applying constraints to objects, work with copies or apply constraints after modifications to prevent unintended side effects.
- Use appropriate comparison logic (case-sensitive vs case-insensitive, AND vs OR) based on business requirements, and document the reasoning for the chosen approach.
- Handle edge cases and boundary conditions properly, including date calculations, array bounds, percentage displays, and range validations.
- Keep changes focused and cohesive by grouping related modifications together while avoiding unrelated changes in the same commit or merge request.
- Verify business requirements and obtain stakeholder approval before implementing features that may impact user experience or data representation, especially for sensitive information like salary ranges.
- Remove unused code, redundant logic, and dead code paths during development rather than leaving them in the codebase.
- Use explicit type declarations and direct value assignments instead of relying on inference, coercion, or complex indirection when clarity is important.
- Structure conditional logic for readability by using early returns, combining related conditions, and breaking complex expressions into well-named variables.
- Maintain consistent formatting and spacing conventions throughout the codebase, including proper indentation, line breaks, and whitespace usage.
- Choose appropriate data types that match the semantic meaning and usage patterns of the data being represented.
- Implement proper error handling and edge case management, especially for boundary conditions and null/empty states.
- Limit change scope to the specific ticket requirements and coordinate with team members when modifying shared components or actively developed code.
- Follow established business rules and domain requirements precisely, verifying boundary conditions and legal constraints before implementation.
- Maintain data consistency by updating all related fields together and using appropriate default values for missing or null data.
- Choose simple, direct approaches over complex solutions when the simpler method achieves the same result with better readability.
- Ensure proper review process completion by not resolving reviewer comments until issues are confirmed addressed and keeping changes up-to-date with the latest codebase.

#### Logic (2 guidelines)

- When modifying conditional logic, verify that all edge cases and boundary conditions handled by the original logic are preserved or explicitly addressed in the new implementation.
- Ensure all execution paths through conditional logic produce the expected output state, with no path accidentally returning intermediate, unprocessed, or incorrectly transformed data.

#### Syntax (1 guideline)

- Use language features as intended without adding redundant syntax that duplicates the feature's built-in behavior.

#### Algorithm (1 guideline)

- When making selections from multiple options, use explicit criteria-based evaluation rather than arbitrary ordering or convenience-based choices.

---

## Suggested Actions

### Immediate

1. **Create lint rules for high-confidence patterns**
   - Security rules should be enforced via static analysis
   - API usage rules like "no Stream.peek()" can be caught by linters
   - TypeScript "as any" usage can trigger warnings

2. **Add to team coding guidelines**
   - Architecture decision records for common patterns
   - Security checklist for code reviews

3. **Prioritize testing documentation**
   - 18 testing guidelines warrant dedicated testing standards
   - Create testing workshop materials from extracted patterns

### Medium-Term

4. **Build AI code review assistant**
   - Use guidelines as training data for automated review
   - Focus on high-confidence, general guidelines

5. **Integrate with development workflow**
   - Add guidelines to global AGENTS.md for AI coding tools
   - Create pre-commit hooks for high-priority patterns
   - Build IDE extensions for real-time feedback

### Long-Term

6. **Track improvement over time**
   - Re-run analysis quarterly
   - Measure reduction in repeated feedback

7. **Share across organization**
   - Publish sanitized guidelines to broader engineering org
   - Contribute to shared linting configurations

---

## Statistics

### The Pipeline Funnel

| Stage | Description | Count | Result |
|-------|-------------|-------|--------|
| 1 | All MRs in 30-day window | ~5,500 | 100% |
| 2 | All reviewer comments | 27,634 | - |
| 3 | Actionable comments (after bot filtering) | 8,659 | 31% |
| 4 | LLM-extracted rules | 5,229 | 60% yield |
| 5 | Combined with prior batch | 11,571 | - |
| 6 | After semantic dedup | 8,909 | 77% |
| 7 | After specificity filter | 7,985 | 90% |
| 8 | After generalization | 281 | 3.5% |

### Guidelines by Domain

| Domain | Count | % of Total |
|--------|-------|------------|
| architecture | 30 | 10.7% |
| configuration | 30 | 10.7% |
| api_usage | 30 | 10.7% |
| testing | 30 | 10.7% |
| documentation | 28 | 10.0% |
| component_usage | 28 | 10.0% |
| error_handling | 21 | 7.5% |
| performance | 18 | 6.4% |
| naming_convention | 17 | 6.0% |
| logging | 15 | 5.3% |
| other | 15 | 5.3% |
| security | 10 | 3.6% |
| imports | 4 | 1.4% |
| logic | 2 | 0.7% |
| syntax/algorithm/data_quality | 3 | 1.1% |

### Priority Distribution

| Tier | Count | Score Range |
|------|-------|-------------|
| Critical | 36 | 80-100 |
| High | 97 | 60-79 |
| Medium | 126 | 40-59 |
| Low | 22 | 0-39 |

*Note: Priority scoring is based on comment volume by category, confidence level, and ecosystem applicability. Testing guidelines dominate the critical tier due to high comment volume in the missing_tests category (1,667 comments, 7.9% of actionable feedback).*

---

## Pipeline Details

The analysis followed a multi-stage funnel approach, progressively filtering and enriching data to extract actionable insights.

### Stage 1: Initial Data Collection

We queried GitLab's API across the team's repositories to identify merge requests from a 30-day window. This initial scan covered over 7,300 MRs spanning multiple repositories and contributors.

### Stage 2: Filtering for Rework Signals

We filtered to focus on MRs showing evidence of rework - specifically those with multiple revision cycles where reviewers requested changes. This isolated approximately 1,800 MRs (~25%) where meaningful code review feedback occurred.

### Stage 3: Comment Extraction

From filtered MRs, we extracted all reviewer comments along with their associated context:
- The diff/code snippet being commented on
- The file and line location
- The author and timestamp
- Whether the comment was resolved and how

### Stage 4: Actionable Comment Identification

Many review comments are clarifying questions, approvals, or context-specific discussions. We retained only actionable comments - those that explicitly requested changes, identified issues, or provided corrective guidance.

### Stage 5: LLM-Powered Categorization

Each actionable comment was processed through an LLM pipeline that:
- Categorized the comment into primary categories
- Determined whether the feedback contained a generalizable rule vs. a one-off fix
- Extracted the rule statement when applicable
- Assigned a domain classification
- Rated confidence level for generalizability

### Stage 6: Batch Processing and Initial Deduplication

Comments were processed in batches of 500. Each batch followed cumulative deduplication against all previously accumulated rules using Jaccard similarity (0.4 threshold) on keyword overlap.

### Stage 7: Semantic Deduplication

The initial keyword-based deduplication missed semantic equivalents (e.g., "Use enums for status values" vs "Define status as enum type"). A second pass used Claude to identify semantically equivalent rules within each domain.

### Stage 8: Specificity Filtering

Rules mentioning specific class names, file paths, or project-specific identifiers were filtered as too specific to be useful.

### Stage 9: Generalization

Remaining rules were grouped by domain and processed through Claude to generate high-level principles that capture multiple related rules. For example, 10 rules about "use constants instead of magic strings" consolidated into one principle.

### Stage 10: Ecosystem Tagging

Guidelines were tagged by language/ecosystem applicability (general, devops, testing, frontend, backend, database) using Claude.

### Stage 11: SDLC Phase Tagging

Each guideline was tagged with applicable SDLC phases (planning, design, implementation, testing, review, deployment) using deterministic domain mapping and keyword detection. Guidelines can apply to multiple phases - on average, each guideline applies to 2.38 phases.

### Stage 12: Priority Scoring

Guidelines received priority scores (0-100) based on:
- **Category comment volume**: Categories with more MR comments get higher weight
- **Confidence level**: High confidence guidelines score higher
- **Ecosystem applicability**: General guidelines get a bonus (broader impact)

Priority tiers: critical (80-100), high (60-79), medium (40-59), low (0-39).

---

## Data Files

**Primary Output:**
- `output/guidelines_with_priority_*.json` - 281 guidelines with full metadata (domain, ecosystem, SDLC phases, priority)
- `output/guidelines_simple_*.txt` - Human-readable format by domain
- `output/guidelines_by_phase_*.txt` - Guidelines grouped by SDLC phase
- `output/phase_*.md` - Individual markdown files per SDLC phase (6 files)
- `output/guidelines_by_priority_*.txt` - Guidelines sorted by priority score

**Intermediate Files:**
- `output/all_existing_rules.jsonl` - All 11,571 raw extracted rules
- `output/deduplicated_rules_*.jsonl` - After semantic deduplication (8,909 rules)
- `output/generalized_guidelines_*.json` - After generalization (281 guidelines)
- `output/guidelines_tagged_*.json` - With ecosystem tags
- `output/guidelines_with_phases_*.json` - With SDLC phase tags

**Source Data:**
- `output/categorized_comments_*.jsonl` - All categorized actionable comments
- `output/mr_analysis_*.jsonl` - Raw MR analysis data

**Scripts:** https://code.corp.indeed.com/mbradshaw/mr-spelunking
