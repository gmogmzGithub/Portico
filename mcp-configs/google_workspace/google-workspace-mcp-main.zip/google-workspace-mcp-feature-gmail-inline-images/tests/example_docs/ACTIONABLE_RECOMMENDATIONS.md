# Actionable Recommendations from MR Review Analysis

**Analysis Date**: 2025-12-14
**Data Source**: 27,634 review comments from ~5,500 MRs across 180+ repositories over 30 days
**Output**: 281 guidelines, 5,584 concrete rules, 8,909 deduplicated rules

---

## Executive Summary

Based on deep analysis of merge request review patterns across Indeed's codebase, I've identified **high-impact intervention opportunities** that could significantly reduce review cycles, improve code quality, and save developer time.

The data reveals clear patterns:
1. **Testing** dominates critical priority issues (28 of 36 critical guidelines)
2. **Architecture/Code Duplication** is the most frequent non-test issue (1,174 occurrences)
3. **Configuration Management** issues appear in 635 review occurrences
4. **~850 rules could be automated** via linters or static analysis

---

## Tier 1: Immediate Actions (High ROI, Low Effort)

### 1. Deploy Automated Linter Rules

**Impact**: ~850 rules (15% of all concrete rules) mention patterns that linters can catch.

| Rule Type | Occurrences | Tool |
|-----------|-------------|------|
| Unused imports | 87 | ESLint, Checkstyle, flake8 |
| Unused variables | 79 | ESLint, Checkstyle, flake8 |
| Duplicate code | 223 | SonarQube, PMD |
| Hardcoded values | 135 | Custom rules |
| Naming conventions | 156 | ESLint, Checkstyle |

**Concrete Actions**:
```
1. Enable `no-unused-vars` and `no-unused-imports` in ESLint (React/TS projects)
2. Enable `checkstyle:UnusedImports` for Java projects
3. Add `flake8 --select=F401,F841` to Python CI
4. Configure SonarQube duplication detection threshold to 10 lines
```

**Evidence**: Java alone has 6 occurrences of "Remove all unused imports" - this is pure automation win.

---

### 2. Strengthen Test Requirements in CI/CD

**Impact**: Testing is #1 critical priority domain with 28 critical guidelines.

**Top Testing Issues by Frequency**:
| Issue | Occurrences | Automation |
|-------|-------------|------------|
| Missing test coverage for new code | 122 | Coverage gates |
| Tests not included in same MR | 69 | PR template checks |
| Duplicate test cases | 21 | Test deduplication analysis |
| Flaky tests (timing issues) | 15 | Retry policies |

**Concrete Actions**:
```
1. Add coverage gates: Block MRs that decrease coverage by >2%
2. PR template: Checkbox requiring "Tests included for new functionality"
3. Fail CI if new public methods lack corresponding test files
4. Auto-detect flaky tests: Flag tests that fail intermittently
```

**Evidence**: "Write comprehensive test coverage for all new functionality" has 122 occurrences across 10 source rules.

---

### 3. Java-Specific Quick Wins

**Impact**: Java has 1,304 rules - the most of any language.

**Top Java Issues**:
| Issue | Occurrences | Fix |
|-------|-------------|-----|
| Unsafe string comparison (NPE risk) | 6 | `Objects.equals()` lint rule |
| Unused imports | 6 | Auto-import cleanup |
| Redundant comments | 5 | Comment policy |
| Prefer explicit imports | 5 | Wildcard import ban |

**Concrete Actions**:
```java
// Add to Checkstyle:
<module name="AvoidStarImport"/>
<module name="UnusedImports"/>

// Add Error Prone check:
-Xep:StringEquality:ERROR
```

---

### 4. React/TypeScript Quick Wins

**Impact**: React (752 rules) + TypeScript (462 rules) = 1,214 frontend rules.

**Top Frontend Issues**:
| Issue | Occurrences | Fix |
|-------|-------------|-----|
| Duplicate aria-labels | 7 | Accessibility linter |
| Unused variables | 6 | `no-unused-vars` |
| Missing hook dependencies | 5 | `react-hooks/exhaustive-deps` |
| Design system token bypass | 4 | Custom lint rule |

**Concrete Actions**:
```javascript
// .eslintrc.js additions:
{
  "rules": {
    "no-unused-vars": "error",
    "react-hooks/exhaustive-deps": "error",
    "jsx-a11y/aria-props": "error"
  }
}
```

---

## Tier 2: Medium-Term Investments (High ROI, Moderate Effort)

### 5. Review Bot Enhancement (Aimer)

**Impact**: 135 rules qualify as high-confidence with 3+ occurrences - prime candidates for automated review comments.

**Top Review Bot Candidates**:

1. **Performance - Blocking I/O** (9 occurrences)
   > "Avoid sequential synchronous I/O operations in request paths; use parallel/async instead"
   - Trigger: Detect `for` loops with await/blocking calls

2. **Architecture - Code Duplication** (8 occurrences)
   > "Consolidate prompt instructions into a single location rather than splitting across variables"
   - Trigger: Detect similar string patterns across files

3. **Error Handling - Null Safety** (6 occurrences)
   > "Always use safe string comparison methods (Objects.equals()) to avoid NPE"
   - Trigger: Detect `string.equals()` patterns in Java

4. **API Usage - Pagination** (6 occurrences)
   > "Always implement pagination when fetching large result sets"
   - Trigger: Detect API calls without pagination parameters

---

### 6. Create "Golden Path" Enforcement

**Impact**: Configuration issues have 635 occurrences - many are about inconsistent setup.

**Top Configuration Issues**:
| Issue | Occurrences | Solution |
|-------|-------------|----------|
| Hardcoded config values | 135 | Config validation in CI |
| Environment inconsistency | 82 | Template enforcement |
| Missing dependency validation | 102 | Health check templates |
| Monitoring/alerting gaps | 66 | Observability templates |

**Concrete Actions**:
1. Create golden path templates with pre-configured linting, testing, observability
2. Validate all `application.yaml` against schema in CI
3. Require environment variable documentation in README
4. Block deploys without health check endpoints

---

### 7. Documentation Automation

**Impact**: Documentation domain has 349 occurrences.

**Top Documentation Issues**:
| Issue | Occurrences | Solution |
|-------|-------------|----------|
| Comments that restate code | 86 | Remove via review |
| Docs don't match implementation | 84 | Auto-doc generation |
| Missing why/context comments | 75 | PR template prompt |

**Concrete Actions**:
1. Add "Explain the WHY" section to PR template
2. Generate API docs from code annotations (OpenAPI, etc.)
3. Lint for comment quality (remove `// increment counter` type comments)

---

## Tier 3: Strategic Initiatives (Highest ROI, Requires Investment)

### 8. Security Automation (Critical - 5 Critical Guidelines)

**Impact**: Security issues have 135 occurrences but extremely high severity.

**Critical Security Guidelines**:
1. **Never expose credentials** (score: 91.0) - 65 occurrences
   - Automate: Secret scanning in CI (git-secrets, truffleHog)

2. **Input validation** (score: 85.7) - varies
   - Automate: SAST tools for injection vulnerabilities

3. **Least privilege** (score: 75.1) - varies
   - Automate: IAM policy analysis

4. **Auth deny-by-default** (score: 91.8) - varies
   - Automate: Security review requirement for auth changes

**Concrete Actions**:
```
1. Deploy secret scanning: Block commits with credentials
2. Require security team review for auth-related MRs
3. Add SAST (Semgrep, CodeQL) to CI pipeline
4. Auto-flag MRs touching security-sensitive files
```

---

### 9. Create Developer Onboarding Based on Data

**Impact**: Many issues are "knowledge gap" problems - developers don't know best practices.

**Generate Training Materials For**:
1. **Java developers**: Safe string comparison, import hygiene
2. **React developers**: Hook dependency arrays, accessibility
3. **Python developers**: Type annotations, import organization
4. **Kotlin developers**: Coroutine best practices, blocking I/O avoidance

**Concrete Actions**:
1. Create "Top 10 Review Feedback" guide per language
2. Require completion of guide before first PR
3. Link guides in review bot comments

---

### 10. Cross-Team Pattern Library

**Impact**: Architecture domain has 1,174 occurrences - highest of any domain.

**Recurring Architecture Issues**:
| Issue | Occurrences | Solution |
|-------|-------------|----------|
| Code duplication | 223 | Shared libraries |
| Missing reusable components | 87 | Component catalog |
| Inconsistent patterns | 72 | Architecture decision records |

**Concrete Actions**:
1. Create shared utility library for common patterns
2. Build internal component catalog with approved implementations
3. Document architectural decisions for cross-team reference

---

## Measurement Plan

### Key Metrics to Track

| Metric | Baseline | Target | How to Measure |
|--------|----------|--------|----------------|
| Avg review cycles per MR | ? | -20% | GitLab analytics |
| Test coverage delta | ? | >0% | Coverage tools |
| Security findings | ? | -50% | SAST reports |
| Linter violations | ? | -30% | CI metrics |
| Time to merge | ? | -15% | GitLab analytics |

### Implementation Priority

| Phase | Actions | Timeline | Expected Impact |
|-------|---------|----------|-----------------|
| 1 | Deploy linter rules (1-4) | 2 weeks | 15% of issues automated |
| 2 | CI test gates | 4 weeks | 28 critical issues addressed |
| 3 | Review bot rules | 8 weeks | 135 high-confidence rules enforced |
| 4 | Security automation | 12 weeks | Critical security gaps closed |
| 5 | Training materials | Ongoing | Knowledge gap reduction |

---

## Data Files for Reference

| File | Description | Use Case |
|------|-------------|----------|
| `output/guidelines_with_priority.json` | 281 guidelines with scores | Strategic planning |
| `output/enforcement/java-rules.json` | 1,304 Java rules | Java tooling |
| `output/enforcement/react-rules.json` | 752 React rules | Frontend tooling |
| `output/enforcement/testing-rules.json` | 22 testing rules | Test policy |
| `output/phase_*.md` | SDLC phase checklists | Agent prompts |

---

## Appendix: Top 10 Single Rules by Impact

These are the single most impactful rules based on occurrence frequency and confidence:

1. **Validate inputs early at system boundaries** (136 occurrences)
2. **Extract common logic into reusable components** (123 occurrences)
3. **Write comprehensive test coverage** (122 occurrences)
4. **Validate dependencies before deployment** (102 occurrences)
5. **Externalize configuration values** (92 occurrences)
6. **Remove obsolete code completely** (87 occurrences)
7. **Keep documentation in sync with code** (84 occurrences)
8. **Use centralized configuration management** (82 occurrences)
9. **Leverage existing shared utilities** (82 occurrences)
10. **Use environment-specific configurations** (82 occurrences)

Each of these could justify a dedicated initiative given their frequency.

---

*Generated from analysis of 30 days of MR review data across Indeed's codebase.*
