"""
Unit tests for Gmail label modification tools.

Tests the modify_gmail_message_labels and batch_modify_gmail_message_labels
functions in gmail/gmail_tools.py.
"""

import pytest
from unittest.mock import MagicMock, patch


class TestModifyGmailMessageLabels:
    """Tests for modify_gmail_message_labels tool execution."""

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_add_labels(self, mock_get_service, mock_to_thread):
        """Test adding labels to a message."""
        from gmail.gmail_tools import modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {}

        mock_to_thread.side_effect = execute_sync

        result = await modify_gmail_message_labels.fn(
            user_google_email="test@example.com",
            message_id="msg123",
            add_label_ids=["STARRED", "IMPORTANT"],
        )

        assert "Message labels updated successfully" in result
        assert "msg123" in result
        assert "Added labels" in result
        assert "STARRED" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_remove_labels(self, mock_get_service, mock_to_thread):
        """Test removing labels from a message (e.g., archiving by removing INBOX)."""
        from gmail.gmail_tools import modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {}

        mock_to_thread.side_effect = execute_sync

        result = await modify_gmail_message_labels.fn(
            user_google_email="test@example.com",
            message_id="msg456",
            remove_label_ids=["INBOX"],
        )

        assert "Message labels updated successfully" in result
        assert "Removed labels" in result
        assert "INBOX" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_add_and_remove_labels(self, mock_get_service, mock_to_thread):
        """Test adding and removing labels simultaneously."""
        from gmail.gmail_tools import modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {}

        mock_to_thread.side_effect = execute_sync

        result = await modify_gmail_message_labels.fn(
            user_google_email="test@example.com",
            message_id="msg789",
            add_label_ids=["TRASH"],
            remove_label_ids=["INBOX"],
        )

        assert "Message labels updated successfully" in result
        assert "Added labels" in result
        assert "Removed labels" in result

    @pytest.mark.asyncio
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_no_labels_raises_error(self, mock_get_service):
        """Test that calling with no labels raises an error."""
        from gmail.gmail_tools import modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        with pytest.raises(Exception) as exc_info:
            await modify_gmail_message_labels.fn(
                user_google_email="test@example.com",
                message_id="msg123",
            )

        assert "At least one of add_label_ids or remove_label_ids must be provided" in str(
            exc_info.value
        )

    @pytest.mark.asyncio
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_empty_lists_raises_error(self, mock_get_service):
        """Test that calling with empty lists raises an error."""
        from gmail.gmail_tools import modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        with pytest.raises(Exception) as exc_info:
            await modify_gmail_message_labels.fn(
                user_google_email="test@example.com",
                message_id="msg123",
                add_label_ids=[],
                remove_label_ids=[],
            )

        assert "At least one of add_label_ids or remove_label_ids must be provided" in str(
            exc_info.value
        )

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_none_converted_to_empty_list(self, mock_get_service, mock_to_thread):
        """Test that None values are properly converted to empty lists internally."""
        from gmail.gmail_tools import modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {}

        mock_to_thread.side_effect = execute_sync

        # This should work - add_label_ids is provided, remove_label_ids defaults to None
        result = await modify_gmail_message_labels.fn(
            user_google_email="test@example.com",
            message_id="msg123",
            add_label_ids=["STARRED"],
            remove_label_ids=None,
        )

        assert "Message labels updated successfully" in result


class TestBatchModifyGmailMessageLabels:
    """Tests for batch_modify_gmail_message_labels tool execution."""

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_batch_add_labels(self, mock_get_service, mock_to_thread):
        """Test adding labels to multiple messages."""
        from gmail.gmail_tools import batch_modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {}

        mock_to_thread.side_effect = execute_sync

        result = await batch_modify_gmail_message_labels.fn(
            user_google_email="test@example.com",
            message_ids=["msg1", "msg2", "msg3"],
            add_label_ids=["STARRED"],
        )

        assert "Labels updated for 3 messages" in result
        assert "Added labels" in result
        assert "STARRED" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_batch_remove_labels(self, mock_get_service, mock_to_thread):
        """Test removing labels from multiple messages (e.g., batch archive)."""
        from gmail.gmail_tools import batch_modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {}

        mock_to_thread.side_effect = execute_sync

        result = await batch_modify_gmail_message_labels.fn(
            user_google_email="test@example.com",
            message_ids=["msg1", "msg2"],
            remove_label_ids=["INBOX"],
        )

        assert "Labels updated for 2 messages" in result
        assert "Removed labels" in result
        assert "INBOX" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_batch_add_and_remove_labels(self, mock_get_service, mock_to_thread):
        """Test adding and removing labels from multiple messages."""
        from gmail.gmail_tools import batch_modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {}

        mock_to_thread.side_effect = execute_sync

        result = await batch_modify_gmail_message_labels.fn(
            user_google_email="test@example.com",
            message_ids=["msg1", "msg2", "msg3", "msg4"],
            add_label_ids=["TRASH"],
            remove_label_ids=["INBOX", "UNREAD"],
        )

        assert "Labels updated for 4 messages" in result
        assert "Added labels" in result
        assert "Removed labels" in result

    @pytest.mark.asyncio
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_batch_no_labels_raises_error(self, mock_get_service):
        """Test that calling with no labels raises an error."""
        from gmail.gmail_tools import batch_modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        with pytest.raises(Exception) as exc_info:
            await batch_modify_gmail_message_labels.fn(
                user_google_email="test@example.com",
                message_ids=["msg1", "msg2"],
            )

        assert "At least one of add_label_ids or remove_label_ids must be provided" in str(
            exc_info.value
        )

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_batch_none_converted_to_empty_list(
        self, mock_get_service, mock_to_thread
    ):
        """Test that None values are properly converted to empty lists internally."""
        from gmail.gmail_tools import batch_modify_gmail_message_labels

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {}

        mock_to_thread.side_effect = execute_sync

        # This should work - only add_label_ids provided
        result = await batch_modify_gmail_message_labels.fn(
            user_google_email="test@example.com",
            message_ids=["msg1"],
            add_label_ids=["IMPORTANT"],
            remove_label_ids=None,
        )

        assert "Labels updated for 1 messages" in result
