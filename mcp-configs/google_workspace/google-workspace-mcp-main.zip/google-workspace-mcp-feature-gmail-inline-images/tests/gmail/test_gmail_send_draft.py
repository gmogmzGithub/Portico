"""
Unit tests for Gmail send and draft tools.

Tests the send_gmail_message and draft_gmail_message functions in gmail/gmail_tools.py.
"""

import pytest
from unittest.mock import MagicMock, patch


class TestSendGmailMessage:
    """Tests for send_gmail_message tool execution."""

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_send_basic_email(self, mock_get_service, mock_to_thread):
        """Test sending a basic email."""
        from gmail.gmail_tools import send_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "sent_msg_123"}

        mock_to_thread.side_effect = execute_sync

        result = await send_gmail_message.fn(
            user_google_email="test@example.com",
            to="recipient@example.com",
            subject="Test Subject",
            body="This is a test email body.",
        )

        assert "Email sent" in result
        assert "sent_msg_123" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_send_html_email(self, mock_get_service, mock_to_thread):
        """Test sending an HTML email."""
        from gmail.gmail_tools import send_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "html_msg_456"}

        mock_to_thread.side_effect = execute_sync

        result = await send_gmail_message.fn(
            user_google_email="test@example.com",
            to="recipient@example.com",
            subject="HTML Test",
            body="<h1>Hello</h1><p>This is HTML content.</p>",
            body_format="html",
        )

        assert "Email sent" in result
        assert "html_msg_456" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_send_email_with_cc_bcc(self, mock_get_service, mock_to_thread):
        """Test sending email with CC and BCC."""
        from gmail.gmail_tools import send_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "cc_bcc_msg"}

        mock_to_thread.side_effect = execute_sync

        result = await send_gmail_message.fn(
            user_google_email="test@example.com",
            to="recipient@example.com",
            subject="CC/BCC Test",
            body="Test body",
            cc="cc@example.com",
            bcc="bcc@example.com",
        )

        assert "Email sent" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_send_reply(self, mock_get_service, mock_to_thread):
        """Test sending a reply with threading info."""
        from gmail.gmail_tools import send_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "reply_msg"}

        mock_to_thread.side_effect = execute_sync

        result = await send_gmail_message.fn(
            user_google_email="test@example.com",
            to="recipient@example.com",
            subject="Re: Original Subject",
            body="Thanks for your message!",
            thread_id="thread_123",
            in_reply_to="<original@example.com>",
            references="<original@example.com>",
        )

        assert "Email sent" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_send_with_default_body_format(self, mock_get_service, mock_to_thread):
        """Test that body_format defaults to 'plain'."""
        from gmail.gmail_tools import send_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "plain_msg"}

        mock_to_thread.side_effect = execute_sync

        # Not specifying body_format should default to "plain"
        result = await send_gmail_message.fn(
            user_google_email="test@example.com",
            to="recipient@example.com",
            subject="Plain Text Test",
            body="Plain text body",
        )

        assert "Email sent" in result


class TestDraftGmailMessage:
    """Tests for draft_gmail_message tool execution."""

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_basic_draft(self, mock_get_service, mock_to_thread):
        """Test creating a basic draft."""
        from gmail.gmail_tools import draft_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "draft_123"}

        mock_to_thread.side_effect = execute_sync

        result = await draft_gmail_message.fn(
            user_google_email="test@example.com",
            subject="Draft Subject",
            body="This is a draft body.",
        )

        assert "Draft created" in result
        assert "draft_123" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_draft_with_recipient(self, mock_get_service, mock_to_thread):
        """Test creating a draft with recipient."""
        from gmail.gmail_tools import draft_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "draft_456"}

        mock_to_thread.side_effect = execute_sync

        result = await draft_gmail_message.fn(
            user_google_email="test@example.com",
            subject="Draft with To",
            body="Draft body",
            to="recipient@example.com",
        )

        assert "Draft created" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_html_draft(self, mock_get_service, mock_to_thread):
        """Test creating an HTML draft."""
        from gmail.gmail_tools import draft_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "html_draft"}

        mock_to_thread.side_effect = execute_sync

        result = await draft_gmail_message.fn(
            user_google_email="test@example.com",
            subject="HTML Draft",
            body="<p>HTML content</p>",
            body_format="html",
        )

        assert "Draft created" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_reply_draft(self, mock_get_service, mock_to_thread):
        """Test creating a reply draft."""
        from gmail.gmail_tools import draft_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "reply_draft"}

        mock_to_thread.side_effect = execute_sync

        result = await draft_gmail_message.fn(
            user_google_email="test@example.com",
            subject="Re: Thread",
            body="Reply draft content",
            to="original_sender@example.com",
            thread_id="thread_abc",
            in_reply_to="<msg@example.com>",
        )

        assert "Draft created" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_create_draft_without_to(self, mock_get_service, mock_to_thread):
        """Test that drafts can be created without a recipient (to is optional)."""
        from gmail.gmail_tools import draft_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "no_to_draft"}

        mock_to_thread.side_effect = execute_sync

        # Draft without 'to' should work
        result = await draft_gmail_message.fn(
            user_google_email="test@example.com",
            subject="No Recipient Draft",
            body="Draft without recipient",
        )

        assert "Draft created" in result

    @pytest.mark.asyncio
    @patch("gmail.gmail_tools.asyncio.to_thread")
    @patch("auth.service_decorator.get_authenticated_google_service")
    async def test_draft_with_all_optional_fields_none(
        self, mock_get_service, mock_to_thread
    ):
        """Test draft creation with all optional fields explicitly None."""
        from gmail.gmail_tools import draft_gmail_message

        mock_service = MagicMock()
        mock_get_service.return_value = (mock_service, "test@example.com")

        async def execute_sync(func, *args, **kwargs):
            return {"id": "minimal_draft"}

        mock_to_thread.side_effect = execute_sync

        result = await draft_gmail_message.fn(
            user_google_email="test@example.com",
            subject="Minimal Draft",
            body="Just subject and body",
            to=None,
            cc=None,
            bcc=None,
            thread_id=None,
            in_reply_to=None,
            references=None,
        )

        assert "Draft created" in result


class TestPrepareGmailMessage:
    """Tests for the internal _prepare_gmail_message function."""

    def test_prepare_plain_message(self):
        """Test preparing a plain text message."""
        from gmail.gmail_tools import _prepare_gmail_message

        raw_message, thread_id = _prepare_gmail_message(
            subject="Test",
            body="Plain body",
            to="recipient@example.com",
            body_format="plain",
        )

        # raw_message should be base64 encoded
        assert isinstance(raw_message, str)
        assert len(raw_message) > 0
        assert thread_id is None

    def test_prepare_html_message(self):
        """Test preparing an HTML message."""
        from gmail.gmail_tools import _prepare_gmail_message

        raw_message, thread_id = _prepare_gmail_message(
            subject="Test",
            body="<p>HTML body</p>",
            to="recipient@example.com",
            body_format="html",
        )

        assert isinstance(raw_message, str)
        assert len(raw_message) > 0

    def test_prepare_reply_adds_re_prefix(self):
        """Test that reply messages get Re: prefix if not present."""
        from gmail.gmail_tools import _prepare_gmail_message

        raw_message, thread_id = _prepare_gmail_message(
            subject="Original Subject",
            body="Reply body",
            to="recipient@example.com",
            in_reply_to="<original@example.com>",
        )

        # The raw message should contain "Re: Original Subject"
        import base64

        decoded = base64.urlsafe_b64decode(raw_message).decode("utf-8")
        assert "Re: Original Subject" in decoded

    def test_prepare_reply_preserves_re_prefix(self):
        """Test that Re: prefix is not duplicated."""
        from gmail.gmail_tools import _prepare_gmail_message

        raw_message, thread_id = _prepare_gmail_message(
            subject="Re: Already a Reply",
            body="Reply body",
            to="recipient@example.com",
            in_reply_to="<original@example.com>",
        )

        import base64

        decoded = base64.urlsafe_b64decode(raw_message).decode("utf-8")
        # Should not have "Re: Re:"
        assert "Re: Re:" not in decoded
        assert "Re: Already a Reply" in decoded

    def test_prepare_message_invalid_format_raises(self):
        """Test that invalid body_format raises ValueError."""
        from gmail.gmail_tools import _prepare_gmail_message

        with pytest.raises(ValueError) as exc_info:
            _prepare_gmail_message(
                subject="Test",
                body="Body",
                to="recipient@example.com",
                body_format="invalid",
            )

        assert "body_format must be either 'plain' or 'html'" in str(exc_info.value)
