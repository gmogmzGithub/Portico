"""Tests for tools_cli.py argument parsing and value conversion."""

import json
from typing import Optional, List, Union

# Extract the functions from tools_cli.py for testing
# These are defined inside main(), so we need to replicate them here for unit testing
def unescape_shell_chars(value: str) -> str:
    """Unescape common shell-escaped characters in string values."""
    if not isinstance(value, str):
        return value
    value = value.replace(r"\\", "\x00")  # Temporarily protect \\
    value = value.replace(r"\!", "!")
    value = value.replace(r"\$", "$")
    value = value.replace(r"\`", "`")
    value = value.replace(r"\#", "#")
    value = value.replace(r"\"", '"')
    value = value.replace(r"\'", "'")
    value = value.replace("\x00", "\\")  # Restore single backslash from \\
    return value


class TestUnescapeShellChars:
    """Test cases for unescape_shell_chars function."""

    def test_unescape_exclamation_mark(self):
        """Test that escaped exclamation marks are unescaped."""
        assert unescape_shell_chars(r"Sheet1\!A1:B2") == "Sheet1!A1:B2"

    def test_unescape_exclamation_mark_in_middle(self):
        """Test unescaping ! in the middle of a string."""
        assert unescape_shell_chars(r"prefix\!suffix") == "prefix!suffix"

    def test_unescape_multiple_exclamation_marks(self):
        """Test unescaping multiple exclamation marks."""
        assert unescape_shell_chars(r"a\!b\!c") == "a!b!c"

    def test_unescape_dollar_sign(self):
        """Test that escaped dollar signs are unescaped."""
        assert unescape_shell_chars(r"\$HOME") == "$HOME"

    def test_unescape_backtick(self):
        """Test that escaped backticks are unescaped."""
        assert unescape_shell_chars(r"\`command\`") == "`command`"

    def test_unescape_hash(self):
        """Test that escaped hash signs are unescaped."""
        assert unescape_shell_chars(r"\#comment") == "#comment"

    def test_unescape_double_quote(self):
        """Test that escaped double quotes are unescaped."""
        assert unescape_shell_chars(r"\"quoted\"") == '"quoted"'

    def test_unescape_single_quote(self):
        """Test that escaped single quotes are unescaped."""
        assert unescape_shell_chars(r"\'quoted\'") == "'quoted'"

    def test_preserve_double_backslash_as_single(self):
        """Test that double backslash becomes single backslash."""
        assert unescape_shell_chars(r"path\\to\\file") == "path\\to\\file"

    def test_no_change_for_normal_text(self):
        """Test that normal text without escapes is unchanged."""
        assert unescape_shell_chars("normal text") == "normal text"

    def test_no_change_for_unescaped_exclamation(self):
        """Test that unescaped exclamation marks are preserved."""
        assert unescape_shell_chars("Sheet1!A1:B2") == "Sheet1!A1:B2"

    def test_non_string_returns_unchanged(self):
        """Test that non-string values are returned unchanged."""
        assert unescape_shell_chars(123) == 123
        assert unescape_shell_chars(None) is None
        assert unescape_shell_chars(["list"]) == ["list"]

    def test_empty_string(self):
        """Test that empty string returns empty string."""
        assert unescape_shell_chars("") == ""

    def test_complex_range_name(self):
        """Test a complex Google Sheets range name."""
        # This is the exact use case from the bug report
        assert unescape_shell_chars(r"'Sheet Name'\!A1:Z100") == "'Sheet Name'!A1:Z100"

    def test_mixed_escapes(self):
        """Test multiple different escape sequences in one string."""
        assert unescape_shell_chars(r"\!\$\#") == "!$#"


def convert_value_by_type(value: str, expected_type) -> any:
    """
    Convert a string value based on expected type annotation.
    Replicated from tools_cli.py for unit testing.
    """
    if value is True:  # Boolean flag (--flag without value)
        return value

    # Handle Optional types (e.g., Optional[int] = Union[int, None])
    origin = getattr(expected_type, "__origin__", None)
    if origin is type(None):
        return None

    # Extract the actual type from Optional/Union
    type_args = getattr(expected_type, "__args__", ())
    if type_args:
        # Filter out NoneType from Union types
        non_none_types = [t for t in type_args if t is not type(None)]
        if non_none_types:
            expected_type = non_none_types[0]
            # Re-compute origin for the extracted type
            origin = getattr(expected_type, "__origin__", None)

    # Convert based on expected type
    if expected_type is bool:
        return value.lower() == "true"
    elif expected_type is int:
        return int(value)
    elif expected_type is float:
        return float(value)
    elif expected_type in (list, dict) or origin in (list, dict):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return unescape_shell_chars(value)
    else:
        # Default: keep as string, unescape shell characters
        return unescape_shell_chars(value)


class TestConvertValueByType:
    """Test cases for convert_value_by_type function."""

    def test_convert_string(self):
        """Test converting a simple string."""
        assert convert_value_by_type("hello", str) == "hello"

    def test_convert_int(self):
        """Test converting to int."""
        assert convert_value_by_type("42", int) == 42

    def test_convert_float(self):
        """Test converting to float."""
        assert convert_value_by_type("3.14", float) == 3.14

    def test_convert_bool_true(self):
        """Test converting 'true' to bool."""
        assert convert_value_by_type("true", bool) is True
        assert convert_value_by_type("True", bool) is True

    def test_convert_bool_false(self):
        """Test converting 'false' to bool."""
        assert convert_value_by_type("false", bool) is False
        assert convert_value_by_type("False", bool) is False

    def test_convert_list(self):
        """Test converting JSON list with bare list type."""
        # Note: With List[str], the function extracts str from type_args,
        # so it returns the string unescaped. Use bare `list` for JSON parsing.
        result = convert_value_by_type('["a", "b", "c"]', list)
        assert result == ["a", "b", "c"]

    def test_convert_dict(self):
        """Test converting JSON dict with bare dict type."""
        result = convert_value_by_type('{"key": "value"}', dict)
        assert result == {"key": "value"}

    def test_convert_optional_string(self):
        """Test converting Optional[str]."""
        result = convert_value_by_type("hello", Optional[str])
        assert result == "hello"

    def test_convert_optional_int(self):
        """Test converting Optional[int]."""
        result = convert_value_by_type("42", Optional[int])
        assert result == 42

    def test_convert_optional_list_str(self):
        """Test converting Optional[List[str]] - the main bug fix case."""
        result = convert_value_by_type('["INBOX", "STARRED"]', Optional[List[str]])
        assert result == ["INBOX", "STARRED"]
        assert isinstance(result, list)

    def test_convert_optional_list_str_single_item(self):
        """Test converting Optional[List[str]] with single item."""
        result = convert_value_by_type('["INBOX"]', Optional[List[str]])
        assert result == ["INBOX"]

    def test_convert_optional_list_str_empty(self):
        """Test converting Optional[List[str]] with empty list."""
        result = convert_value_by_type("[]", Optional[List[str]])
        assert result == []

    def test_convert_union_with_none(self):
        """Test converting Union[List[str], None] (equivalent to Optional[List[str]])."""
        result = convert_value_by_type('["a", "b"]', Union[List[str], None])
        assert result == ["a", "b"]

    def test_convert_nested_optional(self):
        """Test that origin is recomputed after extracting from Optional."""
        # This specifically tests the bug fix where origin wasn't recomputed
        # after extracting the inner type from Optional[List[str]]
        result = convert_value_by_type('["item1", "item2"]', Optional[List[str]])
        # Before the fix, this would return the string '["item1", "item2"]'
        # After the fix, it correctly returns a list
        assert isinstance(result, list)
        assert result == ["item1", "item2"]

    def test_boolean_flag_passthrough(self):
        """Test that boolean True is passed through unchanged."""
        assert convert_value_by_type(True, bool) is True

    def test_invalid_json_returns_string(self):
        """Test that invalid JSON falls back to string."""
        result = convert_value_by_type("not-json", List[str])
        assert result == "not-json"
