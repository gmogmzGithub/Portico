"""Tests for the ToolOptimizer async initialization and caching."""

import pytest
import time

from core.optimizer import (
    ToolOptimizer,
    OptimizerNotReadyError,
    EMBEDDINGS_CACHE_FILE,
)


@pytest.fixture
def sample_tools():
    """Create a small set of sample tools for testing."""
    return {
        "send_email": {
            "name": "send_email",
            "description": "Send an email message to recipients",
            "inputSchema": {"type": "object", "properties": {"to": {"type": "string"}}},
            "service": "gmail",
        },
        "read_email": {
            "name": "read_email",
            "description": "Read emails from the inbox",
            "inputSchema": {"type": "object", "properties": {}},
            "service": "gmail",
        },
        "create_doc": {
            "name": "create_doc",
            "description": "Create a new Google Document",
            "inputSchema": {
                "type": "object",
                "properties": {"title": {"type": "string"}},
            },
            "service": "docs",
        },
    }


@pytest.fixture
def clean_cache():
    """Remove cache files before and after test."""
    if EMBEDDINGS_CACHE_FILE.exists():
        EMBEDDINGS_CACHE_FILE.unlink()
    yield
    if EMBEDDINGS_CACHE_FILE.exists():
        EMBEDDINGS_CACHE_FILE.unlink()


class TestOptimizerAsyncInit:
    """Tests for async initialization behavior."""

    def test_initialize_returns_instantly(self, sample_tools, clean_cache):
        """initialize() should return immediately without blocking."""
        opt = ToolOptimizer()

        start = time.time()
        opt.initialize(sample_tools, {})
        elapsed = time.time() - start

        # Should return in under 100ms (instant)
        assert elapsed < 0.1, f"initialize() took {elapsed:.3f}s, expected < 0.1s"
        assert opt._initialized is True

    def test_list_all_tools_works_immediately(self, sample_tools, clean_cache):
        """list_all_tools() should work immediately after initialize()."""
        opt = ToolOptimizer()
        opt.initialize(sample_tools, {})

        tools = opt.list_all_tools()

        assert len(tools) == 3
        assert "send_email" in tools
        assert "read_email" in tools
        assert "create_doc" in tools

    def test_get_tool_definition_works_immediately(self, sample_tools, clean_cache):
        """get_tool_definition() should work immediately after initialize()."""
        opt = ToolOptimizer()
        opt.initialize(sample_tools, {})

        definition = opt.get_tool_definition("send_email")

        assert definition["name"] == "send_email"
        assert "email" in definition["description"].lower()

    def test_find_similar_tools_raises_when_not_ready(self, sample_tools, clean_cache):
        """find_similar_tools() should raise OptimizerNotReadyError before embeddings ready."""
        opt = ToolOptimizer()
        opt.initialize(sample_tools, {})

        # Immediately after init, embeddings may not be ready
        if not opt.is_ready():
            with pytest.raises(OptimizerNotReadyError) as exc_info:
                opt.find_similar_tools("send a message")

            assert exc_info.value.retry_after_seconds == 3
            assert (
                "initializing" in exc_info.value.message.lower()
                or "loading" in exc_info.value.message.lower()
            )

    def test_is_ready_false_initially(self, sample_tools, clean_cache):
        """is_ready() should return False immediately after initialize()."""
        opt = ToolOptimizer()
        opt.initialize(sample_tools, {})

        # Note: This may occasionally be True if the system is very fast
        # The important thing is that it doesn't block
        initial_ready = opt.is_ready()
        # We don't assert False because on fast systems it might already be done
        assert isinstance(initial_ready, bool)

    def test_wait_until_ready_blocks(self, sample_tools, clean_cache):
        """wait_until_ready() should block until embeddings are computed."""
        opt = ToolOptimizer()
        opt.initialize(sample_tools, {})

        ready = opt.wait_until_ready(timeout=60)

        assert ready is True
        assert opt.is_ready() is True

    def test_find_similar_tools_works_after_ready(self, sample_tools, clean_cache):
        """find_similar_tools() should work after wait_until_ready()."""
        opt = ToolOptimizer()
        opt.initialize(sample_tools, {})
        opt.wait_until_ready(timeout=60)

        results = opt.find_similar_tools("send a message", top_k=2)

        assert len(results) > 0
        assert results[0]["name"] == "send_email"  # Best match for "send a message"
        assert "score" in results[0]


class TestOptimizerCaching:
    """Tests for embedding cache behavior."""

    def test_cache_created_after_init(self, sample_tools, clean_cache):
        """Cache file should be created after embeddings are computed."""
        assert not EMBEDDINGS_CACHE_FILE.exists()

        opt = ToolOptimizer()
        opt.initialize(sample_tools, {})
        opt.wait_until_ready(timeout=60)

        assert EMBEDDINGS_CACHE_FILE.exists()

    def test_cache_used_on_second_init(self, sample_tools, clean_cache):
        """Second initialization with same tools should use cache."""
        # First init - creates cache
        opt1 = ToolOptimizer()
        opt1.initialize(sample_tools, {})
        opt1.wait_until_ready(timeout=60)

        assert EMBEDDINGS_CACHE_FILE.exists()
        cache_mtime = EMBEDDINGS_CACHE_FILE.stat().st_mtime

        # Second init - should use cache (file not modified)
        opt2 = ToolOptimizer()
        opt2.initialize(sample_tools, {})
        opt2.wait_until_ready(timeout=60)

        assert EMBEDDINGS_CACHE_FILE.stat().st_mtime == cache_mtime

    def test_cache_invalidated_when_tools_change(self, sample_tools, clean_cache):
        """Cache should be invalidated when tool set changes."""
        # First init
        opt1 = ToolOptimizer()
        opt1.initialize(sample_tools, {})
        opt1.wait_until_ready(timeout=60)

        cache_mtime = EMBEDDINGS_CACHE_FILE.stat().st_mtime

        # Modify tools - add a new one
        modified_tools = sample_tools.copy()
        modified_tools["new_tool"] = {
            "name": "new_tool",
            "description": "A brand new tool",
            "inputSchema": {},
            "service": "test",
        }

        # Second init with different tools - should recompute
        opt2 = ToolOptimizer()
        opt2.initialize(modified_tools, {})
        opt2.wait_until_ready(timeout=60)

        # Cache should have been updated
        assert EMBEDDINGS_CACHE_FILE.stat().st_mtime > cache_mtime


class TestOptimizerNotReadyError:
    """Tests for the OptimizerNotReadyError exception."""

    def test_error_has_retry_after(self):
        """OptimizerNotReadyError should have retry_after_seconds."""
        error = OptimizerNotReadyError("Test message")

        assert error.retry_after_seconds == 3
        assert error.message == "Test message"
        assert str(error) == "Test message"

    def test_error_default_message(self):
        """OptimizerNotReadyError should have a default message."""
        error = OptimizerNotReadyError()

        assert "initializing" in error.message.lower()
