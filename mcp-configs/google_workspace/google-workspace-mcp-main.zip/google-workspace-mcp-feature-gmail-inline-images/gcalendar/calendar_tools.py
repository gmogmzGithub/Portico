"""
Google Calendar MCP Tools

This module provides MCP tools for interacting with Google Calendar API.
"""

import datetime
import logging
import asyncio
import re
import uuid
import json
from typing import List, Optional, Dict, Any, Union

from googleapiclient.errors import HttpError
from googleapiclient.discovery import build

from auth.service_decorator import require_google_service
from core.utils import handle_http_errors

from core.server import server


# Configure module logger
logger = logging.getLogger(__name__)


def _parse_reminders_json(
    reminders_input: Optional[Union[str, List[Dict[str, Any]]]], function_name: str
) -> List[Dict[str, Any]]:
    """
    Parse reminders from JSON string or list object and validate them.

    Args:
        reminders_input: JSON string containing reminder objects or list of reminder objects
        function_name: Name of calling function for logging

    Returns:
        List of validated reminder objects
    """
    if not reminders_input:
        return []

    # Handle both string (JSON) and list inputs
    if isinstance(reminders_input, str):
        try:
            reminders = json.loads(reminders_input)
            if not isinstance(reminders, list):
                logger.warning(
                    f"[{function_name}] Reminders must be a JSON array, got {type(reminders).__name__}"
                )
                return []
        except json.JSONDecodeError as e:
            logger.warning(f"[{function_name}] Invalid JSON for reminders: {e}")
            return []
    elif isinstance(reminders_input, list):
        reminders = reminders_input
    else:
        logger.warning(
            f"[{function_name}] Reminders must be a JSON string or list, got {type(reminders_input).__name__}"
        )
        return []

    # Validate reminders
    if len(reminders) > 5:
        logger.warning(
            f"[{function_name}] More than 5 reminders provided, truncating to first 5"
        )
        reminders = reminders[:5]

    validated_reminders = []
    for reminder in reminders:
        if (
            not isinstance(reminder, dict)
            or "method" not in reminder
            or "minutes" not in reminder
        ):
            logger.warning(
                f"[{function_name}] Invalid reminder format: {reminder}, skipping"
            )
            continue

        method = reminder["method"].lower()
        if method not in ["popup", "email"]:
            logger.warning(
                f"[{function_name}] Invalid reminder method '{method}', must be 'popup' or 'email', skipping"
            )
            continue

        minutes = reminder["minutes"]
        if not isinstance(minutes, int) or minutes < 0 or minutes > 40320:
            logger.warning(
                f"[{function_name}] Invalid reminder minutes '{minutes}', must be integer 0-40320, skipping"
            )
            continue

        validated_reminders.append({"method": method, "minutes": minutes})

    return validated_reminders


def _apply_transparency_if_valid(
    event_body: Dict[str, Any],
    transparency: Optional[str],
    function_name: str,
) -> None:
    """
    Apply transparency to the event body if the provided value is valid.

    Args:
        event_body: Event payload being constructed.
        transparency: Provided transparency value.
        function_name: Name of the calling function for logging context.
    """
    if transparency is None:
        return

    valid_transparency_values = ["opaque", "transparent"]
    if transparency in valid_transparency_values:
        event_body["transparency"] = transparency
        logger.info(f"[{function_name}] Set transparency to '{transparency}'")
    else:
        logger.warning(
            f"[{function_name}] Invalid transparency value '{transparency}', must be 'opaque' or 'transparent', skipping"
        )


def _apply_visibility_if_valid(
    event_body: Dict[str, Any],
    visibility: Optional[str],
    function_name: str,
) -> None:
    """
    Apply visibility to the event body if the provided value is valid.

    Args:
        event_body: Event payload being constructed.
        visibility: Provided visibility value.
        function_name: Name of the calling function for logging context.
    """
    if visibility is None:
        return

    valid_visibility_values = ["default", "public", "private", "confidential"]
    if visibility in valid_visibility_values:
        event_body["visibility"] = visibility
        logger.info(f"[{function_name}] Set visibility to '{visibility}'")
    else:
        logger.warning(
            f"[{function_name}] Invalid visibility value '{visibility}', must be one of {valid_visibility_values}, skipping"
        )


def _validate_send_updates(send_updates: Optional[str], function_name: str) -> Optional[str]:
    """
    Validate the send_updates parameter value.

    Args:
        send_updates: The send_updates value to validate.
        function_name: Name of the calling function for logging context.

    Returns:
        The validated send_updates value, or None if invalid.
    """
    if send_updates is None:
        return None

    valid_values = ["all", "externalOnly", "none"]
    if send_updates in valid_values:
        return send_updates
    else:
        logger.warning(
            f"[{function_name}] Invalid send_updates value '{send_updates}', must be one of {valid_values}, using default 'all'"
        )
        return "all"


def _preserve_existing_fields(
    event_body: Dict[str, Any],
    existing_event: Dict[str, Any],
    field_mappings: Dict[str, Any],
) -> None:
    """
    Helper function to preserve existing event fields when not explicitly provided.

    Args:
        event_body: The event body being built for the API call
        existing_event: The existing event data from the API
        field_mappings: Dict mapping field names to their new values (None means preserve existing)
    """
    for field_name, new_value in field_mappings.items():
        if new_value is None and field_name in existing_event:
            event_body[field_name] = existing_event[field_name]
            logger.info(f"[modify_event] Preserving existing {field_name}")
        elif new_value is not None:
            event_body[field_name] = new_value


def _format_attendee_details(
    attendees: List[Dict[str, Any]], indent: str = "  "
) -> str:
    """
      Format attendee details including response status, organizer, and optional flags.

      Example output format:
      "  user@example.com: accepted
    manager@example.com: declined (organizer)
    optional-person@example.com: tentative (optional)"

      Args:
          attendees: List of attendee dictionaries from Google Calendar API
          indent: Indentation to use for newline-separated attendees (default: "  ")

      Returns:
          Formatted string with attendee details, or "None" if no attendees
    """
    if not attendees:
        return "None"

    attendee_details_list = []
    for a in attendees:
        email = a.get("email", "unknown")
        response_status = a.get("responseStatus", "unknown")
        optional = a.get("optional", False)
        organizer = a.get("organizer", False)

        detail_parts = [f"{email}: {response_status}"]
        if organizer:
            detail_parts.append("(organizer)")
        if optional:
            detail_parts.append("(optional)")

        attendee_details_list.append(" ".join(detail_parts))

    return f"\n{indent}".join(attendee_details_list)


def _format_attachment_details(
    attachments: List[Dict[str, Any]], indent: str = "  "
) -> str:
    """
    Format attachment details including file information.


    Args:
        attachments: List of attachment dictionaries from Google Calendar API
        indent: Indentation to use for newline-separated attachments (default: "  ")

    Returns:
        Formatted string with attachment details, or "None" if no attachments
    """
    if not attachments:
        return "None"

    attachment_details_list = []
    for att in attachments:
        title = att.get("title", "Untitled")
        file_url = att.get("fileUrl", "No URL")
        file_id = att.get("fileId", "No ID")
        mime_type = att.get("mimeType", "Unknown")

        attachment_info = (
            f"{title}\n"
            f"{indent}File URL: {file_url}\n"
            f"{indent}File ID: {file_id}\n"
            f"{indent}MIME Type: {mime_type}"
        )
        attachment_details_list.append(attachment_info)

    return f"\n{indent}".join(attachment_details_list)


# Helper function to ensure time strings for API calls are correctly formatted
def _correct_time_format_for_api(
    time_str: Optional[str], param_name: str
) -> Optional[str]:
    if not time_str:
        return None

    logger.info(
        f"_correct_time_format_for_api: Processing {param_name} with value '{time_str}'"
    )

    # Handle date-only format (YYYY-MM-DD)
    if len(time_str) == 10 and time_str.count("-") == 2:
        try:
            # Validate it's a proper date
            datetime.datetime.strptime(time_str, "%Y-%m-%d")
            # For date-only, append T00:00:00Z to make it RFC3339 compliant
            formatted = f"{time_str}T00:00:00Z"
            logger.info(
                f"Formatting date-only {param_name} '{time_str}' to RFC3339: '{formatted}'"
            )
            return formatted
        except ValueError:
            logger.warning(
                f"{param_name} '{time_str}' looks like a date but is not valid YYYY-MM-DD. Using as is."
            )
            return time_str

    # Specifically address YYYY-MM-DDTHH:MM:SS by appending 'Z'
    if (
        len(time_str) == 19
        and time_str[10] == "T"
        and time_str.count(":") == 2
        and not (
            time_str.endswith("Z") or ("+" in time_str[10:]) or ("-" in time_str[10:])
        )
    ):
        try:
            # Validate the format before appending 'Z'
            datetime.datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S")
            logger.info(
                f"Formatting {param_name} '{time_str}' by appending 'Z' for UTC."
            )
            return time_str + "Z"
        except ValueError:
            logger.warning(
                f"{param_name} '{time_str}' looks like it needs 'Z' but is not valid YYYY-MM-DDTHH:MM:SS. Using as is."
            )
            return time_str

    # If it already has timezone info or doesn't match our patterns, return as is
    logger.info(f"{param_name} '{time_str}' doesn't need formatting, using as is.")
    return time_str


@server.tool()
@handle_http_errors("list_calendars", is_read_only=True, service_type="calendar")
@require_google_service("calendar", "calendar_read")
async def list_calendars(service, user_google_email: str) -> str:
    """
    Retrieves a list of calendars accessible to the authenticated user.

    Args:
        user_google_email (str): The user's Google email address. Required.

    Returns:
        str: A formatted list of the user's calendars (summary, ID, primary status).
    """
    logger.info(f"[list_calendars] Invoked. Email: '{user_google_email}'")

    calendar_list_response = await asyncio.to_thread(
        lambda: service.calendarList().list().execute()
    )
    items = calendar_list_response.get("items", [])
    if not items:
        return f"No calendars found for {user_google_email}."

    calendars_summary_list = [
        f'- "{cal.get("summary", "No Summary")}"{" (Primary)" if cal.get("primary") else ""} (ID: {cal["id"]})'
        for cal in items
    ]
    text_output = (
        f"Successfully listed {len(items)} calendars for {user_google_email}:\n"
        + "\n".join(calendars_summary_list)
    )
    logger.info(f"Successfully listed {len(items)} calendars for {user_google_email}.")
    return text_output


@server.tool()
@handle_http_errors("get_events", is_read_only=True, service_type="calendar")
@require_google_service("calendar", "calendar_read")
async def get_events(
    service,
    user_google_email: str,
    calendar_id: str = "primary",
    event_id: Optional[str] = None,
    time_min: Optional[str] = None,
    time_max: Optional[str] = None,
    max_results: int = 25,
    query: Optional[str] = None,
    detailed: bool = False,
    include_attachments: bool = False,
) -> str:
    """
    Retrieves events from a specified Google Calendar. Can retrieve a single event by ID or multiple events within a time range.
    You can also search for events by keyword by supplying the optional "query" param.

    Args:
        user_google_email (str): The user's Google email address. Required.
        calendar_id (str): The ID of the calendar to query. Use 'primary' for the user's primary calendar. Defaults to 'primary'. Calendar IDs can be obtained using `list_calendars`.
        event_id (Optional[str]): The ID of a specific event to retrieve. If provided, retrieves only this event and ignores time filtering parameters.
        time_min (Optional[str]): The start of the time range (inclusive) in RFC3339 format (e.g., '2024-05-12T10:00:00Z' or '2024-05-12'). If omitted, defaults to the current time. Ignored if event_id is provided.
        time_max (Optional[str]): The end of the time range (exclusive) in RFC3339 format. If omitted, events starting from `time_min` onwards are considered (up to `max_results`). Ignored if event_id is provided.
        max_results (int): The maximum number of events to return. Defaults to 25. Ignored if event_id is provided.
        query (Optional[str]): A keyword to search for within event fields (summary, description, location). Ignored if event_id is provided.
        detailed (bool): Whether to return detailed event information including description, location, attendees, and attendee details (response status, organizer, optional flags). Defaults to False.
        include_attachments (bool): Whether to include attachment information in detailed event output. When True, shows attachment details (fileId, fileUrl, mimeType, title) for events that have attachments. Only applies when detailed=True. Set this to True when you need to view or access files that have been attached to calendar events, such as meeting documents, presentations, or other shared files. Defaults to False.

    Returns:
        str: A formatted list of events (summary, start and end times, link) within the specified range, or detailed information for a single event if event_id is provided.
    """
    logger.info(
        f"[get_events] Raw parameters - event_id: '{event_id}', time_min: '{time_min}', time_max: '{time_max}', query: '{query}', detailed: {detailed}, include_attachments: {include_attachments}"
    )

    # Handle single event retrieval
    if event_id:
        logger.info(f"[get_events] Retrieving single event with ID: {event_id}")
        event = await asyncio.to_thread(
            lambda: service.events()
            .get(calendarId=calendar_id, eventId=event_id)
            .execute()
        )
        items = [event]
    else:
        # Handle multiple events retrieval with time filtering
        # Ensure time_min and time_max are correctly formatted for the API
        formatted_time_min = _correct_time_format_for_api(time_min, "time_min")
        if formatted_time_min:
            effective_time_min = formatted_time_min
        else:
            utc_now = datetime.datetime.now(datetime.timezone.utc)
            effective_time_min = utc_now.isoformat().replace("+00:00", "Z")
        if time_min is None:
            logger.info(
                f"time_min not provided, defaulting to current UTC time: {effective_time_min}"
            )
        else:
            logger.info(
                f"time_min processing: original='{time_min}', formatted='{formatted_time_min}', effective='{effective_time_min}'"
            )

        effective_time_max = _correct_time_format_for_api(time_max, "time_max")
        if time_max:
            logger.info(
                f"time_max processing: original='{time_max}', formatted='{effective_time_max}'"
            )

        logger.info(
            f"[get_events] Final API parameters - calendarId: '{calendar_id}', timeMin: '{effective_time_min}', timeMax: '{effective_time_max}', maxResults: {max_results}, query: '{query}'"
        )

        # Build the request parameters dynamically
        request_params = {
            "calendarId": calendar_id,
            "timeMin": effective_time_min,
            "timeMax": effective_time_max,
            "maxResults": max_results,
            "singleEvents": True,
            "orderBy": "startTime",
        }

        if query:
            request_params["q"] = query

        events_result = await asyncio.to_thread(
            lambda: service.events().list(**request_params).execute()
        )
        items = events_result.get("items", [])
    if not items:
        if event_id:
            return f"Event with ID '{event_id}' not found in calendar '{calendar_id}' for {user_google_email}."
        else:
            return f"No events found in calendar '{calendar_id}' for {user_google_email} for the specified time range."

    # Handle returning detailed output for a single event when requested
    if event_id and detailed:
        item = items[0]
        summary = item.get("summary", "No Title")
        start = item["start"].get("dateTime", item["start"].get("date"))
        end = item["end"].get("dateTime", item["end"].get("date"))
        link = item.get("htmlLink", "No Link")
        description = item.get("description", "No Description")
        location = item.get("location", "No Location")
        attendees = item.get("attendees", [])
        attendee_emails = (
            ", ".join([a.get("email", "") for a in attendees]) if attendees else "None"
        )
        attendee_details_str = _format_attendee_details(attendees, indent="  ")

        event_details = (
            f"Event Details:\n"
            f"- Title: {summary}\n"
            f"- Starts: {start}\n"
            f"- Ends: {end}\n"
            f"- Description: {description}\n"
            f"- Location: {location}\n"
            f"- Attendees: {attendee_emails}\n"
            f"- Attendee Details: {attendee_details_str}\n"
        )

        if include_attachments:
            attachments = item.get("attachments", [])
            attachment_details_str = _format_attachment_details(
                attachments, indent="  "
            )
            event_details += f"- Attachments: {attachment_details_str}\n"

        event_details += f"- Event ID: {event_id}\n- Link: {link}"
        logger.info(
            f"[get_events] Successfully retrieved detailed event {event_id} for {user_google_email}."
        )
        return event_details

    # Handle multiple events or single event with basic output
    event_details_list = []
    for item in items:
        summary = item.get("summary", "No Title")
        start_time = item["start"].get("dateTime", item["start"].get("date"))
        end_time = item["end"].get("dateTime", item["end"].get("date"))
        link = item.get("htmlLink", "No Link")
        item_event_id = item.get("id", "No ID")

        if detailed:
            # Add detailed information for multiple events
            description = item.get("description", "No Description")
            location = item.get("location", "No Location")
            attendees = item.get("attendees", [])
            attendee_emails = (
                ", ".join([a.get("email", "") for a in attendees])
                if attendees
                else "None"
            )
            attendee_details_str = _format_attendee_details(attendees, indent="    ")

            event_detail_parts = (
                f'- "{summary}" (Starts: {start_time}, Ends: {end_time})\n'
                f"  Description: {description}\n"
                f"  Location: {location}\n"
                f"  Attendees: {attendee_emails}\n"
                f"  Attendee Details: {attendee_details_str}\n"
            )

            if include_attachments:
                attachments = item.get("attachments", [])
                attachment_details_str = _format_attachment_details(
                    attachments, indent="    "
                )
                event_detail_parts += f"  Attachments: {attachment_details_str}\n"

            event_detail_parts += f"  ID: {item_event_id} | Link: {link}"
            event_details_list.append(event_detail_parts)
        else:
            # Basic output format
            event_details_list.append(
                f'- "{summary}" (Starts: {start_time}, Ends: {end_time}) ID: {item_event_id} | Link: {link}'
            )

    if event_id:
        # Single event basic output
        text_output = (
            f"Successfully retrieved event from calendar '{calendar_id}' for {user_google_email}:\n"
            + "\n".join(event_details_list)
        )
    else:
        # Multiple events output
        text_output = (
            f"Successfully retrieved {len(items)} events from calendar '{calendar_id}' for {user_google_email}:\n"
            + "\n".join(event_details_list)
        )

    logger.info(f"Successfully retrieved {len(items)} events for {user_google_email}.")
    return text_output


@server.tool()
@handle_http_errors("create_event", service_type="calendar")
@require_google_service("calendar", "calendar_events")
async def create_event(
    service,
    user_google_email: str,
    summary: str,
    start_time: str,
    end_time: str,
    calendar_id: str = "primary",
    description: Optional[str] = None,
    location: Optional[str] = None,
    attendees: Optional[List[str]] = None,
    timezone: Optional[str] = None,
    attachments: Optional[List[str]] = None,
    add_google_meet: bool = False,
    reminders: Optional[Union[str, List[Dict[str, Any]]]] = None,
    use_default_reminders: bool = True,
    transparency: Optional[str] = None,
    recurrence: Optional[List[str]] = None,
    send_updates: Optional[str] = "all",
    visibility: Optional[str] = None,
    zoom_link: Optional[str] = None,
) -> str:
    """
    Creates a new event.

    Args:
        user_google_email (str): The user's Google email address. Required.
        summary (str): Event title.
        start_time (str): Start time (RFC3339, e.g., "2023-10-27T10:00:00-07:00" or "2023-10-27" for all-day).
        end_time (str): End time (RFC3339, e.g., "2023-10-27T11:00:00-07:00" or "2023-10-28" for all-day).
        calendar_id (str): Calendar ID (default: 'primary').
        description (Optional[str]): Event description.
        location (Optional[str]): Event location.
        attendees (Optional[List[str]]): Attendee email addresses.
        timezone (Optional[str]): Timezone (e.g., "America/New_York").
        attachments (Optional[List[str]]): List of Google Drive file URLs or IDs to attach to the event.
        add_google_meet (bool): Whether to add a Google Meet video conference to the event. Defaults to False.
        reminders (Optional[Union[str, List[Dict[str, Any]]]]): JSON string or list of reminder objects. Each should have 'method' ("popup" or "email") and 'minutes' (0-40320). Max 5 reminders. Example: '[{"method": "popup", "minutes": 15}]' or [{"method": "popup", "minutes": 15}]
        use_default_reminders (bool): Whether to use calendar's default reminders. If False, uses custom reminders. Defaults to True.
        transparency (Optional[str]): Event transparency for busy/free status. "opaque" shows as Busy (default), "transparent" shows as Available/Free. Defaults to None (uses Google Calendar default).
        recurrence (Optional[List[str]]): List of RRULE strings for recurring events. Common examples:
            - Weekly meeting: ["RRULE:FREQ=WEEKLY"]
            - Weekly on specific days: ["RRULE:FREQ=WEEKLY;BYDAY=MO,WE,FR"]
            - Bi-weekly meeting: ["RRULE:FREQ=WEEKLY;INTERVAL=2"]
            - Daily standup (weekdays): ["RRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR"]
            - Monthly on specific date: ["RRULE:FREQ=MONTHLY;BYMONTHDAY=15"]
            - Monthly on last Friday: ["RRULE:FREQ=MONTHLY;BYDAY=-1FR"]
            - Quarterly meeting: ["RRULE:FREQ=MONTHLY;INTERVAL=3"]
            - Limited occurrences: ["RRULE:FREQ=WEEKLY;COUNT=10"]
            - Until specific date: ["RRULE:FREQ=WEEKLY;UNTIL=20240630T235959Z"]
            - Annual event: ["RRULE:FREQ=YEARLY"]
        send_updates (Optional[str]): Whether to send update notifications to attendees. Valid values: "all" (send to all attendees), "externalOnly" (only external attendees), "none" (don't send). Defaults to "all".
        visibility (Optional[str]): Event visibility. Valid values: "default" (use calendar default), "public" (visible to everyone), "private" (only attendees see details), "confidential" (alias for private). Defaults to None (uses calendar default).
        zoom_link (Optional[str]): Zoom meeting link to add to the event. The link will be added to the event location and description. Provide your Zoom PMI link or a meeting-specific URL (e.g., "https://zoom.us/j/1234567890"). Note: If both `location` and `zoom_link` are provided, `zoom_link` takes precedence and overwrites `location`.

    Returns:
        str: Confirmation message of the successful event creation with event link.
    """
    logger.info(
        f"[create_event] Invoked. Email: '{user_google_email}', Summary: {summary}"
    )
    logger.info(f"[create_event] Incoming attachments param: {attachments}")
    # If attachments value is a string, split by comma and strip whitespace
    if attachments and isinstance(attachments, str):
        attachments = [a.strip() for a in attachments.split(",") if a.strip()]
        logger.info(
            f"[create_event] Parsed attachments list from string: {attachments}"
        )
    
    # Handle zoom_link - validate and prepare to set location/description
    effective_location = location
    effective_description = description
    if zoom_link:
        if not zoom_link.startswith("https://") or "zoom" not in zoom_link.lower():
            logger.warning(
                f"[create_event] zoom_link doesn't look like a Zoom URL: {zoom_link}"
            )
        # Set zoom_link as location (overwrites location if both provided)
        if location:
            logger.warning(
                f"[create_event] zoom_link is overwriting location. "
                f"Original location '{location}' will be replaced with zoom_link."
            )
        effective_location = zoom_link
        # Add zoom link to description
        if effective_description:
            effective_description = f"{effective_description}\n\nZoom: {zoom_link}"
        else:
            effective_description = f"Zoom: {zoom_link}"
        logger.info(f"[create_event] Added Zoom link to event: {zoom_link}")
    
    event_body: Dict[str, Any] = {
        "summary": summary,
        "start": (
            {"date": start_time} if "T" not in start_time else {"dateTime": start_time}
        ),
        "end": ({"date": end_time} if "T" not in end_time else {"dateTime": end_time}),
    }
    if effective_location:
        event_body["location"] = effective_location
    if effective_description:
        event_body["description"] = effective_description
    if timezone:
        if "dateTime" in event_body["start"]:
            event_body["start"]["timeZone"] = timezone
        if "dateTime" in event_body["end"]:
            event_body["end"]["timeZone"] = timezone
    if attendees:
        event_body["attendees"] = [{"email": email} for email in attendees]

    if recurrence:
        event_body["recurrence"] = recurrence
        logger.info(f"[create_event] Adding recurrence rules: {recurrence}")

    # Handle reminders
    if reminders is not None or not use_default_reminders:
        # If custom reminders are provided, automatically disable default reminders
        effective_use_default = use_default_reminders and reminders is None

        reminder_data = {"useDefault": effective_use_default}
        if reminders is not None:
            validated_reminders = _parse_reminders_json(reminders, "create_event")
            if validated_reminders:
                reminder_data["overrides"] = validated_reminders
                logger.info(
                    f"[create_event] Added {len(validated_reminders)} custom reminders"
                )
                if use_default_reminders:
                    logger.info(
                        "[create_event] Custom reminders provided - disabling default reminders"
                    )

        event_body["reminders"] = reminder_data

    # Handle transparency validation
    _apply_transparency_if_valid(event_body, transparency, "create_event")

    # Handle visibility validation
    _apply_visibility_if_valid(event_body, visibility, "create_event")

    # Validate send_updates parameter
    validated_send_updates = _validate_send_updates(send_updates, "create_event")

    if add_google_meet:
        request_id = str(uuid.uuid4())
        event_body["conferenceData"] = {
            "createRequest": {
                "requestId": request_id,
                "conferenceSolutionKey": {"type": "hangoutsMeet"},
            }
        }
        logger.info(
            f"[create_event] Adding Google Meet conference with request ID: {request_id}"
        )

    if attachments:
        # Accept both file URLs and file IDs. If a URL, extract the fileId.
        event_body["attachments"] = []
        drive_service = None
        try:
            drive_service = service._http and build("drive", "v3", http=service._http)
        except Exception as e:
            logger.warning(f"Could not build Drive service for MIME type lookup: {e}")
        for att in attachments:
            file_id = None
            if att.startswith("https://"):
                # Match /d/<id>, /file/d/<id>, ?id=<id>
                match = re.search(r"(?:/d/|/file/d/|id=)([\w-]+)", att)
                file_id = match.group(1) if match else None
                logger.info(
                    f"[create_event] Extracted file_id '{file_id}' from attachment URL '{att}'"
                )
            else:
                file_id = att
                logger.info(
                    f"[create_event] Using direct file_id '{file_id}' for attachment"
                )
            if file_id:
                file_url = f"https://drive.google.com/open?id={file_id}"
                mime_type = "application/vnd.google-apps.drive-sdk"
                title = "Drive Attachment"
                # Try to get the actual MIME type and filename from Drive
                if drive_service:
                    try:
                        file_metadata = await asyncio.to_thread(
                            lambda: drive_service.files()
                            .get(
                                fileId=file_id,
                                fields="mimeType,name",
                                supportsAllDrives=True,
                            )
                            .execute()
                        )
                        mime_type = file_metadata.get("mimeType", mime_type)
                        filename = file_metadata.get("name")
                        if filename:
                            title = filename
                            logger.info(
                                f"[create_event] Using filename '{filename}' as attachment title"
                            )
                        else:
                            logger.info(
                                "[create_event] No filename found, using generic title"
                            )
                    except Exception as e:
                        logger.warning(
                            f"Could not fetch metadata for file {file_id}: {e}"
                        )
                event_body["attachments"].append(
                    {
                        "fileUrl": file_url,
                        "title": title,
                        "mimeType": mime_type,
                    }
                )
        created_event = await asyncio.to_thread(
            lambda: service.events()
            .insert(
                calendarId=calendar_id,
                body=event_body,
                supportsAttachments=True,
                conferenceDataVersion=1 if add_google_meet else 0,
                sendUpdates=validated_send_updates,
            )
            .execute()
        )
    else:
        created_event = await asyncio.to_thread(
            lambda: service.events()
            .insert(
                calendarId=calendar_id,
                body=event_body,
                conferenceDataVersion=1 if add_google_meet else 0,
                sendUpdates=validated_send_updates,
            )
            .execute()
        )
    link = created_event.get("htmlLink", "No link available")
    confirmation_message = f"Successfully created event '{created_event.get('summary', summary)}' for {user_google_email}. Link: {link}"

    # Add Google Meet information if conference was created
    if add_google_meet and "conferenceData" in created_event:
        conference_data = created_event["conferenceData"]
        if "entryPoints" in conference_data:
            for entry_point in conference_data["entryPoints"]:
                if entry_point.get("entryPointType") == "video":
                    meet_link = entry_point.get("uri", "")
                    if meet_link:
                        confirmation_message += f" Google Meet: {meet_link}"
                        break

    logger.info(
        f"Event created successfully for {user_google_email}. ID: {created_event.get('id')}, Link: {link}"
    )
    return confirmation_message


@server.tool()
@handle_http_errors("modify_event", service_type="calendar")
@require_google_service("calendar", "calendar_events")
async def modify_event(
    service,
    user_google_email: str,
    event_id: str,
    calendar_id: str = "primary",
    summary: Optional[str] = None,
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
    description: Optional[str] = None,
    location: Optional[str] = None,
    attendees: Optional[List[str]] = None,
    timezone: Optional[str] = None,
    add_google_meet: Optional[bool] = None,
    reminders: Optional[Union[str, List[Dict[str, Any]]]] = None,
    use_default_reminders: Optional[bool] = None,
    transparency: Optional[str] = None,
    send_updates: Optional[str] = "all",
    visibility: Optional[str] = None,
) -> str:
    """
    Modifies an existing event.

    Args:
        user_google_email (str): The user's Google email address. Required.
        event_id (str): The ID of the event to modify.
        calendar_id (str): Calendar ID (default: 'primary').
        summary (Optional[str]): New event title.
        start_time (Optional[str]): New start time (RFC3339, e.g., "2023-10-27T10:00:00-07:00" or "2023-10-27" for all-day).
        end_time (Optional[str]): New end time (RFC3339, e.g., "2023-10-27T11:00:00-07:00" or "2023-10-28" for all-day).
        description (Optional[str]): New event description.
        location (Optional[str]): New event location.
        attendees (Optional[List[str]]): New attendee email addresses.
        timezone (Optional[str]): New timezone (e.g., "America/New_York").
        add_google_meet (Optional[bool]): Whether to add or remove Google Meet video conference. If True, adds Google Meet; if False, removes it; if None, leaves unchanged.
        reminders (Optional[Union[str, List[Dict[str, Any]]]]): JSON string or list of reminder objects to replace existing reminders. Each should have 'method' ("popup" or "email") and 'minutes' (0-40320). Max 5 reminders. Example: '[{"method": "popup", "minutes": 15}]' or [{"method": "popup", "minutes": 15}]
        use_default_reminders (Optional[bool]): Whether to use calendar's default reminders. If specified, overrides current reminder settings.
        transparency (Optional[str]): Event transparency for busy/free status. "opaque" shows as Busy, "transparent" shows as Available/Free. If None, preserves existing transparency setting.
        send_updates (Optional[str]): Whether to send update notifications to attendees. Valid values: "all" (send to all attendees), "externalOnly" (only external attendees), "none" (don't send). Defaults to "all".
        visibility (Optional[str]): Event visibility. Valid values: "default" (use calendar default), "public" (visible to everyone), "private" (only attendees see details), "confidential" (alias for private). If None, preserves existing visibility.

    Returns:
        str: Confirmation message of the successful event modification with event link.
    """
    logger.info(
        f"[modify_event] Invoked. Email: '{user_google_email}', Event ID: {event_id}"
    )

    # Build the event body with only the fields that are provided
    event_body: Dict[str, Any] = {}
    if summary is not None:
        event_body["summary"] = summary
    if start_time is not None:
        event_body["start"] = (
            {"date": start_time} if "T" not in start_time else {"dateTime": start_time}
        )
        if timezone is not None and "dateTime" in event_body["start"]:
            event_body["start"]["timeZone"] = timezone
    if end_time is not None:
        event_body["end"] = (
            {"date": end_time} if "T" not in end_time else {"dateTime": end_time}
        )
        if timezone is not None and "dateTime" in event_body["end"]:
            event_body["end"]["timeZone"] = timezone
    if description is not None:
        event_body["description"] = description
    if location is not None:
        event_body["location"] = location
    if attendees is not None:
        event_body["attendees"] = [{"email": email} for email in attendees]

    # Handle reminders
    if reminders is not None or use_default_reminders is not None:
        reminder_data = {}
        if use_default_reminders is not None:
            reminder_data["useDefault"] = use_default_reminders
        else:
            # Preserve existing event's useDefault value if not explicitly specified
            try:
                existing_event = (
                    service.events()
                    .get(calendarId=calendar_id, eventId=event_id)
                    .execute()
                )
                reminder_data["useDefault"] = existing_event.get("reminders", {}).get(
                    "useDefault", True
                )
            except Exception as e:
                logger.warning(
                    f"[modify_event] Could not fetch existing event for reminders: {e}"
                )
                reminder_data["useDefault"] = (
                    True  # Fallback to True if unable to fetch
                )

        # If custom reminders are provided, automatically disable default reminders
        if reminders is not None:
            if reminder_data.get("useDefault", False):
                reminder_data["useDefault"] = False
                logger.info(
                    "[modify_event] Custom reminders provided - disabling default reminders"
                )

            validated_reminders = _parse_reminders_json(reminders, "modify_event")
            if reminders and not validated_reminders:
                logger.warning(
                    "[modify_event] Reminders provided but failed validation. No custom reminders will be set."
                )
            elif validated_reminders:
                reminder_data["overrides"] = validated_reminders
                logger.info(
                    f"[modify_event] Updated reminders with {len(validated_reminders)} custom reminders"
                )

        event_body["reminders"] = reminder_data

    # Handle transparency validation
    _apply_transparency_if_valid(event_body, transparency, "modify_event")

    # Handle visibility - will be applied after fetching existing event to allow preservation
    # Validate send_updates parameter
    validated_send_updates = _validate_send_updates(send_updates, "modify_event")

    if timezone is not None and "start" not in event_body and "end" not in event_body:
        # If timezone is provided but start/end times are not, we need to fetch the existing event
        # to apply the timezone correctly. This is a simplification; a full implementation
        # might handle this more robustly or require start/end with timezone.
        # For now, we'll log a warning and skip applying timezone if start/end are missing.
        logger.warning(
            "[modify_event] Timezone provided but start_time and end_time are missing. Timezone will not be applied unless start/end times are also provided."
        )

    if not event_body:
        message = "No fields provided to modify the event."
        logger.warning(f"[modify_event] {message}")
        raise Exception(message)

    # Log the event ID for debugging
    logger.info(
        f"[modify_event] Attempting to update event with ID: '{event_id}' in calendar '{calendar_id}'"
    )

    # Get the existing event to preserve fields that aren't being updated
    try:
        existing_event = await asyncio.to_thread(
            lambda: service.events()
            .get(calendarId=calendar_id, eventId=event_id)
            .execute()
        )
        logger.info(
            "[modify_event] Successfully retrieved existing event before update"
        )

        # Preserve existing fields if not provided in the update
        _preserve_existing_fields(
            event_body,
            existing_event,
            {
                "summary": summary,
                "description": description,
                "location": location,
                "attendees": attendees,
            },
        )

        # Handle visibility - apply new value or preserve existing
        if visibility is not None:
            _apply_visibility_if_valid(event_body, visibility, "modify_event")
        elif "visibility" in existing_event:
            event_body["visibility"] = existing_event["visibility"]
            logger.info("[modify_event] Preserving existing visibility")

        # Preserve start/end times if not provided (required by Google Calendar API)
        if "start" not in event_body and "start" in existing_event:
            event_body["start"] = existing_event["start"]
            logger.info("[modify_event] Preserving existing start time")
        if "end" not in event_body and "end" in existing_event:
            event_body["end"] = existing_event["end"]
            logger.info("[modify_event] Preserving existing end time")

        # Handle Google Meet conference data
        if add_google_meet is not None:
            if add_google_meet:
                # Add Google Meet
                request_id = str(uuid.uuid4())
                event_body["conferenceData"] = {
                    "createRequest": {
                        "requestId": request_id,
                        "conferenceSolutionKey": {"type": "hangoutsMeet"},
                    }
                }
                logger.info(
                    f"[modify_event] Adding Google Meet conference with request ID: {request_id}"
                )
            else:
                # Remove Google Meet by setting conferenceData to empty
                event_body["conferenceData"] = {}
                logger.info("[modify_event] Removing Google Meet conference")
        elif "conferenceData" in existing_event:
            # Preserve existing conference data if not specified
            event_body["conferenceData"] = existing_event["conferenceData"]
            logger.info("[modify_event] Preserving existing conference data")

    except HttpError as get_error:
        if get_error.resp.status == 404:
            logger.error(
                f"[modify_event] Event not found during pre-update verification: {get_error}"
            )
            message = f"Event not found during verification. The event with ID '{event_id}' could not be found in calendar '{calendar_id}'. This may be due to incorrect ID format or the event no longer exists."
            raise Exception(message)
        else:
            logger.warning(
                f"[modify_event] Error during pre-update verification, but proceeding with update: {get_error}"
            )

    # Proceed with the update
    updated_event = await asyncio.to_thread(
        lambda: service.events()
        .update(
            calendarId=calendar_id,
            eventId=event_id,
            body=event_body,
            conferenceDataVersion=1,
            sendUpdates=validated_send_updates,
        )
        .execute()
    )

    link = updated_event.get("htmlLink", "No link available")
    confirmation_message = f"Successfully modified event '{updated_event.get('summary', summary)}' (ID: {event_id}) for {user_google_email}. Link: {link}"

    # Add Google Meet information if conference was added
    if add_google_meet is True and "conferenceData" in updated_event:
        conference_data = updated_event["conferenceData"]
        if "entryPoints" in conference_data:
            for entry_point in conference_data["entryPoints"]:
                if entry_point.get("entryPointType") == "video":
                    meet_link = entry_point.get("uri", "")
                    if meet_link:
                        confirmation_message += f" Google Meet: {meet_link}"
                        break
    elif add_google_meet is False:
        confirmation_message += " (Google Meet removed)"

    logger.info(
        f"Event modified successfully for {user_google_email}. ID: {updated_event.get('id')}, Link: {link}"
    )
    return confirmation_message


@server.tool()
@handle_http_errors("delete_event", service_type="calendar")
@require_google_service("calendar", "calendar_events")
async def delete_event(
    service, user_google_email: str, event_id: str, calendar_id: str = "primary"
) -> str:
    """
    Deletes an existing event.

    Args:
        user_google_email (str): The user's Google email address. Required.
        event_id (str): The ID of the event to delete.
        calendar_id (str): Calendar ID (default: 'primary').

    Returns:
        str: Confirmation message of the successful event deletion.
    """
    logger.info(
        f"[delete_event] Invoked. Email: '{user_google_email}', Event ID: {event_id}"
    )

    # Log the event ID for debugging
    logger.info(
        f"[delete_event] Attempting to delete event with ID: '{event_id}' in calendar '{calendar_id}'"
    )

    # Try to get the event first to verify it exists
    try:
        await asyncio.to_thread(
            lambda: service.events()
            .get(calendarId=calendar_id, eventId=event_id)
            .execute()
        )
        logger.info("[delete_event] Successfully verified event exists before deletion")
    except HttpError as get_error:
        if get_error.resp.status == 404:
            logger.error(
                f"[delete_event] Event not found during pre-delete verification: {get_error}"
            )
            message = f"Event not found during verification. The event with ID '{event_id}' could not be found in calendar '{calendar_id}'. This may be due to incorrect ID format or the event no longer exists."
            raise Exception(message)
        else:
            logger.warning(
                f"[delete_event] Error during pre-delete verification, but proceeding with deletion: {get_error}"
            )

    # Proceed with the deletion
    await asyncio.to_thread(
        lambda: service.events()
        .delete(calendarId=calendar_id, eventId=event_id)
        .execute()
    )

    confirmation_message = f"Successfully deleted event (ID: {event_id}) from calendar '{calendar_id}' for {user_google_email}."
    logger.info(f"Event deleted successfully for {user_google_email}. ID: {event_id}")
    return confirmation_message


@server.tool()
@handle_http_errors("get_events_times_only", is_read_only=True, service_type="calendar")
@require_google_service("calendar", "calendar_read")
async def get_events_times_only(
    service,
    user_google_email: str,
    calendar_id: str = "primary",
    time_min: Optional[str] = None,
    time_max: Optional[str] = None,
    max_results: int = 25,
) -> str:
    """
    Retrieves only the start and end times of events from a specified Google Calendar within a given time range.
    Events are grouped by weekday and de-duplicated by title and time (marking recurring events).

    Args:
        user_google_email (str): The user's Google email address. Required.
        calendar_id (str): The ID of the calendar to query. Use 'primary' for the user's primary calendar. Defaults to 'primary'.
        time_min (Optional[str]): The start of the time range (inclusive) in RFC3339 format (e.g., '2024-05-12T10:00:00Z' or '2024-05-12'). If omitted, defaults to the current time.
        time_max (Optional[str]): The end of the time range (exclusive) in RFC3339 format. If omitted, events starting from `time_min` onwards are considered (up to `max_results`).
        max_results (int): The maximum number of events to return. Defaults to 25.

    Returns:
        str: A formatted list of event times grouped by weekday with recurring events marked.
    """
    logger.info(
        f"[get_events_times_only] Raw time parameters - time_min: '{time_min}', time_max: '{time_max}'"
    )

    # Ensure time_min and time_max are correctly formatted for the API
    formatted_time_min = _correct_time_format_for_api(time_min, "time_min")
    if formatted_time_min:
        effective_time_min = formatted_time_min
    else:
        utc_now = datetime.datetime.now(datetime.timezone.utc)
        effective_time_min = utc_now.isoformat().replace("+00:00", "Z")
    if time_min is None:
        logger.info(
            f"time_min not provided, defaulting to current UTC time: {effective_time_min}"
        )
    else:
        logger.info(
            f"time_min processing: original='{time_min}', formatted='{formatted_time_min}', effective='{effective_time_min}'"
        )

    effective_time_max = _correct_time_format_for_api(time_max, "time_max")
    if time_max:
        logger.info(
            f"time_max processing: original='{time_max}', formatted='{effective_time_max}'"
        )

    logger.info(
        f"[get_events_times_only] Final API parameters - calendarId: '{calendar_id}', timeMin: '{effective_time_min}', timeMax: '{effective_time_max}', maxResults: {max_results}"
    )

    events_result = await asyncio.to_thread(
        lambda: service.events()
        .list(
            calendarId=calendar_id,
            timeMin=effective_time_min,
            timeMax=effective_time_max,
            maxResults=max_results,
            singleEvents=True,
            orderBy="startTime",
        )
        .execute()
    )
    items = events_result.get("items", [])
    if not items:
        return f"No events found in calendar '{calendar_id}' for {user_google_email} for the specified time range."

    # Group events by weekday
    weekday_events: Dict[str, Dict[str, int]] = {
        "Monday": {},
        "Tuesday": {},
        "Wednesday": {},
        "Thursday": {},
        "Friday": {},
        "Saturday": {},
        "Sunday": {},
    }

    for item in items:
        summary = item.get("summary", "No Title")
        start_str = item["start"].get("dateTime", item["start"].get("date"))
        end_str = item["end"].get("dateTime", item["end"].get("date"))

        # Parse datetime to get weekday and time components
        try:
            # Handle both datetime and date-only formats
            if "T" in start_str:
                start_dt = datetime.datetime.fromisoformat(
                    start_str.replace("Z", "+00:00")
                )
                end_dt = datetime.datetime.fromisoformat(end_str.replace("Z", "+00:00"))
                start_time = start_dt.strftime("%H:%M")
                end_time = end_dt.strftime("%H:%M")
            else:
                # All-day events
                start_dt = datetime.datetime.strptime(start_str, "%Y-%m-%d")
                start_time = "All day"
                end_time = ""

            weekday_name = start_dt.strftime("%A")
            event_key = (
                f"{summary} ({start_time}-{end_time})"
                if end_time
                else f"{summary} ({start_time})"
            )

            # Track occurrences for de-duplication
            if event_key in weekday_events[weekday_name]:
                weekday_events[weekday_name][event_key] += 1
            else:
                weekday_events[weekday_name][event_key] = 1

        except (ValueError, KeyError) as e:
            logger.warning(f"[get_events_times_only] Could not parse event time: {e}")
            continue

    # Format output
    output_lines = [f"Events for {user_google_email} (calendar: {calendar_id}):"]
    for weekday in [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
    ]:
        events = weekday_events[weekday]
        if events:
            output_lines.append(f"\n{weekday}:")
            for event_key, count in events.items():
                if count > 1:
                    output_lines.append(
                        f"  - {event_key} (recurring, {count} occurrences)"
                    )
                else:
                    output_lines.append(f"  - {event_key}")

    if len(output_lines) == 1:
        return f"No events found in calendar '{calendar_id}' for {user_google_email} for the specified time range."

    logger.info(
        f"[get_events_times_only] Successfully retrieved events for {user_google_email}"
    )
    return "\n".join(output_lines)


# Response status mapping for respond_to_event
RESPONSE_STATUS_MAP = {
    "accept": "accepted",
    "decline": "declined",
    "tentative": "tentative",
}


@server.tool()
@handle_http_errors("respond_to_event", service_type="calendar")
@require_google_service("calendar", "calendar_events")
async def respond_to_event(
    service,
    user_google_email: str,
    event_id: str,
    response: str,
    calendar_id: str = "primary",
    comment: Optional[str] = None,
    send_updates: Optional[str] = "all",
) -> str:
    """
    Respond to a calendar event invitation (RSVP).

    Use this to accept, decline, or tentatively accept meeting invitations.

    Args:
        user_google_email (str): The user's Google email address. Required.
        event_id (str): The ID of the event to respond to.
        response (str): Your response to the invitation. Valid values: "accept", "decline", "tentative".
        calendar_id (str): Calendar ID (default: 'primary').
        comment (Optional[str]): Optional message to include with your response (visible to organizer).
        send_updates (Optional[str]): Whether to send update notifications. Valid values: "all", "externalOnly", "none". Defaults to "all".

    Returns:
        str: Confirmation message of the successful response.
    """
    logger.info(
        f"[respond_to_event] Invoked. Email: '{user_google_email}', Event ID: {event_id}, Response: {response}"
    )

    # Validate response value
    if response not in RESPONSE_STATUS_MAP:
        valid_responses = list(RESPONSE_STATUS_MAP.keys())
        raise ValueError(
            f"Invalid response value '{response}'. Must be one of: {valid_responses}"
        )

    response_status = RESPONSE_STATUS_MAP[response]
    validated_send_updates = _validate_send_updates(send_updates, "respond_to_event")

    # Fetch the existing event to get the attendees list
    event = await asyncio.to_thread(
        lambda: service.events()
        .get(calendarId=calendar_id, eventId=event_id)
        .execute()
    )

    attendees = event.get("attendees", [])
    if not attendees:
        raise ValueError(
            f"Event {event_id} has no attendees. Cannot respond to an event without attendees."
        )

    # Find and update the user's attendee entry
    user_found = False
    for attendee in attendees:
        if attendee.get("email", "").lower() == user_google_email.lower():
            attendee["responseStatus"] = response_status
            if comment:
                attendee["comment"] = comment
            user_found = True
            break

    if not user_found:
        raise ValueError(
            f"User {user_google_email} is not an attendee of event {event_id}. "
            f"You can only respond to events you're invited to."
        )

    # Patch the event with updated attendees
    patch_body = {"attendees": attendees}
    updated_event = await asyncio.to_thread(
        lambda: service.events()
        .patch(
            calendarId=calendar_id,
            eventId=event_id,
            body=patch_body,
            sendUpdates=validated_send_updates,
        )
        .execute()
    )

    event_summary = updated_event.get("summary", "Untitled Event")
    confirmation_message = (
        f"Successfully responded '{response}' to event '{event_summary}' "
        f"(ID: {event_id}) for {user_google_email}."
    )
    if comment:
        confirmation_message += f" Comment: {comment}"

    logger.info(f"[respond_to_event] {confirmation_message}")
    return confirmation_message


def _format_busy_period(start: str, end: str) -> str:
    """Format a single busy period for display."""
    try:
        start_dt = datetime.datetime.fromisoformat(start.replace("Z", "+00:00"))
        end_dt = datetime.datetime.fromisoformat(end.replace("Z", "+00:00"))
        
        start_time = start_dt.strftime("%H:%M")
        end_time = end_dt.strftime("%H:%M")
        
        # Calculate duration
        duration = end_dt - start_dt
        hours = duration.total_seconds() / 3600
        if hours >= 1:
            duration_str = f"{hours:.1f} hours" if hours != int(hours) else f"{int(hours)} hour{'s' if hours > 1 else ''}"
        else:
            minutes = duration.total_seconds() / 60
            duration_str = f"{int(minutes)} minutes"
        
        return f"Busy: {start_time}-{end_time} ({duration_str})"
    except Exception:
        return f"Busy: {start} - {end}"


@server.tool()
@handle_http_errors("get_free_busy", is_read_only=True, service_type="calendar")
@require_google_service("calendar", "calendar_read")
async def get_free_busy(
    service,
    user_google_email: str,
    emails: List[str],
    time_min: str,
    time_max: str,
    group_expansion_max: int = 100,
) -> str:
    """
    Check availability (free/busy status) for one or more users.

    Use this to see when people are busy before scheduling a meeting.
    Note: This only shows busy/free status, not meeting details (for privacy).

    Args:
        user_google_email (str): The user's Google email address. Required.
        emails (List[str]): List of email addresses to check availability for.
        time_min (str): Start of time range to check (RFC3339, e.g., "2025-01-15T00:00:00Z").
        time_max (str): End of time range to check (RFC3339, e.g., "2025-01-16T00:00:00Z").
        group_expansion_max (int): Maximum number of calendars to return for a group (default: 100).

    Returns:
        str: Formatted free/busy information for each requested user.
    """
    logger.info(
        f"[get_free_busy] Invoked. Email: '{user_google_email}', "
        f"Checking {len(emails)} calendars from {time_min} to {time_max}"
    )

    # Format times for API
    formatted_time_min = _correct_time_format_for_api(time_min, "time_min")
    formatted_time_max = _correct_time_format_for_api(time_max, "time_max")

    # Validate time range
    if formatted_time_min and formatted_time_max and formatted_time_min >= formatted_time_max:
        raise ValueError(
            f"time_min ({time_min}) must be before time_max ({time_max})"
        )

    # Build request body
    request_body = {
        "timeMin": formatted_time_min,
        "timeMax": formatted_time_max,
        "items": [{"id": email} for email in emails],
        "groupExpansionMax": group_expansion_max,
    }

    # Make the free/busy query
    result = await asyncio.to_thread(
        lambda: service.freebusy().query(body=request_body).execute()
    )

    # Parse and format the response
    calendars = result.get("calendars", {})
    
    # Build output
    output_lines = [
        f"Free/Busy Status ({formatted_time_min[:10]} to {formatted_time_max[:10]}):",
        ""
    ]

    for email in emails:
        calendar_data = calendars.get(email, {})
        busy_periods = calendar_data.get("busy", [])
        errors = calendar_data.get("errors", [])

        output_lines.append(f"{email}:")
        
        if errors:
            for error in errors:
                output_lines.append(f"  ⚠️ Error: {error.get('reason', 'Unknown error')}")
        elif not busy_periods:
            output_lines.append("  ✓ Free (no busy periods)")
        else:
            for period in busy_periods:
                formatted = _format_busy_period(period["start"], period["end"])
                output_lines.append(f"  - {formatted}")
        
        output_lines.append("")

    logger.info(
        f"[get_free_busy] Successfully retrieved free/busy for {len(emails)} calendars"
    )
    return "\n".join(output_lines).strip()


def _merge_busy_intervals(intervals: List[tuple]) -> List[tuple]:
    """Merge overlapping busy intervals into consolidated periods."""
    if not intervals:
        return []
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    merged = [sorted_intervals[0]]
    
    for start, end in sorted_intervals[1:]:
        last_start, last_end = merged[-1]
        if start <= last_end:
            # Overlapping or adjacent, extend the end
            merged[-1] = (last_start, max(last_end, end))
        else:
            # Non-overlapping, add new interval
            merged.append((start, end))
    
    return merged


def _find_free_slots_in_day(
    busy_intervals: List[tuple],
    day_start: datetime.datetime,
    day_end: datetime.datetime,
    min_duration_minutes: int,
    working_hours_only: bool,
    working_start: str,
    working_end: str,
    timezone: Optional[str] = None,
) -> List[tuple]:
    """Find free slots within a single day.
    
    Args:
        busy_intervals: List of (start, end) datetime tuples representing busy periods
        day_start: Start of the day (in UTC if timezone is provided)
        day_end: End of the day (in UTC if timezone is provided)
        min_duration_minutes: Minimum slot duration required
        working_hours_only: Whether to filter to working hours
        working_start: Working hours start in HH:MM format
        working_end: Working hours end in HH:MM format
        timezone: IANA timezone string (e.g., "America/Chicago") for working hours
    """
    free_slots = []
    
    # Apply working hours filter
    if working_hours_only:
        working_start_time = datetime.datetime.strptime(working_start, "%H:%M").time()
        working_end_time = datetime.datetime.strptime(working_end, "%H:%M").time()
        
        # If timezone is provided, convert working hours to UTC
        if timezone:
            try:
                from zoneinfo import ZoneInfo
                tz = ZoneInfo(timezone)
                
                # Get the date in the target timezone
                # day_start is in UTC, convert to target timezone to get the local date
                local_day = day_start.astimezone(tz).date()
                
                # Create working hours start/end in the target timezone
                working_start_local = datetime.datetime.combine(
                    local_day, working_start_time, tzinfo=tz
                )
                working_end_local = datetime.datetime.combine(
                    local_day, working_end_time, tzinfo=tz
                )
                
                # Convert to UTC for comparison with busy intervals
                day_start = working_start_local.astimezone(datetime.timezone.utc)
                day_end = working_end_local.astimezone(datetime.timezone.utc)
                
            except Exception as e:
                logger.warning(
                    f"[_find_free_slots_in_day] Could not apply timezone '{timezone}': {e}. "
                    "Falling back to UTC working hours."
                )
                # Fallback to old behavior
                day_start = day_start.replace(
                    hour=working_start_time.hour,
                    minute=working_start_time.minute,
                    second=0,
                    microsecond=0,
                )
                day_end = day_end.replace(
                    hour=working_end_time.hour,
                    minute=working_end_time.minute,
                    second=0,
                    microsecond=0,
                )
        else:
            # No timezone provided, apply working hours directly (legacy behavior)
            day_start = day_start.replace(
                hour=working_start_time.hour,
                minute=working_start_time.minute,
                second=0,
                microsecond=0,
            )
            day_end = day_end.replace(
                hour=working_end_time.hour,
                minute=working_end_time.minute,
                second=0,
                microsecond=0,
            )
    
    # Find free slots by inverting busy intervals
    current_time = day_start
    min_duration = datetime.timedelta(minutes=min_duration_minutes)
    
    for busy_start, busy_end in sorted(busy_intervals):
        if current_time < busy_start:
            slot_duration = busy_start - current_time
            if slot_duration >= min_duration:
                free_slots.append((current_time, busy_start))
        current_time = max(current_time, busy_end)
    
    # Check for free time after last busy period
    if current_time < day_end:
        slot_duration = day_end - current_time
        if slot_duration >= min_duration:
            free_slots.append((current_time, day_end))
    
    return free_slots


@server.tool()
@handle_http_errors("find_available_slots", is_read_only=True, service_type="calendar")
@require_google_service("calendar", "calendar_read")
async def find_available_slots(
    service,
    user_google_email: str,
    emails: List[str],
    duration_minutes: int,
    time_min: str,
    time_max: str,
    working_hours_only: bool = True,
    working_hours_start: str = "09:00",
    working_hours_end: str = "17:00",
    timezone: str = "America/Chicago",
    max_results: int = 5,
) -> str:
    """
    Find available meeting slots when all participants are free.

    Use this to find times when everyone can meet. Returns time slots
    where all specified participants have no conflicts.

    Args:
        user_google_email (str): The user's Google email address. Required.
        emails (List[str]): List of participant email addresses to check (including yourself if needed).
        duration_minutes (int): Required meeting length in minutes (e.g., 30, 60).
        time_min (str): Start of search window (RFC3339, e.g., "2025-01-15T00:00:00Z").
        time_max (str): End of search window (RFC3339, e.g., "2025-01-20T00:00:00Z").
        working_hours_only (bool): Filter to working hours only (default: True).
        working_hours_start (str): Start of working hours in HH:MM format (default: "09:00").
        working_hours_end (str): End of working hours in HH:MM format (default: "17:00").
        timezone (str): Timezone for working hours (default: "America/Chicago").
        max_results (int): Maximum number of slots to return (default: 5).

    Returns:
        str: List of available meeting slots, or message if none found.
    """
    logger.info(
        f"[find_available_slots] Invoked. Email: '{user_google_email}', "
        f"Participants: {len(emails)}, Duration: {duration_minutes}min, "
        f"Range: {time_min} to {time_max}"
    )

    # Format times for API
    formatted_time_min = _correct_time_format_for_api(time_min, "time_min")
    formatted_time_max = _correct_time_format_for_api(time_max, "time_max")

    # Validate time range
    if formatted_time_min and formatted_time_max and formatted_time_min >= formatted_time_max:
        raise ValueError(
            f"time_min ({time_min}) must be before time_max ({time_max})"
        )

    # Get free/busy for all participants
    request_body = {
        "timeMin": formatted_time_min,
        "timeMax": formatted_time_max,
        "items": [{"id": email} for email in emails],
        "timeZone": timezone,
    }

    result = await asyncio.to_thread(
        lambda: service.freebusy().query(body=request_body).execute()
    )

    # Collect all busy periods from all participants
    all_busy_intervals = []
    calendars = result.get("calendars", {})
    
    for email in emails:
        calendar_data = calendars.get(email, {})
        busy_periods = calendar_data.get("busy", [])
        
        for period in busy_periods:
            start_dt = datetime.datetime.fromisoformat(
                period["start"].replace("Z", "+00:00")
            )
            end_dt = datetime.datetime.fromisoformat(
                period["end"].replace("Z", "+00:00")
            )
            all_busy_intervals.append((start_dt, end_dt))

    # Merge all busy intervals
    merged_busy = _merge_busy_intervals(all_busy_intervals)

    # Parse time range
    search_start = datetime.datetime.fromisoformat(
        formatted_time_min.replace("Z", "+00:00")
    )
    search_end = datetime.datetime.fromisoformat(
        formatted_time_max.replace("Z", "+00:00")
    )

    # Find available slots day by day
    available_slots = []
    current_day = search_start.replace(hour=0, minute=0, second=0, microsecond=0)
    
    while current_day < search_end and len(available_slots) < max_results:
        next_day = current_day + datetime.timedelta(days=1)
        
        # Skip weekends if working hours only
        if working_hours_only and current_day.weekday() >= 5:
            current_day = next_day
            continue
        
        # Get busy intervals for this day
        day_busy = [
            (start, end) for start, end in merged_busy
            if start.date() == current_day.date() or end.date() == current_day.date()
        ]
        
        # Clip intervals to this day
        day_start = max(current_day, search_start)
        day_end = min(next_day, search_end)
        
        # Find free slots for this day
        day_slots = _find_free_slots_in_day(
            day_busy,
            day_start,
            day_end,
            duration_minutes,
            working_hours_only,
            working_hours_start,
            working_hours_end,
            timezone,
        )
        
        # Add slots that meet duration requirement
        for slot_start, slot_end in day_slots:
            if len(available_slots) >= max_results:
                break
            # Only add slots that fit the duration
            slot_duration = (slot_end - slot_start).total_seconds() / 60
            if slot_duration >= duration_minutes:
                # Create a slot of exactly the requested duration
                available_slots.append((slot_start, slot_start + datetime.timedelta(minutes=duration_minutes)))
        
        current_day = next_day

    # Format output
    if not available_slots:
        return (
            f"No available {duration_minutes}-minute slots found for all {len(emails)} "
            f"participants between {formatted_time_min[:10]} and {formatted_time_max[:10]}.\n\n"
            f"Try:\n"
            f"- Expanding the search window\n"
            f"- Reducing the meeting duration\n"
            f"- Disabling working_hours_only filter"
        )

    output_lines = [
        f"Available {duration_minutes}-minute slots for all {len(emails)} participants:",
        ""
    ]
    
    for i, (start, end) in enumerate(available_slots, 1):
        day_name = start.strftime("%a")
        date_str = start.strftime("%b %d")
        start_time = start.strftime("%I:%M %p").lstrip("0")
        end_time = end.strftime("%I:%M %p").lstrip("0")
        output_lines.append(f"{i}. {day_name} {date_str}, {start_time} - {end_time}")

    logger.info(
        f"[find_available_slots] Found {len(available_slots)} available slots"
    )
    return "\n".join(output_lines)


# Valid auto-decline modes for OOO and Focus Time events
VALID_AUTO_DECLINE_MODES = [
    "declineNone",
    "declineAllConflictingInvitations",
    "declineOnlyNewConflictingInvitations",
]


@server.tool()
@handle_http_errors("create_out_of_office", service_type="calendar")
@require_google_service("calendar", "calendar_events")
async def create_out_of_office(
    service,
    user_google_email: str,
    start_time: str,
    end_time: str,
    auto_decline_mode: str = "declineAllConflictingInvitations",
    decline_message: Optional[str] = None,
    calendar_id: str = "primary",
    send_updates: Optional[str] = "all",
) -> str:
    """
    Create an Out of Office event that can automatically decline conflicting meetings.

    This creates a special OOO event that shows you as unavailable and can automatically
    decline meeting invitations during this period.

    Note: This feature requires a Google Workspace account (not personal Gmail).
    OOO events can only be created on the primary calendar.

    Args:
        user_google_email (str): The user's Google email address. Required.
        start_time (str): OOO start time (RFC3339, e.g., "2025-01-15T00:00:00Z").
        end_time (str): OOO end time (RFC3339, e.g., "2025-01-20T00:00:00Z").
        auto_decline_mode (str): How to handle conflicting invitations:
            - "declineAllConflictingInvitations" (default): Decline all conflicts
            - "declineOnlyNewConflictingInvitations": Only decline new invitations
            - "declineNone": Don't auto-decline anything
        decline_message (Optional[str]): Custom message to include when declining invites.
            Defaults to "I'm out of office."
        calendar_id (str): Must be "primary" for OOO events. Defaults to "primary".
        send_updates (Optional[str]): Whether to notify about declined events.
            Valid values: "all", "externalOnly", "none". Defaults to "all".

    Returns:
        str: Confirmation message of the successful OOO event creation.
    """
    logger.info(
        f"[create_out_of_office] Invoked. Email: '{user_google_email}', "
        f"From {start_time} to {end_time}, Mode: {auto_decline_mode}"
    )

    # Validate calendar_id - OOO only works on primary
    if calendar_id != "primary":
        logger.warning(
            f"[create_out_of_office] calendar_id '{calendar_id}' is not 'primary'. "
            "OOO events only work on primary calendar. Using 'primary'."
        )
        calendar_id = "primary"

    # Validate auto_decline_mode
    if auto_decline_mode not in VALID_AUTO_DECLINE_MODES:
        raise ValueError(
            f"Invalid auto_decline_mode '{auto_decline_mode}'. "
            f"Must be one of: {VALID_AUTO_DECLINE_MODES}"
        )

    # Build OOO properties
    effective_decline_message = decline_message or "I'm out of office."
    ooo_properties = {
        "autoDeclineMode": auto_decline_mode,
        "declineMessage": effective_decline_message,
    }

    # Build event body
    event_body = {
        "summary": "Out of office",
        "eventType": "outOfOffice",
        "start": {"dateTime": _correct_time_format_for_api(start_time, "start_time")},
        "end": {"dateTime": _correct_time_format_for_api(end_time, "end_time")},
        "outOfOfficeProperties": ooo_properties,
        "visibility": "public",
    }

    validated_send_updates = _validate_send_updates(send_updates, "create_out_of_office")

    # Create the event
    created_event = await asyncio.to_thread(
        lambda: service.events()
        .insert(
            calendarId=calendar_id,
            body=event_body,
            sendUpdates=validated_send_updates,
        )
        .execute()
    )

    event_id = created_event.get("id", "unknown")
    link = created_event.get("htmlLink", "No link available")
    
    confirmation_message = (
        f"Successfully created Out of Office event for {user_google_email}.\n"
        f"Period: {start_time[:10]} to {end_time[:10]}\n"
        f"Auto-decline mode: {auto_decline_mode}\n"
        f"Decline message: {effective_decline_message}\n"
        f"Event ID: {event_id}\n"
        f"Link: {link}"
    )

    logger.info(f"[create_out_of_office] Created OOO event {event_id}")
    return confirmation_message


@server.tool()
@handle_http_errors("create_focus_time", service_type="calendar")
@require_google_service("calendar", "calendar_events")
async def create_focus_time(
    service,
    user_google_email: str,
    start_time: str,
    end_time: str,
    summary: str = "Focus Time",
    auto_decline_mode: str = "declineNone",
    decline_message: Optional[str] = None,
    chat_status: Optional[str] = None,
    calendar_id: str = "primary",
    send_updates: Optional[str] = "all",
) -> str:
    """
    Create a Focus Time event to block time for uninterrupted work.

    Focus Time events can optionally auto-decline meeting invitations and
    set your Google Chat status to Do Not Disturb.

    Note: This feature requires a Google Workspace account (not personal Gmail).
    Focus Time events can only be created on the primary calendar.

    Args:
        user_google_email (str): The user's Google email address. Required.
        start_time (str): Focus time start (RFC3339, e.g., "2025-01-15T09:00:00Z").
        end_time (str): Focus time end (RFC3339, e.g., "2025-01-15T11:00:00Z").
        summary (str): Event title. Defaults to "Focus Time".
        auto_decline_mode (str): How to handle conflicting invitations:
            - "declineNone" (default): Don't auto-decline
            - "declineAllConflictingInvitations": Decline all conflicts
            - "declineOnlyNewConflictingInvitations": Only decline new invitations
        decline_message (Optional[str]): Custom message when declining invites.
        chat_status (Optional[str]): Set Google Chat status. Use "doNotDisturb" to
            enable Do Not Disturb during focus time. Defaults to None (no change).
        calendar_id (str): Must be "primary" for Focus Time events. Defaults to "primary".
        send_updates (Optional[str]): Whether to notify about declined events.
            Valid values: "all", "externalOnly", "none". Defaults to "all".

    Returns:
        str: Confirmation message of the successful Focus Time event creation.
    """
    logger.info(
        f"[create_focus_time] Invoked. Email: '{user_google_email}', "
        f"Summary: '{summary}', From {start_time} to {end_time}"
    )

    # Validate calendar_id - Focus Time only works on primary
    if calendar_id != "primary":
        logger.warning(
            f"[create_focus_time] calendar_id '{calendar_id}' is not 'primary'. "
            "Focus Time events only work on primary calendar. Using 'primary'."
        )
        calendar_id = "primary"

    # Validate auto_decline_mode
    if auto_decline_mode not in VALID_AUTO_DECLINE_MODES:
        raise ValueError(
            f"Invalid auto_decline_mode '{auto_decline_mode}'. "
            f"Must be one of: {VALID_AUTO_DECLINE_MODES}"
        )

    # Build Focus Time properties
    focus_properties: Dict[str, Any] = {
        "autoDeclineMode": auto_decline_mode,
    }
    if decline_message:
        focus_properties["declineMessage"] = decline_message
    if chat_status:
        focus_properties["chatStatus"] = chat_status

    # Build event body
    event_body = {
        "summary": summary,
        "eventType": "focusTime",
        "start": {"dateTime": _correct_time_format_for_api(start_time, "start_time")},
        "end": {"dateTime": _correct_time_format_for_api(end_time, "end_time")},
        "focusTimeProperties": focus_properties,
        "visibility": "default",
    }

    validated_send_updates = _validate_send_updates(send_updates, "create_focus_time")

    # Create the event
    created_event = await asyncio.to_thread(
        lambda: service.events()
        .insert(
            calendarId=calendar_id,
            body=event_body,
            sendUpdates=validated_send_updates,
        )
        .execute()
    )

    event_id = created_event.get("id", "unknown")
    link = created_event.get("htmlLink", "No link available")
    
    confirmation_parts = [
        f"Successfully created Focus Time event '{summary}' for {user_google_email}.",
        f"Time: {start_time} to {end_time}",
        f"Auto-decline mode: {auto_decline_mode}",
    ]
    if chat_status:
        confirmation_parts.append(f"Chat status: {chat_status}")
    confirmation_parts.extend([
        f"Event ID: {event_id}",
        f"Link: {link}",
    ])
    
    confirmation_message = "\n".join(confirmation_parts)

    logger.info(f"[create_focus_time] Created Focus Time event {event_id}")
    return confirmation_message
