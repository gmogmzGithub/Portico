#!/usr/bin/env python3
"""
Tools CLI for Google Workspace MCP Server

This script allows you to test MCP tools directly without the protocol overhead.
You can call tools as regular Python async functions with real or mocked credentials.

Usage:
    python tools_cli.py --tool get_doc_content --document_id "doc_id_here" --user_google_email "user@example.com"
    python tools_cli.py --interactive  # Interactive REPL mode
    python tools_cli.py --optimizer --tool google_workspace_find_tool --query "create document"  # Optimizer mode
"""

import argparse
import asyncio
import logging
import os
import sys
from typing import Any, Dict
from dotenv import load_dotenv

# Load environment variables
dotenv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
load_dotenv(dotenv_path=dotenv_path)

# Suppress googleapiclient discovery cache warning
logging.getLogger("googleapiclient.discovery_cache").setLevel(logging.ERROR)

# Configure logging - use WARNING to reduce noise
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "WARNING"),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def init_server(optimizer_mode: bool = False):
    """Initialize the server and import all tools.

    Args:
        optimizer_mode: If True, initialize optimizer and expose only meta-tools
    """
    try:
        # Import server and initialize
        from auth.oauth_config import reload_oauth_config
        from core.server import server, set_transport_mode
        from core.tool_registry import (
            set_enabled_tools as set_enabled_tool_names,
            wrap_server_tool_method,
        )
        from auth.scopes import set_enabled_tools

        # Reload OAuth configuration
        reload_oauth_config()

        # Configure for testing
        set_transport_mode("stdio")  # Use stdio mode by default for testing

        # Import all tool modules to register them (side-effect imports)
        import gmail.gmail_tools  # noqa: F401
        import gdrive.drive_tools  # noqa: F401
        import gcalendar.calendar_tools  # noqa: F401
        import gdocs.docs_tools  # noqa: F401
        import gsheets.sheets_tools  # noqa: F401
        import gchat.chat_tools  # noqa: F401
        import gforms.forms_tools  # noqa: F401
        import gslides.slides_tools  # noqa: F401
        import gtasks.tasks_tools  # noqa: F401
        import gsearch.search_tools  # noqa: F401

        # Enable all tools
        all_services = [
            "gmail",
            "drive",
            "calendar",
            "docs",
            "sheets",
            "chat",
            "forms",
            "slides",
            "tasks",
            "search",
        ]
        set_enabled_tools(all_services)
        set_enabled_tool_names(None)

        # Wrap and filter tools
        wrap_server_tool_method(server)
        from core.tool_registry import filter_server_tools

        filter_server_tools(server)

        if optimizer_mode:
            _enable_optimizer_mode(server)

        return server
    except Exception as e:
        logger.error(f"Failed to initialize server: {e}")
        raise


def _enable_optimizer_mode(server):
    """Enable optimizer mode: collect tools, init optimizer, expose only meta-tools."""
    from core.optimizer import is_optimizer_available, initialize_optimizer
    from core.server import register_optimizer_tools

    if not is_optimizer_available():
        raise RuntimeError(
            "Optimizer mode requires numpy and sentence-transformers. "
            "Install with: uv pip install numpy sentence-transformers"
        )

    # Map service modules to service names
    service_mapping = {
        "gmail": "gmail",
        "drive": "drive",
        "calendar": "calendar",
        "docs": "docs",
        "sheets": "sheets",
        "chat": "chat",
        "forms": "forms",
        "slides": "slides",
        "tasks": "tasks",
        "search": "search",
    }

    # Collect all registered tools
    tool_definitions = {}
    tool_functions = {}

    if hasattr(server, "_tool_manager") and hasattr(server._tool_manager, "_tools"):
        for tool_name, tool_impl in server._tool_manager._tools.items():
            # Skip auth tool in optimizer mode
            if tool_name == "start_google_auth":
                continue

            # Determine service from tool name or module
            service = None
            for svc_key, svc_name in service_mapping.items():
                if svc_key in tool_name.lower() or (
                    hasattr(tool_impl.fn, "__module__")
                    and svc_key in tool_impl.fn.__module__
                ):
                    service = svc_name
                    break

            tool_def = {
                "name": tool_name,
                "description": getattr(tool_impl.fn, "__doc__", "") or "",
                "inputSchema": getattr(tool_impl, "parameters", {}),
                "service": service or "unknown",
            }
            tool_definitions[tool_name] = tool_def
            tool_functions[tool_name] = tool_impl.fn

    print(f"🔍 Optimizer mode: Found {len(tool_definitions)} tools")

    # Initialize optimizer
    optimizer = initialize_optimizer(tool_definitions, tool_functions)

    # Wait for embeddings to be ready (with timeout)
    print("⏳ Loading embedding model (this may take a few seconds)...")
    ready = optimizer.wait_until_ready(timeout=60)
    if not ready:
        raise RuntimeError("Optimizer failed to initialize within timeout")
    print("✅ Embeddings ready")

    # Clear original tools and register only optimizer meta-tools
    if hasattr(server, "_tool_manager") and hasattr(server._tool_manager, "_tools"):
        # Preserve get_tool_hints - it should be available alongside optimizer tools
        get_tool_hints_backup = server._tool_manager._tools.get("get_tool_hints")

        server._tool_manager._tools.clear()

        # Restore get_tool_hints so agents can access hints directly
        if get_tool_hints_backup:
            server._tool_manager._tools["get_tool_hints"] = get_tool_hints_backup

    register_optimizer_tools()
    print(
        "✅ Registered 5 optimizer tools: find_tool, describe_tool, list_tools, call_tool, get_tool_hints"
    )


class ToolTester:
    """Helper class to test MCP tools directly."""

    def __init__(self, server_instance):
        self.server = server_instance
        self.tools = {}

    async def _collect_tools(self) -> Dict[str, Any]:
        """Collect all registered tools from the server."""
        tools = {}
        if hasattr(self.server, "_tool_manager"):
            tool_manager = self.server._tool_manager
            if hasattr(tool_manager, "_tools"):
                # FastMCP stores tools in _tools dict directly, no list_tools() method exists
                tools = dict(tool_manager._tools)
        return tools

    async def init_tools(self):
        """Initialize tools collection (must be called after __init__)."""
        self.tools = await self._collect_tools()

    def list_tools(self) -> None:
        """Print all available tools."""
        print("\n📋 Available Tools:")
        print("=" * 60)
        for name, tool in sorted(self.tools.items()):
            desc = (
                tool.description.split("\n")[0]
                if tool.description
                else "No description"
            )
            print(f"  • {name}")
            print(f"    {desc}")
            print()

    def get_tool_info(self, tool_name: str) -> None:
        """Print detailed information about a specific tool."""
        if tool_name not in self.tools:
            print(f"❌ Tool '{tool_name}' not found.")
            return

        tool = self.tools[tool_name]
        print(f"\n🔧 Tool: {tool_name}")
        print("=" * 60)
        print(f"Description: {tool.description}")
        print("\nParameters:")

        if hasattr(tool, "fn"):
            import inspect

            sig = inspect.signature(tool.fn)
            for param_name, param in sig.parameters.items():
                if param_name in [
                    "service",
                    "drive_service",
                    "docs_service",
                    "sheets_service",
                ]:
                    continue  # Skip injected service parameters
                annotation = (
                    param.annotation
                    if param.annotation != inspect.Parameter.empty
                    else "Any"
                )
                default = (
                    f" = {param.default}"
                    if param.default != inspect.Parameter.empty
                    else ""
                )
                print(f"  • {param_name}: {annotation}{default}")
        print()

    async def call_tool(self, tool_name: str, **kwargs) -> Any:
        """Call a tool with the given parameters."""
        if tool_name not in self.tools:
            raise ValueError(
                f"Tool '{tool_name}' not found. Use list_tools() to see available tools."
            )

        tool = self.tools[tool_name]

        # Remove None values from kwargs
        kwargs = {k: v for k, v in kwargs.items() if v is not None}

        print(f"\n🚀 Calling tool: {tool_name}")
        print(f"   Parameters: {kwargs}")
        print("=" * 60)

        try:
            # Call the tool function directly
            if hasattr(tool, "fn"):
                result = await tool.fn(**kwargs)
            else:
                result = await tool(**kwargs)

            print("\n✅ Result:")
            print("-" * 60)
            print(result)
            print("-" * 60)
            return result
        except Exception as e:
            print(f"\n❌ Error: {e}")
            logger.exception("Tool execution failed")
            raise


def interactive_mode(tester: ToolTester):
    """Run an interactive REPL for testing tools."""
    print("\n🎯 Interactive Test Mode")
    print("=" * 60)
    print("Commands:")
    print("  list              - List all available tools")
    print("  info <tool_name>  - Get detailed info about a tool")
    print("  call <tool_name>  - Call a tool (will prompt for parameters)")
    print("  quit              - Exit interactive mode")
    print("=" * 60)

    while True:
        try:
            cmd = input("\n> ").strip()

            if not cmd:
                continue

            if cmd == "quit":
                print("👋 Goodbye!")
                break

            if cmd == "list":
                tester.list_tools()
                continue

            if cmd.startswith("info "):
                tool_name = cmd[5:].strip()
                tester.get_tool_info(tool_name)
                continue

            if cmd.startswith("call "):
                tool_name = cmd[5:].strip()
                if tool_name not in tester.tools:
                    print(f"❌ Tool '{tool_name}' not found.")
                    continue

                # Get tool parameters
                tester.get_tool_info(tool_name)

                # Prompt for parameters
                print("\nEnter parameters (press Enter to skip optional parameters):")
                kwargs = {}

                tool = tester.tools[tool_name]
                if hasattr(tool, "fn"):
                    import inspect

                    sig = inspect.signature(tool.fn)
                    for param_name, param in sig.parameters.items():
                        if param_name in [
                            "service",
                            "drive_service",
                            "docs_service",
                            "sheets_service",
                        ]:
                            continue

                        if param.default == inspect.Parameter.empty:
                            # Required parameter
                            value = input(f"  {param_name} (required): ")
                            kwargs[param_name] = value
                        else:
                            # Optional parameter
                            default_str = (
                                f" [default: {param.default}]"
                                if param.default is not None
                                else ""
                            )
                            value = input(f"  {param_name} (optional){default_str}: ")
                            if value:
                                kwargs[param_name] = value

                # Execute the tool
                asyncio.run(tester.call_tool(tool_name, **kwargs))
            else:
                print(
                    "❌ Unknown command. Try 'list', 'info <tool>', 'call <tool>', or 'quit'"
                )

        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"❌ Error: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="CLI for Google Workspace MCP tools",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument(
        "--interactive", "-i", action="store_true", help="Run in interactive REPL mode"
    )
    parser.add_argument(
        "--list", "-l", action="store_true", help="List all available tools"
    )
    parser.add_argument("--tool", "-t", type=str, help="Tool name to call")
    parser.add_argument("--info", type=str, help="Show detailed info about a tool")
    parser.add_argument(
        "--user_google_email",
        type=str,
        default=os.getenv("USER_GOOGLE_EMAIL"),
        help="User email for authentication (can also be set via USER_GOOGLE_EMAIL env var)",
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose logging"
    )
    parser.add_argument(
        "--optimizer",
        action="store_true",
        help="Enable optimizer mode - expose only 4 meta-tools for semantic tool discovery",
    )

    # Allow arbitrary additional arguments for tool parameters
    args, unknown = parser.parse_known_args()

    # Set verbose logging if requested
    if args.verbose:
        logging.getLogger().setLevel(logging.INFO)

    # Parse unknown args as tool parameters (raw strings initially)
    import json
    import inspect

    raw_kwargs = {}
    i = 0
    while i < len(unknown):
        arg = unknown[i]
        if arg.startswith("--"):
            param_name = arg[2:]
            if i + 1 < len(unknown) and not unknown[i + 1].startswith("--"):
                raw_kwargs[param_name] = unknown[i + 1]
                i += 2
            else:
                raw_kwargs[param_name] = True
                i += 1
        else:
            i += 1

    def unescape_shell_chars(value: str) -> str:
        """Unescape common shell-escaped characters in string values.

        When users pass arguments like --range_name 'Sheet1\!A1:B2' to prevent
        bash history expansion, the backslash may be preserved in the string.
        This function removes such escape characters.
        """
        if not isinstance(value, str):
            return value
        # Unescape common shell-escaped special characters
        # Order matters: handle double backslashes first
        value = value.replace(r"\\", "\x00")  # Temporarily protect \\
        value = value.replace(r"\!", "!")
        value = value.replace(r"\$", "$")
        value = value.replace(r"\`", "`")
        value = value.replace(r"\#", "#")
        value = value.replace(r"\"", '"')
        value = value.replace(r"\'", "'")
        value = value.replace("\x00", "\\")  # Restore single backslash from \\
        return value

    def convert_value_by_type(value: str, expected_type) -> Any:
        """Convert a string value based on expected type annotation."""
        import typing

        if value is True:  # Boolean flag (--flag without value)
            return value

        # Handle Optional types (e.g., Optional[int] = Union[int, None])
        origin = getattr(expected_type, "__origin__", None)
        if origin is type(None):
            return None

        # Extract the actual type from Optional/Union ONLY
        # Don't do this for List[T], Dict[K,V], etc. which also have __args__
        if origin is typing.Union:
            type_args = getattr(expected_type, "__args__", ())
            if type_args:
                # Filter out NoneType from Union types
                non_none_types = [t for t in type_args if t is not type(None)]
                if non_none_types:
                    expected_type = non_none_types[0]
                    # Re-compute origin for the extracted type
                    origin = getattr(expected_type, "__origin__", None)

        # Convert based on expected type
        if expected_type is bool:
            return value.lower() == "true"
        elif expected_type is int:
            return int(value)
        elif expected_type is float:
            return float(value)
        elif expected_type in (list, dict) or origin in (list, dict):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return unescape_shell_chars(value)
        else:
            # Default: keep as string, unescape shell characters
            return unescape_shell_chars(value)

    def convert_value_fallback(value: str) -> Any:
        """Fallback conversion when no type info is available."""
        if value is True:
            return value
        if value.lower() in ("true", "false"):
            return value.lower() == "true"
        elif value.startswith("[") or value.startswith("{"):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return unescape_shell_chars(value)
        # Don't auto-convert numeric strings - keep as string by default
        # Unescape shell characters for string values
        return unescape_shell_chars(value)

    def parse_tool_kwargs(tool, raw_kwargs: dict) -> dict:
        """Parse raw kwargs using tool's type annotations."""
        tool_kwargs = {}
        type_hints = {}

        # Get type hints from tool function
        if hasattr(tool, "fn"):
            try:
                type_hints = inspect.signature(tool.fn).parameters
            except (ValueError, TypeError):
                pass

        for param_name, value in raw_kwargs.items():
            if param_name in type_hints:
                param = type_hints[param_name]
                if param.annotation != inspect.Parameter.empty:
                    tool_kwargs[param_name] = convert_value_by_type(
                        value, param.annotation
                    )
                else:
                    tool_kwargs[param_name] = convert_value_fallback(value)
            else:
                tool_kwargs[param_name] = convert_value_fallback(value)

        return tool_kwargs

    # Initialize server
    print("🔧 Initializing server...")
    try:
        server = init_server(optimizer_mode=args.optimizer)
        tester = ToolTester(server)
        # Initialize tools asynchronously
        asyncio.run(tester.init_tools())
        mode_str = " (optimizer mode)" if args.optimizer else ""
        print(f"✅ Server initialized ({len(tester.tools)} tools loaded){mode_str}")
    except Exception as e:
        print(f"❌ Failed to initialize: {e}")
        if args.verbose:
            import traceback

            traceback.print_exc()
        sys.exit(1)

    if args.list:
        tester.list_tools()
        return

    if args.info:
        tester.get_tool_info(args.info)
        return

    if args.interactive:
        interactive_mode(tester)
        return

    if args.tool:
        # Get the tool to access type hints for conversion
        if args.tool not in tester.tools:
            print(
                f"❌ Tool '{args.tool}' not found. Use --list to see available tools."
            )
            sys.exit(1)

        tool = tester.tools[args.tool]
        # Parse kwargs using tool's type annotations
        tool_kwargs = parse_tool_kwargs(tool, raw_kwargs)

        # Add user_google_email to kwargs if provided
        if args.user_google_email:
            tool_kwargs["user_google_email"] = args.user_google_email

        asyncio.run(tester.call_tool(args.tool, **tool_kwargs))
        return

    # No action specified, show help
    parser.print_help()
    print("\n💡 Quick start:")
    print("  python tools_cli.py --list                           # List all tools")
    print("  python tools_cli.py --info get_doc_content           # Get tool info")
    print("  python tools_cli.py --interactive                    # Interactive mode")
    print(
        "  python tools_cli.py --tool search_docs --query 'test' --user_google_email user@example.com"
    )
    print("\n🔍 Optimizer mode (semantic tool discovery):")
    print(
        "  python tools_cli.py --optimizer --list               # List optimizer meta-tools"
    )
    print(
        "  python tools_cli.py --optimizer --tool google_workspace_find_tool --query 'create document'"
    )
    print(
        "  python tools_cli.py --optimizer --tool google_workspace_describe_tool --name 'create_doc'"
    )
    print(
        "  python tools_cli.py --optimizer --tool google_workspace_call_tool --name 'create_doc' "
        '--arguments \'{"title": "My Doc", "user_google_email": "me@example.com"}\''
    )


if __name__ == "__main__":
    main()
