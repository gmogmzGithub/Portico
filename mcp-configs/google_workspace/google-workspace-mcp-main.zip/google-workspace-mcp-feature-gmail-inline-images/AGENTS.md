<!-- START OF INDEED CENTRAL CONTEXT INSTRUCTIONS -->
<!-- TEMPLATE_VERSION: 3.0.0 -->

!! At the start of this session, complete all steps below before proceeding with any tasks !!

1. Investigate this repository to determine what technologies are in use. Not all categories will be present in every repository. Look for:
  - Programming languages
  - Frameworks and libraries
  - Build systems and package managers
  - Testing frameworks
  - Databases and data stores
  - Deployment and containerization tools
  - CI/CD systems
  - Cloud providers and infrastructure
  Keep this information in mind for evaluating file relevance in later steps.
2. Determine the model being used (if available from the agent's context) and store it in a variable.
3. Run `iago-cli framework render --model <model>`. If you are missing <model>, skip that flag.
4. Inspect the index.md file returned by that command and evaluate which files are relevant to this repository or the current task using a two-tier approach. Use the technology information gathered in step 1 to inform your decisions:
  - Default to reading files unless they are clearly irrelevant. When in doubt about relevance, err on the side of inclusion.
  - Examine the path/directory structure. Only skip a file if the path clearly indicates the content is for a technology NOT used in this repository.
  - If the path is vague or general and doesn't clearly indicate relevance or irrelevance, evaluate the filename and description to make your final decision.
5. Read only the files you determined to be relevant in the previous step.
6. Follow the instructions in the gathered context files throughout the rest of this session for all future tasks.
7. Keep all filenames as a reference - you may read previously skipped files if later tasks or context make them relevant.

When listing files for the human, do so in the format:

"I have found the following context files that I believe are relevant:
- filename.md
- other_filename.md"

Replace the filenames above with the actual file names you found, using one line per file.

<!-- END OF INDEED CENTRAL CONTEXT INSTRUCTIONS -->

# Agent Guide for Google Workspace MCP

## Repository Information

**IMPORTANT**: This is a fork of [taylorwilsdon/google_workspace_mcp](https://github.com/taylorwilsdon/google_workspace_mcp) maintained by Indeed.

### Fork Status
- We are generally doing our own thing and developing features for Indeed's specific needs
- **We do NOT intend to push all changes upstream** to the original repository
- Some features may be Indeed-specific and not appropriate for the upstream project
- **All MRs should target Indeed GitLab `origin/main`**

### Creating Merge Requests
```bash
# Create branch, commit, push, and create MR
git checkout -b jira/<username>/AI4DP-XXX  # or jira/<username>/NOBUG
git add . && git commit -m "NOBUG: Description"
git push -u origin <branch-name> -o secret_push_protection.skip_all
glab mr create --fill --yes
```

### Syncing with Upstream

We have two git remotes configured:
- `origin` - Indeed GitLab (`git@code.corp.indeed.com:ai4dp/google-workspace-mcp.git`)
- `upstream` - Taylor's original repo (`https://github.com/taylorwilsdon/google_workspace_mcp.git`)

**To sync changes from upstream:**

```bash
# 1. Fetch upstream
git fetch upstream

# 2. Check for new commits
git log main..upstream/main --oneline

# 3. Cherry-pick the commits you want
git cherry-pick <commit-sha>

# 4. Push to a sync branch (avoids branch protection issues)
git push origin main:sync/upstream-$(date +%Y-%m-%d) -o secret_push_protection.skip_all

# 5. Create MR in GitLab to merge the sync branch
glab mr create --source-branch sync/upstream-$(date +%Y-%m-%d) --target-branch main --title "Sync upstream changes" --yes
```

**GitLab Push Considerations:**
- Upstream commits have non-Indeed author emails - the email push rule is disabled to allow these
- The bundled credentials file triggers secret detection - use `-o secret_push_protection.skip_all` when pushing
- Branch protection on `main` blocks force pushes - use the sync branch + MR workflow instead

## Running CLI

By default run all python commands via `uv`, unless otherwise directed.

## Testing Tools

### Using tools_cli.py
Test individual MCP tools without running the server:

```bash
uv run python tools_cli.py --tool modify_doc_text --document_id <doc_id> --user_google_email <email> --text "Hello" --location end
```

Use `--list` to see all available tools.

### Authentication
- Uses OAuth2 flow with credential store in `~/.google_workspace_mcp/credentials/`
- Email parameter is required: `--user_google_email your@email.com`
- First run will trigger browser authentication
- Uses bundled Indeed OAuth client credentials by default

## Common Issues

### 1. Google Docs Text Operations
- **Index 0 is invalid** - Start from index 1 (first char after section break)
- **Blank lines create empty list items** - Use `convert_to_list` parameter, auto-cleaning handles this
- **Text inherits formatting** - Insertion after bold text inherits bold; clearing happens automatically

### 2. Batch Operations
- **Use batch_edit_doc** for multiple operations - more efficient than individual calls
- **Search-based positioning** - Prefer `search + position` over manual index calculation
- **Auto-adjustment** - Positions auto-adjust for sequential operations in batch
- **Table modifications** - Use `modify_table`, NOT batch_edit_doc (batch can only INSERT tables)

### 3. List Operations
- **List types** - Use "ORDERED"/"UNORDERED" or "numbered"/"bullet"
- **Blank line cleaning** - Automatically applied when `convert_to_list` is used
- **insert_list_item** - For adding single items to existing lists
- **append_to_list** - Specialized for appending to end of list

### 4. Error Messages
- **DocsErrorBuilder** - Structured error responses with codes like `MISSING_REQUIRED_PARAM`
- **ValidationManager** - Parameter validation with helpful error messages
- Check error `code` field for programmatic handling

### 5. Markdown Import (`insert_markdown`)
- **Tables need blank lines** - Google's markdown parser requires a blank line before tables; `normalize_markdown_tables()` handles this automatically
- **Horizontal rules** - Use `---`; rendered as bottom border on paragraph (Google doesn't have native HR)
- **Links in tables** - Preserved with formatting during import
- **Test with example docs** - Use files in `tests/example_docs/` to test markdown import

### 6. Google Slides Text Styling (CRITICAL!)

**Text styling in Slides is complex due to inheritance.** Styles cascade from:
`text element → placeholder → layout → master → theme`

**NEVER use bare `insertText`** - it creates unstyled text!

**Essential tools for text styling:**
- **`get_effective_text_style`** - Resolves full inheritance to show ACTUAL rendered style
- **`insert_text_with_style`** - Inserts text WITH styling (explicit or copied from source)
- **`get_presentation_theme`** - Shows theme fonts, colors, and layouts

**Workflow for copying/duplicating content:**
```bash
# 1. Get effective style from source
uv run python tools_cli.py --tool get_effective_text_style \
  --presentation_id SOURCE_PRES --element_id SOURCE_ELEM

# 2. Insert with copied style
uv run python tools_cli.py --tool insert_text_with_style \
  --presentation_id DEST_PRES --element_id DEST_ELEM \
  --text "My Text" --copy_style_from SOURCE_ELEM \
  --copy_style_from_presentation SOURCE_PRES
```

**Layout selection matters!** Layouts contain:
- Background images (wave patterns, gradients)
- Logos (company branding)
- Pre-styled placeholders

Use `list_layouts` to see available layouts, then `add_slide(layout="layout_id")`.

**Call `get_tool_hints(category="slides")` for comprehensive guidance!**

## Design Patterns

### Tool Parameters
- **Multiple positioning modes** - location, index, search, heading, range
- **Preview mode** - Add `preview=True` to see what would change
- **Tab support** - Multi-tab documents need `tab_id` parameter

### Undo System
- **In-memory history** - Operations tracked per document
- **undo_doc_operation** - Undo last operation on document
- **Batch operations** - Single undo for entire batch via `batch_id`

## Code Style

### Testing
- Write tests in `tests/gdocs/` for gdocs features
- Use pytest: `uv run python -m pytest tests/gdocs/test_*.py`
- Integration tests go in `tests/gdocs/integration/`

### Aimer (AI MR Reviewer)
Aimer automatically reviews MRs and may request:
- **Unit tests for new parameters** - When adding parameters to helper functions (e.g., `tab_id`), write tests that specifically exercise those new parameters
- **Test coverage for helper functions** - Changes to `gdocs/docs_helpers.py` need explicit tests; structure tests don't always cover helper function changes
- **Mock document structures** - Create helper functions like `create_multi_tab_doc()` to generate test fixtures

Example test pattern for new functionality:
```python
def create_multi_tab_doc():
    """Create a mock multi-tab document."""
    return {"tabs": [{"tabProperties": {"tabId": "tab1"}, ...}]}

class TestNewFeature:
    def test_function_with_new_param(self):
        doc = create_multi_tab_doc()
        result = helper_function(doc, new_param="value")
        assert result == expected
```

After making a MR, ask the user if they'd like you to sleep for 10 minutes and check the MR for aimer comments and pipeline failures.  Usually this is what you should be doing.

### Commits
- Format: `module: Brief description`
- Reference beads issues in commit body
- Use ADRs for significant design decisions

### Issue Tracking with bd (beads)

**IMPORTANT**: This project uses **bd (beads)** for ALL issue tracking. Do NOT use markdown TODOs or other tracking methods.

**Check for ready work:**
```bash
bd ready --json
```

**Create new issues:**
```bash
bd create "Issue title" -t bug|feature|task -p 0-4 --json
bd create "Issue title" -p 1 --deps discovered-from:bd-123 --json
```

**Claim and update:**
```bash
bd update bd-42 --status in_progress --json
bd update bd-42 --priority 1 --json
```

**Complete work:**
```bash
bd close bd-42 --reason "Completed" --json
```

**Issue Types:** `bug`, `feature`, `task`, `epic`, `chore`

**Priorities:** `0` (critical) → `4` (backlog), default is `2`

**Workflow:**
1. Check ready work: `bd ready`
2. Claim task: `bd update <id> --status in_progress`
3. Work on it
4. Discover new work? `bd create "Found bug" -p 1 --deps discovered-from:<parent-id>`
5. Complete: `bd close <id> --reason "Done"`
6. Commit `.beads/issues.jsonl` with code changes

## Documentation

- **ADRs** - Major decisions go in `docs/adrs/` directory
- **Tool docstrings** - Comprehensive with examples in each tool function
- **README** - High-level overview and setup
- **PROMPT.md** - Detailed tool documentation for LLMs

## Quick Start for New Agents

1. Read `README.md` for project overview
2. Check `docs/adrs/` for architectural context
3. Use `tools_cli.py --list` to explore available tools
4. Test changes with `tools_cli.py --tool <name> ...`
5. Run relevant tests before committing
6. Create ADR for significant design decisions
7. File beads issues for bugs/features

## Versioning

**Bump the version in `pyproject.toml` any time you change the tools.** Use [semver](https://semver.org/):

- **MAJOR** (1.0.0 → 2.0.0) - Breaking changes to tool signatures or behavior
- **MINOR** (1.0.0 → 1.1.0) - New tools or features, backward compatible
- **PATCH** (1.0.0 → 1.0.1) - Bug fixes, no new features

The CI pipeline automatically tags Docker images with the version from `pyproject.toml` when merging to main.

## Gotchas

- **pyproject.toml/uv.lock** changes are often from dependency updates, commit separately
- **Linting** - Always check and fix linter errors before committing
- **Timeout commands** - Use `timeout` for potentially long-running operations
- **Module imports** - Import from `gdocs.docs_helpers` for shared utilities
- **CPU-only PyTorch** - We use CPU-only PyTorch to keep Docker images small (~2GB savings) and avoid CI OOM issues. This is sufficient for the optimizer's semantic search workload. See `docs/adrs/005-cpu-only-pytorch-for-docker.md` for details.

