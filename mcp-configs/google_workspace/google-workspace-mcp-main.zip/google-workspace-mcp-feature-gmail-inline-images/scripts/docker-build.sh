#!/bin/bash
# Build and push Google Workspace MCP Docker image to Indeed internal registry
#
# Usage:
#   ./scripts/docker-build.sh              # Build with version from pyproject.toml
#   ./scripts/docker-build.sh 1.0.0        # Build with specific version
#   ./scripts/docker-build.sh --push       # Build and push to registry
#   ./scripts/docker-build.sh 1.0.0 --push # Build specific version and push

set -e

# Configuration
REGISTRY="${DOCKER_REGISTRY:-harbor.indeed.tech}"
IMAGE_NAME="${DOCKER_IMAGE:-ai4dp/google-workspace-mcp}"
FULL_IMAGE="${REGISTRY}/${IMAGE_NAME}"
# Default to linux/amd64 for Intel servers, override with DOCKER_PLATFORM if needed
PLATFORM="${DOCKER_PLATFORM:-linux/amd64}"

# Parse arguments
VERSION=""
PUSH=false

for arg in "$@"; do
    case $arg in
        --push)
            PUSH=true
            ;;
        *)
            if [[ -z "$VERSION" ]]; then
                VERSION="$arg"
            fi
            ;;
    esac
done

# Get version from pyproject.toml if not provided
if [[ -z "$VERSION" ]]; then
    if [[ -f "pyproject.toml" ]]; then
        VERSION=$(grep -m1 '^version = ' pyproject.toml | sed 's/version = "\(.*\)"/\1/')
    fi
    if [[ -z "$VERSION" ]]; then
        VERSION=$(git describe --tags --always 2>/dev/null || echo "latest")
    fi
fi

echo "================================================"
echo "Building Google Workspace MCP Docker Image"
echo "================================================"
echo "Registry: ${REGISTRY}"
echo "Image:    ${IMAGE_NAME}"
echo "Version:  ${VERSION}"
echo "Platform: ${PLATFORM}"
echo "Push:     ${PUSH}"
echo "================================================"

# Build the image with version and latest tags
echo ""
echo "🔨 Building image..."
docker build \
    --platform "${PLATFORM}" \
    -t "${FULL_IMAGE}:${VERSION}" \
    -t "${FULL_IMAGE}:latest" \
    --label "org.opencontainers.image.version=${VERSION}" \
    --label "org.opencontainers.image.created=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    .

echo ""
echo "✅ Build complete!"
echo "   ${FULL_IMAGE}:${VERSION}"
echo "   ${FULL_IMAGE}:latest"

# Push if requested
if [[ "$PUSH" == true ]]; then
    echo ""
    echo "🚀 Pushing to registry..."
    
    # Login to registry if not already logged in
    if ! docker info 2>/dev/null | grep -q "Username"; then
        echo "   Logging in to ${REGISTRY}..."
        docker login "${REGISTRY}"
    fi
    
    docker push "${FULL_IMAGE}:${VERSION}"
    docker push "${FULL_IMAGE}:latest"
    
    echo ""
    echo "✅ Push complete!"
    echo "   Pull with: docker pull ${FULL_IMAGE}:${VERSION}"
fi

echo ""
echo "================================================"
echo "Done!"
echo "================================================"

