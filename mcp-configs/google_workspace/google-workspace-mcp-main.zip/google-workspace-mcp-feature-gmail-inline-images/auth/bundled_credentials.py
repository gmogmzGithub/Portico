"""
Bundled OAuth Credentials for Indeed

This module contains bundled OAuth client credentials for the Indeed organization.
These credentials are for a "Desktop app" type OAuth client, which means:
- The client secret is NOT truly confidential (standard for desktop/installed apps)
- Security relies on: redirect URI (localhost), PKCE, user consent, and scope restrictions
- This is the standard distribution model for desktop applications

These credentials are used as the default when no environment variables are set,
providing a zero-configuration experience for Indeed users.

To override these credentials, set environment variables:
- GOOGLE_OAUTH_CLIENT_ID
- GOOGLE_OAUTH_CLIENT_SECRET
"""

# Indeed Developer Productivity OAuth credentials
# Project: developer-productivity-openctx
# Type: Desktop app (installed application)
INDEED_CLIENT_ID = (
    "621624152059-cg6bonh17b2bt35uef24l8ns3blkh38j.apps.googleusercontent.com"
)
INDEED_CLIENT_SECRET = "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"
INDEED_PROJECT_ID = "developer-productivity-openctx"


def get_bundled_client_config():
    """
    Returns the bundled OAuth client configuration in the format
    expected by Google's OAuth library.

    Returns:
        dict: Client configuration with "installed" key for desktop apps
    """
    return {
        "installed": {
            "client_id": INDEED_CLIENT_ID,
            "client_secret": INDEED_CLIENT_SECRET,
            "project_id": INDEED_PROJECT_ID,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "redirect_uris": ["http://localhost"],
        }
    }


def get_bundled_credentials():
    """
    Returns just the client ID and secret as a tuple.

    Returns:
        tuple: (client_id, client_secret)
    """
    return INDEED_CLIENT_ID, INDEED_CLIENT_SECRET
